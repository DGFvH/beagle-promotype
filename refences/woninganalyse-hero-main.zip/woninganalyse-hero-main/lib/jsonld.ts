// Shared JSON-LD builders. Imported by route files that emit
// <script type="application/ld+json"> blocks for SEO/rich-results.
// Phase 3 of the SEO project; see seo-audit.md.

const SITE_URL = 'https://www.woninganalyse.nl'

// Stable @id so other schemas can reference the homepage Organization
// via { '@id': ORGANIZATION_ID } instead of duplicating the entity.
export const ORGANIZATION_ID = `${SITE_URL}/#organization`

interface BreadcrumbItem {
  name: string
  url: string
}

export function buildBreadcrumbList(items: BreadcrumbItem[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  }
}

interface ServiceOptions {
  name: string
  description: string
  serviceType: string
  url: string
  areaServed?: string
}

// Sibling JSON-LD to a tool's SoftwareApplication. Service captures the
// "Woninganalyse offers leadgeneratie-as-a-service" framing that
// SoftwareApplication alone doesn't express. Provider references the
// homepage Organization by @id.
export function buildService({ name, description, serviceType, url, areaServed = 'NL' }: ServiceOptions) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Service',
    name,
    description,
    serviceType,
    url,
    provider: { '@id': ORGANIZATION_ID },
    areaServed,
  }
}

interface BlogPostingOptions {
  title: string
  description: string
  slug: string
  date: string
  category: string
  relatedTool?: string
  wordCount: number
  author?: { name: string; role: string }
}

// FAQPage schema generator. Used by blog post pages (with the post.faqs
// array) and by tool pages (with their own per-tool FAQ list). Eligible
// for Google's "People Also Ask" SERP feature when content matches
// search intent. Each emitting page must render the same Q&A visibly so
// the JSON-LD reflects on-page content (Google requirement).
export function buildFaqPage(faqs: { q: string; a: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map((faq) => ({
      '@type': 'Question',
      name: faq.q,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.a,
      },
    })),
  }
}

// SEO-CONTEXT.md §5 mentions Product/Offer per tool — we deliberately
// don't add those here; SoftwareApplication.offers is the more correct
// schema for SaaS, and Google would treat duplicate Product+SaaS
// entries as schema confusion. Phase 3d intentionally limits this.
export function buildBlogPosting({
  title,
  description,
  slug,
  date,
  category,
  relatedTool,
  wordCount,
  author,
}: BlogPostingOptions) {
  const url = `${SITE_URL}/blog/${slug}`
  const keywords = [category, relatedTool].filter(Boolean) as string[]

  return {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: title,
    description,
    datePublished: date,
    image: `${url}/opengraph-image`,
    wordCount,
    articleSection: category,
    keywords: keywords.join(', '),
    author: author
      ? { '@type': 'Person', name: author.name, jobTitle: author.role }
      : { '@id': ORGANIZATION_ID },
    publisher: { '@id': ORGANIZATION_ID },
    mainEntityOfPage: url,
  }
}
