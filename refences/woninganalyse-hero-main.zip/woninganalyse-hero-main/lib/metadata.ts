import type { Metadata } from 'next'

const BASE_URL = 'https://www.woninganalyse.nl'
const OG_IMAGE = `${BASE_URL}/og-image.png`

export function buildMetadata(
  title: string,
  description: string,
  path: string,
  options?: Partial<Metadata>
): Metadata {
  const url = `${BASE_URL}${path}`

  return {
    title,
    description,
    alternates: {
      canonical: url,
    },
    openGraph: {
      title,
      description,
      url,
      siteName: 'Woninganalyse',
      locale: 'nl_NL',
      type: 'website',
      images: [
        {
          url: OG_IMAGE,
          width: 1200,
          height: 630,
          alt: 'Woninganalyse — AI-tools voor makelaars',
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [OG_IMAGE],
    },
    ...options,
  }
}
