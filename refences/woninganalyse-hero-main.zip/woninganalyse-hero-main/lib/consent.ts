// Cookie-based consent state shared across woninganalyse.nl subdomains.
// Setting Domain=.woninganalyse.nl makes the cookie readable on both
// www.woninganalyse.nl (this app) and platform.woninganalyse.nl, so a
// visitor who accepts on either surface is not re-prompted on the other.
//
// HANDOFF.md §8 documents the contract the platform repo must match:
// same cookie name, same value, same parent-domain scope.

export const CONSENT_COOKIE = 'cookie-consent'
export const CONSENT_VALUE = 'accepted'
export const CONSENT_EVENT = 'cookie-consent-accepted'

export function hasConsent(): boolean {
  if (typeof document === 'undefined') return false
  const match = document.cookie
    .split('; ')
    .find((c) => c.startsWith(`${CONSENT_COOKIE}=`))
  return match?.split('=')[1] === CONSENT_VALUE
}

export function grantConsent(): void {
  if (typeof document === 'undefined') return
  // On localhost / Vercel preview, the brand-domain attribute would be rejected;
  // fall back to a host-only cookie so the banner still works in dev.
  const isBrandHost =
    typeof window !== 'undefined' &&
    window.location.hostname.endsWith('woninganalyse.nl')
  const domainAttr = isBrandHost ? '; Domain=.woninganalyse.nl' : ''
  const secureAttr = isBrandHost ? '; Secure' : ''
  document.cookie =
    `${CONSENT_COOKIE}=${CONSENT_VALUE}; Path=/; Max-Age=31536000; SameSite=Lax${domainAttr}${secureAttr}`
}
