import { ImageResponse } from 'next/og'

export const OG_SIZE = { width: 1200, height: 630 }
export const OG_CONTENT_TYPE = 'image/png'

const PALETTES = {
  brand: {
    background: 'linear-gradient(135deg, #0D2EB8 0%, #1B4FFF 50%, #3B6FFF 100%)',
  },
  accent: {
    background: 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 35%, #FF6B35 100%)',
  },
}

interface OGOptions {
  title: string
  subtitle?: string
  badge?: string
  accent?: 'brand' | 'accent'
}

export function buildOGImage({ title, subtitle, badge, accent = 'brand' }: OGOptions) {
  const palette = PALETTES[accent]

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between',
          background: palette.background,
          padding: 80,
          fontFamily: 'system-ui, sans-serif',
        }}
      >
        {/* Brand row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div
            style={{
              width: 56,
              height: 56,
              background: 'rgba(255,255,255,0.18)',
              borderRadius: 12,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <span style={{ fontSize: 32, fontWeight: 700, color: '#fff' }}>W</span>
          </div>
          <span style={{ fontSize: 28, fontWeight: 600, color: 'rgba(255,255,255,0.9)' }}>
            Woninganalyse
          </span>
        </div>

        {/* Content */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {badge && (
            <div
              style={{
                display: 'flex',
                alignSelf: 'flex-start',
                background: 'rgba(255,255,255,0.18)',
                borderRadius: 999,
                padding: '8px 20px',
                marginBottom: 24,
                fontSize: 18,
                fontWeight: 600,
                color: '#fff',
                letterSpacing: '0.05em',
                textTransform: 'uppercase',
              }}
            >
              {badge}
            </div>
          )}
          <span
            style={{
              display: 'flex',
              fontSize: 76,
              fontWeight: 800,
              color: '#fff',
              lineHeight: 1.05,
              letterSpacing: '-0.02em',
              maxWidth: 1040,
            }}
          >
            {title}
          </span>
          {subtitle && (
            <span
              style={{
                display: 'flex',
                fontSize: 28,
                color: 'rgba(255,255,255,0.78)',
                lineHeight: 1.3,
                marginTop: 24,
                maxWidth: 900,
              }}
            >
              {subtitle}
            </span>
          )}
        </div>
      </div>
    ),
    { ...OG_SIZE }
  )
}
