// Inline segment used inside richText blocks. A plain string renders as
// text; an object renders as a link (Next <Link> for internal hrefs,
// <a target="_blank"> for external when external: true).
export type InlineSegment =
  | string
  | { text: string; href: string; external?: boolean }

export type ContentBlock =
  | { type: 'paragraph'; text: string }
  | { type: 'richText'; segments: InlineSegment[] }
  | { type: 'heading2'; text: string }
  | { type: 'heading3'; text: string }
  | { type: 'list'; items: string[] }
  | { type: 'callout'; text: string }

export interface BlogPostFaq {
  q: string
  a: string
}

export interface BlogAuthor {
  name: string
  role: string
}

export const DEFAULT_AUTHOR: BlogAuthor = {
  name: 'Daniel Verweij',
  role: 'Lead Data Analist bij Woninganalyse',
}

export interface BlogPost {
  slug: string
  title: string
  description: string
  date: string
  readTime: number
  category: string
  relatedTool: string
  relatedToolSlug: string
  relatedToolCta: string
  content: ContentBlock[]
  faqs?: BlogPostFaq[]
  author?: BlogAuthor
  image?: string
  imageAlt?: string
}

export const blogPosts: BlogPost[] = [
  {
    slug: 'woningwaarde-berekenen-2026',
    title: 'Hoe bereken je de woningwaarde in 2026?',
    description:
      'Een complete gids voor makelaars: van WOZ-waarde tot Kadasterdata. De vier methoden voor woningwaardering, wanneer u welke inzet, en hoe u uw cliënten een onderbouwde indicatie geeft.',
    date: '2026-01-10',
    readTime: 6,
    category: 'Woningwaardering',
    image: '/blog/woningwaarde-berekenen-2026.png',
    imageAlt: 'Huisjes op stijgende stapels munten — woningwaarde berekenen in 2026',
    relatedTool: 'Waardescan',
    relatedToolSlug: '/tools/waardescan',
    relatedToolCta: 'Bekijk Waardescan',
    content: [
      {
        type: 'paragraph',
        text: 'Voor uw cliënten is de woningwaarde één van de eerste vragen in het verkooptraject. Of het gesprek gaat over verkoopoptimalisatie, hypotheekruimte of een eerste oriëntatie — een onderbouwde waarde-indicatie is het startpunt van de adviesrelatie. In dit artikel zetten we de vier meest gebruikte methoden naast elkaar, zodat u weet wanneer welke geschikt is voor uw kantoor.',
      },
      {
        type: 'heading2',
        text: 'Methode 1: De WOZ-waarde als startpunt',
      },
      {
        type: 'paragraph',
        text: 'Elke woning in Nederland heeft een WOZ-waarde, vastgesteld door de gemeente. De waarde wordt jaarlijks bijgesteld op basis van verkoopcijfers in de buurt. Voor een eerste oriëntatie met een verkoper is de WOZ-waarde een geschikt vertrekpunt, maar houd er rekening mee dat hij doorgaans 5 tot 15% afwijkt van de actuele marktwaarde. Gemeenten kijken naar een peildatum in het verleden (1 januari van het voorgaande jaar), waardoor recente prijsbewegingen niet direct worden meegenomen. Communiceer de WOZ-waarde richting cliënten dus altijd als richtgetal, niet als marktwaarde.',
      },
      {
        type: 'heading2',
        text: 'Methode 2: Vergelijkbare verkopen via het Kadaster',
      },
      {
        type: 'paragraph',
        text: 'Het Kadaster registreert alle vastgoedtransacties in Nederland. Door recent verkochte vergelijkbare woningen in dezelfde buurt te selecteren — op oppervlak, bouwjaar en woningtype — bouwt u zelf een onderbouwde marktwaarde-indicatie op. Dit is de methode die professionele makelaars het meest gebruiken in de prijsbepalingsfase, en die het meest verdedigbare onderhandelingsverhaal richting verkopers oplevert.',
      },
      {
        type: 'list',
        items: [
          'Selecteer woningen binnen 500 meter die de afgelopen 12 maanden zijn verkocht',
          'Vergelijk op oppervlak (±15%), bouwjaar (±10 jaar) en woningtype',
          'Pas de waarde aan voor bijzondere kenmerken: tuin, garage, renovatieniveau',
          'Gebruik minimaal 3 vergelijkingsobjecten voor een betrouwbare indicatie',
        ],
      },
      {
        type: 'heading2',
        text: 'Methode 3: Online waardebepaling tools',
      },
      {
        type: 'paragraph',
        text: 'Moderne AI-tools combineren Kadasterdata, CBS-statistieken en actuele marktgegevens om in seconden een waarde-indicatie te genereren. Tools zoals Waardescan van Woninganalyse zet u op uw eigen website in als white-label widget: bezoekers vragen een gratis indicatie aan en u ontvangt hun gegevens als warme lead. De nauwkeurigheid ligt doorgaans binnen 5-8% van de uiteindelijke verkoopprijs — voldoende voor het eerste gesprek, niet voor een formele taxatie.',
      },
      {
        type: 'callout',
        text: 'In onze ervaring ontvangen makelaars die een gratis Waardescan aanbieden op hun website merkbaar meer leadaanvragen — in de orde van 15 tot 30 extra per maand, afhankelijk van websiteverkeer en regio. Bezoekers die hun woningwaarde opvragen zijn actief bezig met verkopen of kopen — dat zijn warme leads.',
      },
      {
        type: 'heading2',
        text: 'Methode 4: Een professionele taxateur',
      },
      {
        type: 'paragraph',
        text: 'Voor officiële doeleinden — zoals hypotheekaanvragen of erfeniskwesties — is een gecertificeerde taxatie verplicht. Een NWWI-gecertificeerde taxateur bezoekt de woning, beoordeelt de staat van onderhoud en stelt een formeel taxatierapport op. Dit rapport is juridisch bindend en zes maanden geldig. Verwijs uw cliënten hierheen wanneer hun bank of notaris erom vraagt — dit is geen taak die u als makelaar zelf vervult.',
      },
      {
        type: 'heading2',
        text: 'Welke methode kiest u wanneer?',
      },
      {
        type: 'paragraph',
        text: 'In de praktijk gebruikt u meerdere methoden naast elkaar. Voor het eerste klantgesprek is een online tool of de WOZ-waarde voldoende om de cliënt een gevoel te geven. Voor de prijsbepaling combineert u Kadasterdata met uw eigen marktkennis en bezichtigingsbevindingen. En voor de officiële taxatie verwijst u door naar een NWWI-collega. Welk gereedschap u inzet hangt af van waar in het traject u zit — en hoe snel uw cliënt antwoord verwacht.',
      },
      {
        type: 'paragraph',
        text: 'Met Waardescan van Woninganalyse plaatst u een gratis waarde-indicatie op uw eigen website, in uw merk en huisstijl. Bezoekers vragen een indicatie aan op basis van officiële Kadaster- en CBS-data; u ontvangt hun gegevens als lead, klaar voor opvolging.',
      },
    ],
  },
  {
    slug: 'ai-tools-voor-makelaars',
    title: 'AI voor makelaars: welke tools leveren echt iets op in 2026?',
    description:
      'Leadgeneratie, objectvragen en woningteksten — drie werkstromen waar AI u als makelaar meetbaar tijd bespaart. Een eerlijk overzicht van wat werkt, wat niet, en waar u begint.',
    date: '2026-04-30',
    readTime: 9,
    category: 'AI & Technologie',
    image: '/blog/ai-tools-voor-makelaars.png',
    imageAlt: 'Digitale stadshologram op tablet — AI-tools voor de vastgoedmarkt',
    relatedTool: 'Huistekst',
    relatedToolSlug: '/tools/huistekst',
    relatedToolCta: 'Probeer Huistekst gratis',
    content: [
      {
        type: 'richText',
        segments: [
          'U bent makelaar, geen IT-specialist. Toch hoort u steeds vaker dat AI uw kantoor productiever zou maken. Het probleem: de meeste artikelen over AI en vastgoed zijn vaag, Engelstalig of gaan over technologie die in Nederland niet beschikbaar is. Dit artikel is anders. We beginnen met twee werkstromen waar direct omzetpotentieel zit — ',
          { text: 'leads genereren via uw eigen website', href: '/tools/waardescan' },
          ' en ',
          { text: 'objectvragen buiten kantooruren afhandelen', href: '/tools/object-assistent' },
          ' — en kijken daarna naar ',
          { text: 'Funda-teksten schrijven', href: '/tools/huistekst' },
          '. Per onderdeel beoordelen we wat AI concreet verandert.',
        ],
      },
      {
        type: 'heading2',
        text: 'Wat bedoelen we met AI voor makelaars?',
      },
      {
        type: 'paragraph',
        text: 'AI voor makelaars is geen robot die uw werk overneemt. Het zijn gerichte softwaretools die één specifieke taak sneller of beter uitvoeren dan u handmatig kunt. Denk aan het genereren van een woningtekst op basis van kenmerken, het berekenen van een woningwaarde-indicatie uit Kadasterdata, of het beantwoorden van een objectvraag op basis van uw eigen brochure. De makelaar blijft de expert; de tool neemt het routinewerk over.',
      },
      {
        type: 'heading2',
        text: '1. Leadgeneratie: bezoekers omzetten in contactmomenten',
      },
      {
        type: 'richText',
        segments: [
          'De meeste makelaarssites hebben een contactformulier. Het probleem: slechts 1 à 2% van de bezoekers vult het in, omdat er geen reden is om dat te doen. Een ',
          { text: 'woningwaarde-widget', href: '/tools/waardescan' },
          ' draait de logica om. De bezoeker voert een adres in, ontvangt binnen seconden een indicatie op basis van Kadaster- en CBS-data, en laat pas daarna een e-mailadres achter voor het volledige rapport. Die volgorde maakt het verschil. U ontvangt contactgegevens van iemand die al inhoudelijk bezig is met een woning — een warme lead in plaats van een willekeurige aanvraag.',
        ],
      },
      {
        type: 'richText',
        segments: [
          'Hoe dat er precies uitziet en welke vier elementen het verschil maken tussen een widget die 5 leads oplevert en een die er 25 oplevert, hebben we uitgewerkt in een ',
          { text: 'apart artikel over leadgeneratie met een woningwaarde-tool', href: '/blog/leads-genereren-woningwaarde-tool' },
          '.',
        ],
      },
      {
        type: 'heading2',
        text: '2. Objectvragen beantwoorden — ook buiten kantooruren',
      },
      {
        type: 'richText',
        segments: [
          'Geïnteresseerden stellen vragen wanneer het hen uitkomt: \'s avonds, in het weekend, tussen vergaderingen door. Op dat moment is uw kantoor dicht. Een ',
          { text: 'AI-chatbot getraind op uw objectbrochure', href: '/tools/object-assistent' },
          ' beantwoordt die vragen direct — van VvE-bijdragen tot energielabel en bestemmingsplan. De chatbot verzint niets: hij antwoordt uitsluitend op basis van de documenten die u heeft aangeleverd. Bij vragen waar geen antwoord op staat, vraagt hij contactgegevens zodat u zelf kunt opvolgen.',
        ],
      },
      {
        type: 'richText',
        segments: [
          'Vijf concrete use cases — van administratieve vragen offloaden tot serieuze geïnteresseerden herkennen — beschrijven we in ',
          { text: 'het artikel over AI-chatbots voor uw objectpagina', href: '/blog/ai-chatbot-objectpagina-use-cases' },
          '.',
        ],
      },
      {
        type: 'heading2',
        text: '3. AI-woningteksten: van kenmerken naar Funda-klare tekst',
      },
      {
        type: 'richText',
        segments: [
          'Het schrijven van woningbeschrijvingen is voor veel makelaars een terugkerend tijdslek. Per woning besteedt u al snel 30 tot 45 minuten aan een tekst — en dat is voordat u begint aan een Engelse of Duitse versie voor internationale kopers. ',
          { text: 'Huistekst van Woninganalyse', href: '/tools/huistekst' },
          ' draait dat om: u vult de basiskenmerken in (type, oppervlak, kamers, bouwjaar, bijzonderheden) en ontvangt binnen 30 seconden een publicatieklare tekst in de door u gekozen stijl en taal. Niet als definitief product, maar als sterke basis die u in twee minuten redigeert naar uw eigen toon.',
        ],
      },
      {
        type: 'paragraph',
        text: 'Wanneer het werkt: bij het produceren van grote aantallen beschrijvingen, bij meertalige presentaties, en als u moeite heeft met de lege pagina. Wanneer het niet werkt: bij unieke high-end objecten waarvoor een persoonlijk geschreven verhaal een bewuste marketingkeuze is. In dat geval is de AI-tekst bruikbaar als ruwe opzet, niet als eindproduct.',
      },
      {
        type: 'heading2',
        text: 'Waar AI (nog) niet werkt voor makelaars',
      },
      {
        type: 'paragraph',
        text: 'Eerlijkheid hoort erbij. AI vervangt geen persoonlijk klantgesprek, geen bezichtiging, geen lokale marktkennis en geen onderhandelingservaring. Tools die beweren uw volledige verkooptraject te automatiseren overschatten de technologie en onderschatten uw vakmanschap. De grootste winst zit in het wegnemen van routinetaken zodat u meer tijd overhoudt voor de onderdelen van het vak waar uw expertise het verschil maakt.',
      },
      {
        type: 'heading2',
        text: 'Hoe kiest u de juiste AI-tool voor uw kantoor?',
      },
      {
        type: 'list',
        items: [
          'Begin met het probleem, niet met de technologie. Welke taak kost u het meest terugkerende tijd: teksten, leads of objectvragen?',
          'Kies één tool en implementeer die volledig voordat u de volgende toevoegt. Drie tools half geïmplementeerd leveren minder op dan één tool die goed draait.',
          'Meet het resultaat na de eerste maand: hoeveel leads extra, hoeveel uur bespaard, hoeveel sneller reageert u op vragen?',
          'Evalueer na drie maanden of de tool zich heeft terugverdiend — in tijd, leads of klanttevredenheid.',
        ],
      },
      {
        type: 'heading2',
        text: 'Samenvatting',
      },
      {
        type: 'richText',
        segments: [
          'AI voor makelaars is geen toekomstdroom — het zijn concrete tools die u vandaag al kunt inzetten op drie herkenbare werkstromen. ',
          { text: 'Huistekst', href: '/tools/huistekst' },
          ' voor Funda-teksten, ',
          { text: 'Waardescan', href: '/tools/waardescan' },
          ' voor leadgeneratie via uw eigen website, en ',
          { text: 'Object Assistent', href: '/tools/object-assistent' },
          ' voor objectvragen buiten kantooruren. De investering is laag, de drempel ook. Wat telt is niet of u AI gaat gebruiken, maar wanneer u begint — en of u dat doet met tools die voor de Nederlandse makelaarsmarkt zijn gebouwd.',
        ],
      },
      {
        type: 'callout',
        text: 'Wilt u zien hoe de tools zich gedragen op uw eigen kantoor? Vraag een persoonlijke demo aan waarin we de implementatie live laten zien, afgestemd op uw situatie.',
      },
    ],
    faqs: [
      {
        q: 'Welke AI-tools gebruikt een makelaar in de praktijk?',
        a: 'De drie meest ingezette AI-tools voor makelaars zijn: tekst-generatoren voor woningbeschrijvingen (zoals Huistekst), woningwaarde-widgets voor leadgeneratie (zoals Waardescan), en AI-chatbots die objectvragen beantwoorden op basis van de brochure (zoals Object Assistent). Daarnaast gebruiken grotere kantoren steeds vaker AI-functies binnen hun bestaande CRM voor lead scoring en opvolgautomatisering.',
      },
      {
        q: 'Kan AI woningteksten schrijven die goed genoeg zijn voor Funda?',
        a: 'Ja, mits u de output als basis behandelt en niet als definitief product. Een goede AI-tekstgenerator levert een professionele beschrijving op basis van woningkenmerken; u redigeert naar uw eigen stijl en voegt lokale kennis toe. Het resultaat is consistent, meertalig en in seconden klaar — geschikt voor Funda, uw eigen site en sociale media.',
      },
      {
        q: 'Hoe helpt AI bij leadgeneratie voor makelaars?',
        a: 'Door bezoekers van uw website een directe waarde-indicatie te bieden in ruil voor hun contactgegevens. In plaats van een passief contactformulier biedt u iets concreets aan — een onderbouwde woningwaarde op basis van Kadaster- en CBS-data. Dat verlaagt de drempel om gegevens achter te laten en levert inhoudelijk gekwalificeerde leads op.',
      },
      {
        q: 'Is AI voor makelaars geschikt voor kleine kantoren?',
        a: 'Ja. De tools werken onafhankelijk van kantoorgrootte. Het enige dat telt is dat u capaciteit heeft om leads op te volgen. Een zelfstandige makelaar met een actieve website profiteert net zo goed van een woningwaarde-widget of AI-tekstgenerator als een kantoor met tien medewerkers.',
      },
    ],
  },
  {
    slug: 'woningbeschrijving-schrijven-tips',
    title: 'Zo schrijft u een perfecte woningbeschrijving',
    description:
      'Praktische tips voor makelaars om overtuigende verkoopteksten te schrijven. Inclusief een stappenplan en hoe AI het proces versnelt.',
    date: '2026-02-07',
    readTime: 5,
    category: 'Copywriting',
    image: '/blog/woningbeschrijving-schrijven-tips.webp',
    imageAlt: 'Makelaar schrijft document terwijl zij een miniatuurwoning vasthoudt',
    relatedTool: 'Huistekst',
    relatedToolSlug: '/tools/huistekst',
    relatedToolCta: 'Bekijk Huistekst',
    content: [
      {
        type: 'paragraph',
        text: 'Een goede woningbeschrijving verkoopt niet alleen de vierkante meters — het verkoopt een gevoel, een levensstijl, een toekomst. Toch worstelen veel makelaars met het schrijven van teksten die écht raken. Te technisch, te generiek, of simpelweg te veel tijd kostten. In dit artikel geven we u een bewezen structuur en vertellen we hoe AI u daarbij kan helpen.',
      },
      {
        type: 'heading2',
        text: 'Waarom de eerste zin alles bepaalt',
      },
      {
        type: 'paragraph',
        text: 'Op Funda scannen kopers tientallen advertenties per sessie. De eerste twee zinnen bepalen of iemand stopt met scrollen. Vermijd vage openers zoals "Prachtige woning met veel ruimte" — die zijn nietszeggend. Begin in plaats daarvan met de unieke sfeer of locatievoordeel: "Wonen op steenworp afstand van het Vondelpark en toch de rust van een rustige woonstraat."',
      },
      {
        type: 'heading2',
        text: 'De ideale structuur van een woningbeschrijving',
      },
      {
        type: 'list',
        items: [
          'Opening (2-3 zinnen): sfeer, ligging, uniek karakter van de woning',
          'Indeling (3-4 zinnen): globale structuur, aantal kamers, verdiepingen',
          'Woonkamer en keuken: licht, materialen, aansluitingen, bijzonderheden',
          'Slaapkamers en badkamer: aantal, oppervlak, afwerking',
          'Buitenruimte: tuin, balkon, ligging (zon, privacy)',
          'Praktisch: parkeren, opslag, energielabel, bouwjaar',
          'Afsluiting: oproep tot actie of sfeerafsluiter',
        ],
      },
      {
        type: 'heading2',
        text: 'Veelgemaakte fouten',
      },
      {
        type: 'paragraph',
        text: 'Te veel technische specificaties achter elkaar maken een tekst droog en onleesbaar. Gebruik specificaties als ondersteuning van een verhaal, niet als vervanging ervan. Vermijd ook superlatieven die niet onderbouwd worden ("de mooiste tuin van de straat") — kopers zijn sceptisch en het ondermijnt uw geloofwaardigheid.',
      },
      {
        type: 'callout',
        text: 'Gemiddeld besteedt een makelaar 30-60 minuten per woningbeschrijving. Met Huistekst van Woninganalyse is een professionele tekst klaar in onder de 30 seconden — inclusief meertalige versies voor internationale kopers.',
      },
      {
        type: 'heading2',
        text: 'Hoe AI het proces versnelt',
      },
      {
        type: 'paragraph',
        text: 'Huistekst vraagt u om de basiskenmerken van de woning in te voeren: type, oppervlak, kamers, bouwjaar en bijzonderheden. Vervolgens genereert de AI een volledige beschrijving in de door u gekozen stijl — zakelijk, warm of luxe — en in de gewenste taal. U kunt de gegenereerde tekst direct gebruiken of finetunen naar uw eigen schrijfstijl.',
      },
      {
        type: 'paragraph',
        text: 'Het resultaat: consistente kwaliteit op elk object, zonder de mentale inspanning van een blanco pagina. Meer tijd voor bezichtigingen, minder tijd aan het bureau.',
      },
    ],
  },
  {
    slug: 'woz-waarde-vs-marktwaarde',
    title: 'WOZ-waarde vs. marktwaarde: wat is het verschil?',
    description:
      'Makelaars en huiseigenaren halen WOZ-waarde en marktwaarde regelmatig door elkaar. Dit artikel legt het verschil helder uit met praktische voorbeelden.',
    date: '2026-01-24',
    readTime: 5,
    category: 'Woningwaardering',
    relatedTool: 'Waardescan',
    relatedToolSlug: '/tools/waardescan',
    relatedToolCta: 'Vraag een gratis Waardescan aan',
    content: [
      {
        type: 'paragraph',
        text: 'Vraag tien mensen wat hun huis waard is en de helft noemt de WOZ-waarde. Dat is begrijpelijk — de gemeente communiceert die waarde jaarlijks via de WOZ-beschikking. Maar de WOZ-waarde is iets heel anders dan wat een koper bereid is te betalen. Dit onderscheid is cruciaal voor iedereen die overweegt te kopen of verkopen.',
      },
      {
        type: 'heading2',
        text: 'Wat is de WOZ-waarde?',
      },
      {
        type: 'paragraph',
        text: 'De Waardering Onroerende Zaken (WOZ) is een officiële waardebepaling door de gemeente, gebaseerd op een peildatum van 1 januari van het voorgaande jaar. De WOZ-waarde wordt gebruikt als grondslag voor belastingen: onroerendezaakbelasting (OZB), erfbelasting en vermogensrendementsheffing. De gemeente baseert de waarde op verkoopcijfers van vergelijkbare woningen in dezelfde buurt.',
      },
      {
        type: 'heading2',
        text: 'Wat is de marktwaarde?',
      },
      {
        type: 'paragraph',
        text: 'De marktwaarde is het bedrag waartegen een woning van eigenaar zou wisselen tussen een bereidwillige koper en een bereidwillige verkoper, beide handelend met kennis van zaken en zonder dwang. De marktwaarde is het resultaat van vraag en aanbod op het moment van verkoop — en kan dus sterk fluctueren met de marktomstandigheden.',
      },
      {
        type: 'heading2',
        text: 'Waarom wijken ze van elkaar af?',
      },
      {
        type: 'list',
        items: [
          'Peildatum: de WOZ gebruikt historische data, de markt reageert in real-time',
          'Individuele staat: een gerenoveerde keuken of badkamer verhoogt de marktwaarde direct, maar wordt pas later in WOZ verwerkt',
          'Locatiefactoren: nieuwe voorzieningen, bestemmingsplanwijzigingen en buurtreputatie beïnvloeden de markt sneller',
          'Overbieden: in een gespannen markt wordt ruim boven de WOZ-waarde betaald',
        ],
      },
      {
        type: 'callout',
        text: 'Praktijkvoorbeeld: een appartement in Amsterdam-West had in 2024 een WOZ-waarde van € 380.000. Het verkocht uiteindelijk voor € 445.000 — 17% boven de WOZ. In een rustiger markt buiten de Randstad zijn de verschillen kleiner.',
      },
      {
        type: 'heading2',
        text: 'Wanneer gebruikt u welke waarde?',
      },
      {
        type: 'paragraph',
        text: 'Gebruik de WOZ-waarde voor: belastingaangiftes, bezwaar tegen gemeentelijke aanslagen, en als grove indicator. Gebruik de marktwaarde voor: verkoopstrategie, hypotheekaanvraag, en onderhandelingen. Een actuele marktwaarde-indicatie op basis van Kadasterdata is altijd nauwkeuriger dan de WOZ voor commerciële doeleinden.',
      },
      {
        type: 'heading2',
        text: 'Bezwaar maken tegen de WOZ',
      },
      {
        type: 'paragraph',
        text: 'Vindt u de WOZ-waarde te hoog (en betaalt u daardoor te veel belasting)? U kunt binnen zes weken na ontvangst bezwaar maken bij de gemeente. Onderbouw uw bezwaar met recente verkoopprijzen van vergelijkbare woningen. Een gratis Waardescan van Woninganalyse kan hierbij als referentie dienen.',
      },
    ],
  },
  {
    slug: 'leads-genereren-woningwaarde-tool',
    title: 'Hoe genereert u leads met een woningwaarde-tool op uw website?',
    description:
      'Contactformulieren converteren 1–2%. Makelaars die een woningwaarde-widget plaatsen zien dat aantal doorgaans verdubbelen. Lees de vier elementen die het verschil maken.',
    date: '2026-03-07',
    readTime: 10,
    category: 'Leadgeneratie',
    relatedTool: 'Waardescan',
    relatedToolSlug: '/tools/waardescan',
    relatedToolCta: 'Bekijk de Waardescan',
    content: [
      {
        type: 'paragraph',
        text: 'Een typisch makelaarskantoor stuurt elke maand honderden bezoekers naar zijn website — uit Google, sociale media, doorverwijzingen of betaalde advertenties. Die bezoekers landen op een mooi vormgegeven aanbodpagina, scrollen wat door, klikken misschien op één woning, en sluiten dan het tabblad. Slechts 1 à 2% vult een contactformulier in. De rest verdwijnt zonder spoor. Het probleem is meestal niet desinteresse — bezoekers oriënteren zich gemiddeld 2 tot 6 maanden voordat ze een makelaar inschakelen. Het probleem is dat een leeg formulier hun niets biedt om in te vullen. Een woningwaarde-tool draait die dynamiek om door eerst een resultaat te leveren voordat u om gegevens vraagt.',
      },
      {
        type: 'heading2',
        text: 'De rekensom: waarom een contactformulier niet meer voldoet',
      },
      {
        type: 'paragraph',
        text: 'Stel u krijgt 1.000 unieke bezoekers per maand op uw site. Daarvan vult 1,5% het contactformulier in — 15 leads. Bij goede opvolging worden daar 4 of 5 gekwalificeerde gesprekken van, en 1 á 2 daadwerkelijke klanten. Dat zijn realistische cijfers voor een Nederlandse makelaarsite. Maar wat gebeurt er met de overige 985 bezoekers? Ze hebben uw aanbod gezien, soms zelfs een specifieke woning bekeken, maar u weet niet wie ze zijn. U kunt ze niet opvolgen. U weet niet of ze ooit terugkomen. En u weet niet welke van die 985 bezoekers eigenlijk meer geïnteresseerd was dan de 15 die wél het formulier invulden — zelf-selectie via een formulier is geen goede filter, omdat juist mensen in de oriëntatiefase die filter overslaan. Een woningwaarde-widget vangt precies die eerdere oriëntatiefase op.',
      },
      {
        type: 'list',
        items: [
          'Het formulier vraagt om persoonlijke gegevens zonder concrete tegenprestatie',
          'Bezoekers in de oriëntatiefase zijn nog niet bereid om contact op te nemen',
          'U heeft geen inzicht in welke bezoekers serieus geïnteresseerd zijn',
          'Concurrerende sites die wél direct iets bieden, vangen dezelfde leads weg',
        ],
      },
      {
        type: 'heading2',
        text: 'Wat een woningwaarde-tool anders doet',
      },
      {
        type: 'richText',
        segments: [
          'Een waardescan-widget op uw website draait de logica om. In plaats van te vragen om gegevens, biedt u eerst een resultaat: de bezoeker voert zijn adres in en ontvangt binnen seconden een onderbouwde indicatie van de woningwaarde. Pas daarna vraagt u om een e-mailadres — om het volledige rapport te versturen. Die volgorde maakt het verschil. Bezoekers krijgen direct iets bruikbaars, en hun gegevens achterlaten voelt als een eerlijke uitruil. ',
          { text: 'De Waardescan van Woninganalyse', href: '/tools/waardescan' },
          ' werkt precies op deze manier: postcode en huisnummer in stap 1, indicatie in stap 2, e-mail in stap 3 om het volledige rapport per mail te ontvangen.',
        ],
      },
      {
        type: 'richText',
        segments: [
          'De waarde-indicatie komt niet uit de lucht vallen. Een professionele woningwaarde-tool combineert officiële Nederlandse databronnen — ',
          { text: 'het Kadaster', href: 'https://www.kadaster.nl', external: true },
          ' (BAG-gegevens en historische transactieprijzen), ',
          { text: 'het CBS', href: 'https://www.cbs.nl', external: true },
          ' (woningmarktstatistieken per buurt en gemeente) en actuele transactiedata uit de regio. Voor de bezoeker betekent dat een geloofwaardige indicatie binnen 30 seconden, niet een gokje. Voor u betekent het dat de lead die binnenkomt al inhoudelijk gekwalificeerd is. U weet om welk pand het gaat, welke waarde-orde de bezoeker in zijn hoofd heeft, en u kunt het opvolggesprek beginnen op een concreet niveau in plaats van bij nul.',
        ],
      },
      {
        type: 'heading2',
        text: 'De vier elementen van een converterende widget',
      },
      {
        type: 'paragraph',
        text: 'Niet elke woningwaarde-tool werkt even goed. De ervaring met makelaars die zo\'n tool plaatsen wijst op vier elementen die telkens terugkeren in goed converterende widgets — en die ontbreken in widgets die genegeerd worden. Het verschil tussen een widget die 25 leads per maand oplevert en een die er 5 oplevert zit in deze details.',
      },
      {
        type: 'heading3',
        text: '1. Lage drempel',
      },
      {
        type: 'paragraph',
        text: 'Vraag in stap 1 zo weinig mogelijk. Een postcode en huisnummer is genoeg om een eerste indicatie te tonen — niet meer. Een formulier dat begint met naam, telefoonnummer en e-mail jaagt het grootste deel van de bezoekers weg voordat ze überhaupt iets te zien krijgen. Pas wanneer de waarde-indicatie verschijnt, vraagt u het e-mailadres voor het volledige rapport. Op dat moment heeft de bezoeker al iets in handen waarop hij doorklikt — de inruil voelt eerlijk. Vraag in die laatste stap ook niet om optionele velden zoals "beroep" of "jaarinkomen"; die voegen voor uw opvolging niets toe en jagen mensen alsnog weg op het laatste moment.',
      },
      {
        type: 'heading3',
        text: '2. Direct resultaat, geen "we sturen het later"',
      },
      {
        type: 'richText',
        segments: [
          'Wachten doodt conversie. Een professionele woningwaarde-tool levert binnen 30 seconden een uitkomst — niet morgen per e-mail, niet "we nemen contact op". Bezoekers verwachten dezelfde snelheid die ze gewend zijn van Google Maps of ',
          { text: 'Funda', href: 'https://www.funda.nl', external: true },
          '. Een widget die er twee minuten over doet of pas een rapport stuurt nadat iemand het kantoor heeft gebeld, vertraagt het proces zodanig dat een groot deel van de aanvragen halverwege afhaakt. De bezoeker wil direct een antwoord; geef het hem. Een follow-up per e-mail kan altijd nog, maar pas nadat hij de eerste indicatie al heeft gezien.',
        ],
      },
      {
        type: 'heading3',
        text: '3. Eerlijke bandbreedte, geen schijnprecisie',
      },
      {
        type: 'paragraph',
        text: 'Een waardescan die exact één bedrag noemt — "€ 387.450" — wekt argwaan, en terecht. Niemand kan zonder bezichtiging en taxatie tot op de euro nauwkeurig zijn. Toon daarom een bandbreedte: "€ 380.000 – € 410.000", met een korte uitleg waarom de range bestaat (afhankelijkheid van staat, energielabel, bijzonderheden). Bezoekers vertrouwen een eerlijke marge meer dan een nepprecisie. Het maakt het ook makkelijker om in een opvolggesprek te zeggen: "Voor een definitieve waarde komen we langs voor een korte rondgang" — die boodschap landt soepel bij iemand die al een redelijke bandbreedte heeft gezien. Een tool die doet alsof hij precies weet wat een woning waard is, schiet zichzelf in de voet zodra de werkelijke verkoopprijs afwijkt.',
      },
      {
        type: 'heading3',
        text: '4. Uw eigen merk, niet dat van de leverancier',
      },
      {
        type: 'richText',
        segments: [
          'Bezoekers blijven op uw site, niet op die van de tool-leverancier. Een widget met uw logo, uw kleur en uw domeinnaam houdt het bezoek binnen uw merkidentiteit; een widget die plotseling een ander logo toont voelt voor de bezoeker als een omleiding, en omleidingen verlagen vertrouwen. Dat is in B2C-vastgoed extra relevant: lokaal vertrouwen is fragiel. Witlabel-implementatie hoeft daarvoor niet gelijk full-custom te zijn met eigen domein en bouwwerk. Een branded widget op een bewezen product is voor de meeste kantoren economischer en levert hetzelfde gevoel van eigen merk op.',
        ],
      },
      {
        type: 'callout',
        text: 'Makelaars die de Waardescan plaatsen rapporteren doorgaans 15 tot 30 extra contactaanvragen per maand op een site met circa 1.000 bezoekers — vergeleken met de 12 à 15 die ze daarvoor uit hun contactformulier haalden. De totale conversie verdubbelt in veel gevallen, en de bijkomende leads zijn gemiddeld inhoudelijk beter omdat het object al bekend is bij binnenkomst.',
      },
      {
        type: 'heading2',
        text: 'Wat u moet meten in de eerste maand',
      },
      {
        type: 'paragraph',
        text: 'Een widget plaatsen is geen einde, maar een begin. De eerste 30 dagen zijn cruciaal voor het bijstellen van uw opvolgproces. Vier metrics geven u snel een eerlijk beeld van wat de tool werkelijk oplevert — en welke knoppen u kunt bijdraaien.',
      },
      {
        type: 'list',
        items: [
          'Aantal aanvragen per dag — fluctueert met verkeer; richt u op de trendlijn over 14 dagen, niet op losse pieken',
          'Conversie van aanvraag naar opvolggesprek binnen 24 uur — streef naar minimaal 60%; alles eronder duidt op een gat in uw opvolgflow',
          'Conversie van opvolggesprek naar afspraak op locatie — gemiddeld 25–35% in goed lopende kantoren',
          'Aandeel leads dat resulteert in een verkoop binnen 6 maanden — afhankelijk van marktsegment 5–15%; dit is de echte ROI-meter',
        ],
      },
      {
        type: 'heading2',
        text: 'Wanneer het géén goede match is',
      },
      {
        type: 'paragraph',
        text: 'Een woningwaarde-tool is geen wondermiddel voor elk kantoor. Werkt u uitsluitend in het topsegment, dan zit uw doelgroep niet op een online indicatie te wachten — daar gaat het om persoonlijke benadering, discretie en ervaring. Heeft u geen capaciteit om binnen één werkdag een lead op te volgen, dan creëert u alleen frustratie: bezoekers verwachten snelheid, krijgen die niet, en de naam van uw kantoor blijft hangen als "die makelaar die nooit terugbelt". En in zeer kleine markten — een dorp van enkele duizenden inwoners — is het verkeer simpelweg te laag om de tool zinvol te laten draaien. In die scenario\'s is een persoonlijk netwerk effectiever dan een widget. Voor de meerderheid van Nederlandse makelaars werkt een waardescan wél, mits u deze vier elementen serieus neemt.',
      },
      {
        type: 'heading2',
        text: 'Klaar om te beginnen',
      },
      {
        type: 'richText',
        segments: [
          'De drempel om een woningwaarde-tool te plaatsen is laag: één regel code in uw website, een keuze voor uw merkkleur en logo, en u staat live. Geen IT-project, geen langdurige implementatie. Voor de meeste makelaars geldt dat de tool binnen één maand zichzelf terugverdient — al was het maar door één extra verkoopgesprek dat zonder de widget nooit was ontstaan. Wilt u zien hoe de Waardescan op uw eigen site werkt, met uw eigen merk, voordat u commitment maakt? ',
          { text: 'Plan een persoonlijke demo', href: '/demo' },
          ' waarin we de implementatie live laten zien.',
        ],
      },
    ],
    faqs: [
      {
        q: 'Hoe nauwkeurig is een online woningwaarde-tool?',
        a: 'Een goede tool zit gemiddeld binnen 5 tot 8% van de uiteindelijke verkoopprijs, op basis van Kadaster- en CBS-data plus actuele regionale transacties. Voor een formele taxatie blijft een gecertificeerd taxateur (NWWI/NRVT) noodzakelijk, maar voor een eerste indicatie en lead-kwalificatie is de bandbreedte ruim voldoende.',
      },
      {
        q: 'Concurreer ik niet met mezelf als ik gratis indicaties weggeef?',
        a: 'Nee. Een online indicatie is een vertrekpunt, geen vervanging voor uw expertise. De bezoeker krijgt een grove richting; pas in een persoonlijk gesprek of bezichtiging kunt u factoren meewegen die geen tool kan zien: staat van onderhoud, sfeer, lokale buurtdynamiek, de vraagprijs-strategie. De tool zorgt juist dat het gesprek met u inhoudelijk start in plaats van bij nul.',
      },
      {
        q: 'Hoe veel tijd kost het om de widget op mijn site te plaatsen?',
        a: 'Voor een standaard CMS (WordPress, Webflow, Wix, Squarespace) of een zelfgebouwde site is het één regel code in de HTML — typisch 5 tot 10 minuten werk. De configuratie van logo, kleur en welkomsttekst doet u in een dashboard; geen technische kennis nodig. De totale opzet duurt zelden langer dan 30 minuten.',
      },
      {
        q: 'Werkt het ook voor kleinere makelaarskantoren?',
        a: 'Ja, mits u capaciteit heeft om elke lead binnen één werkdag op te volgen. De tool zelf maakt geen onderscheid tussen een eenmanskantoor en een groot bureau. De bottleneck is bijna altijd de opvolg-snelheid: bezoekers verwachten een reactie binnen 24 uur. Heeft u die capaciteit niet, dan is het beter om de widget pas later te plaatsen of er een opvolg-routine omheen te bouwen.',
      },
    ],
  },
  {
    slug: 'ai-chatbot-objectpagina-use-cases',
    title: 'AI-chatbot voor uw objectpagina: 5 use cases die leads opleveren',
    description:
      'Een AI-chatbot op uw objectpagina vangt vragen op buiten kantooruren en filtert serieuze geïnteresseerden uit ruis. Vijf concrete toepassingen — en wat een chatbot níét kan.',
    date: '2026-04-24',
    readTime: 10,
    category: 'AI & Technologie',
    relatedTool: 'Object Assistent',
    relatedToolSlug: '/tools/object-assistent',
    relatedToolCta: 'Bekijk Object Assistent',
    content: [
      {
        type: 'paragraph',
        text: 'Bezoekers van Funda en uw eigen objectpagina\'s stellen vragen op het moment dat hen uitkomt — \'s avonds laat, in het weekend, tussen ander werk door. Het probleem is dat uw kantoor op die momenten dicht is. De vraag blijft hangen, de bezoeker kijkt verder, en een potentieel goede lead verdampt. Een AI-chatbot getraind op uw eigen objectdocumentatie verandert dat: 24/7 beschikbaar, accuraat op basis van wat u heeft aangeleverd, zonder verzonnen antwoorden. Hieronder vijf concrete use cases — gevolgd door wat u nodig heeft om te beginnen en wat een chatbot eerlijk gezegd níét kan.',
      },
      {
        type: 'heading2',
        text: 'Hoe een object-chatbot werkt (kort)',
      },
      {
        type: 'paragraph',
        text: 'U uploadt de objectbrochure en eventuele bijlagen — VvE-stukken, bestemmingsplan, energielabel-rapport, plattegronden. De AI leest die documenten en genereert antwoorden op basis van uitsluitend wat erin staat. Geen verzonnen feiten, geen aanvullingen uit het algemene internet. Wanneer een bezoeker een vraag stelt waar in de documentatie geen antwoord op staat, geeft de chatbot dat eerlijk aan en verzamelt de gegevens zodat u zelf kunt opvolgen. Het is, in essentie, een 24/7 beschikbare versie van uzelf — maar beperkt tot exact dezelfde feiten die u op een rondleiding zou vertellen.',
      },
      {
        type: 'heading2',
        text: 'Use case 1 — Vragen buiten kantooruren afhandelen',
      },
      {
        type: 'paragraph',
        text: 'Het meest tastbare voordeel. Een geïnteresseerde koper kijkt zaterdagavond naar een woning in zijn doel-buurt en heeft één vraag: is er een CV-ketel of stadsverwarming? Op een gewone site moet hij wachten tot maandag of een mailtje sturen waarvan onduidelijk is wanneer het wordt beantwoord. Met een chatbot krijgt hij binnen 10 seconden het antwoord uit de brochure ("Stadsverwarming via Vattenfall, vaste leverancier"). Voor u is het verschil dat een aanvraag die u anders pas op maandag had gezien, nu direct wordt afgehandeld — vaak zonder dat u tijd kwijt bent. En als de bezoeker daarna een vervolgvraag heeft die níét in de brochure staat, vraagt de chatbot zijn gegevens en zet hem op uw lijst voor opvolging. Volgens analyses van Funda-verkeer vindt circa 35–40% van de objectpagina-bezoeken plaats buiten kantooruren; zonder een chatbot mist u feitelijk de helft van uw potentiële vragen-momenten.',
      },
      {
        type: 'heading2',
        text: 'Use case 2 — Diepe technische details die u zelf moet opzoeken',
      },
      {
        type: 'richText',
        segments: [
          'Bestemmingsplan, isolatiewaarden, EPC-cijfers, fundering, soort dak. Vragen waarop het antwoord ergens diep in een rapport staat dat u dagelijks niet bij de hand heeft. In een telefoongesprek zegt u typisch: "Goede vraag, ik kijk het na en bel terug." De chatbot doet dat opzoekwerk in seconden — en kan zelfs uitleg geven uit het rapport ("Energielabel B met spouwmuurisolatie en HR++-glas, gerenoveerd in 2019"). De bezoeker krijgt zijn antwoord direct, en u hoeft niet 5 minuten in een PDF te bladeren voor wat een routinevraag had moeten zijn. Op platforms als ',
          { text: 'Funda', href: 'https://www.funda.nl', external: true },
          ' worden bezoekers verwend met snelle informatie; uw kantoor moet daarop aansluiten of u verliest hen aan een concurrent die wél binnen seconden antwoordt.',
        ],
      },
      {
        type: 'heading2',
        text: 'Use case 3 — Serieuze geïnteresseerden onderscheiden',
      },
      {
        type: 'richText',
        segments: [
          'Niet elke bezoeker is even serieus. Sommigen kijken voor de aardigheid; anderen overwegen daadwerkelijk een bod. Het verschil zit vaak in de aard van de vragen die ze stellen. Vragen over "is er ergens een toilet?" zijn algemeen oriënterend; vragen over "wanneer is de overdracht mogelijk en kan ik vóór de oplevering al bezichtigen met een aannemer?" duiden op een serieuze intentie. De chatbot herkent dat type vragen en kan op basis daarvan vragen om contactgegevens, of de chat-historie als prioriteit-lead in uw dashboard zetten. U bespaart tijd door eerst de echte kandidaten te bellen. ',
          { text: 'Hoe deze lead-kwalificatie zich verhoudt tot een bredere lead-strategie', href: '/blog/leads-genereren-woningwaarde-tool' },
          ' hebben we apart uitgewerkt — chatbot-leads en widget-leads versterken elkaar.',
        ],
      },
      {
        type: 'heading2',
        text: 'Use case 4 — Administratieve vragen offloaden',
      },
      {
        type: 'paragraph',
        text: 'Repetitieve vragen vreten tijd. VvE-bijdrage, parkeerregeling, lasten per maand, oppervlakte van de berging, of er een lift is — al deze vragen krijgt u tien keer per object. Elke beantwoording is op zich een minuut, maar over een maand telt het op tot uren. Een chatbot beantwoordt deze vragen direct uit uw documentatie. U merkt het pas in de tweede maand: het volume aan kleine vragen op uw e-mail en telefoon neemt zichtbaar af, terwijl de échte gesprekken (bezichtigingen, biedingen, onderhandelingen) gewoon doorgaan. Voor een kantoor met 10 actieve objecten betekent dat al snel 5 tot 8 uur per maand teruggewonnen. Belangrijker dan de tijdwinst zelf is wat ermee mogelijk wordt: in plaats van administratief reageren op standaardvragen, kunt u die uren in proactieve klantbenadering steken — bestaande relaties bellen, nieuwe woningen acquireren, of strategischer omgaan met uw aanbodselectie. Een chatbot levert in feite niet alleen tijdwinst, maar herverdeelt waar uw aandacht naartoe gaat.',
      },
      {
        type: 'heading2',
        text: 'Use case 5 — Emotionele vragen met empathie',
      },
      {
        type: 'paragraph',
        text: '"Is de buurt rustig?" "Wonen er gezinnen?" "Hoe is het gesteld met de scholen in de buurt?" Dit type vraag is gevoeliger — het gaat over leefkwaliteit, niet over feiten. Een goede chatbot beantwoordt op basis van CBS-buurtdata (gemiddelde leeftijd, type huishoudens, voorzieningen) zonder zich te wagen aan oordelen over veiligheid of "geschiktheid". Belangrijk is dat de bot eerlijk verwijst naar een persoonlijk gesprek voor het emotionele deel: "Voor een persoonlijke indruk van het wonen daar adviseer ik een korte rondleiding — laat uw gegevens achter en we plannen iets in." Zo blijft de menselijke laag intact terwijl u toch 24/7 een gesprek opent. De chatbot vervangt u niet; hij houdt de bezoeker betrokken tot u beschikbaar bent. In de praktijk is dit type vraag een uitstekend signaal voor lead-kwalificatie: bezoekers die naar buurtbeleving vragen, bevinden zich verder in het beslissingsproces dan bezoekers die alleen om vierkante meters vragen.',
      },
      {
        type: 'callout',
        text: 'Een gemiddeld actief object trekt 30 à 50 chats per maand — waarvan ongeveer 60% een direct antwoord uit de documentatie krijgt zonder uw tussenkomst, 30% leidt tot een vervolgvraag waar u op opvolgt, en 10% een serieuze leadaanvraag wordt. Voor een kantoor met 10 actieve objecten betekent dat 30 à 50 leads per maand die anders nooit waren binnengekomen.',
      },
      {
        type: 'heading2',
        text: 'Wat u nodig heeft om te beginnen',
      },
      {
        type: 'paragraph',
        text: 'Minder dan u denkt. De objectbrochure die u toch al maakt, eventueel aangevuld met VvE-stukken en het energielabel-rapport. Dat is voldoende om te starten. De chatbot leert in onder de 10 minuten van die documenten en is direct bruikbaar. Het plaatsen op de objectpagina is één regel code — vergelijkbaar met hoe u een Google Maps-embed of een YouTube-video toevoegt. Voor een gemiddeld kantoor: 5 minuten per object voor de upload, 5 minuten voor de installatie. De configuratie van toon en welkomstbericht doet u in een dashboard zonder technische kennis.',
      },
      {
        type: 'heading2',
        text: 'Wat een chatbot níét kan',
      },
      {
        type: 'paragraph',
        text: 'Eerlijkheid hoort erbij. Een AI-chatbot doet géén onderhandelingen, geeft geen prijsindicatie buiten wat in de brochure staat, en geeft geen juridisch advies. Hij houdt zich strikt aan de documentatie die u heeft aangeleverd, en bij gevoelige onderwerpen — biedingen, financiering, het persoonlijke verhaal van de verkoper — verwijst hij door naar uw kantoor. Dat is geen beperking; dat is een ontwerpkeuze. Een chatbot die wel zou onderhandelen, zou onbetrouwbaar zijn omdat hij feiten zou moeten verzinnen die hij niet heeft. Door de scope strikt te houden, blijft de output betrouwbaar — en blijven de waardevolle gesprekken bij u.',
      },
      {
        type: 'richText',
        segments: [
          'Wilt u zien hoe ',
          { text: 'Object Assistent', href: '/tools/object-assistent' },
          ' zich gedraagt op een echt objectvoorbeeld, met uw eigen brochure als basis? ',
          { text: 'Plan een persoonlijke demo', href: '/demo' },
          '. We laten u live de chatbot trainen op een eigen object, en u kunt zelf vragen stellen om te ervaren hoe accuraat de antwoorden zijn voordat u een commitment maakt.',
        ],
      },
    ],
    faqs: [
      {
        q: 'Verzint de chatbot wel eens antwoorden?',
        a: 'Goed ontworpen object-chatbots verzinnen niets. Ze antwoorden uitsluitend op basis van de documenten die u heeft aangeleverd. Wanneer een vraag wordt gesteld waar geen brondocument antwoord op geeft, zegt de chatbot dat eerlijk en vraagt om contactgegevens voor opvolging. Het verschil tussen een hallucinerende algemene chatbot en een professionele object-chatbot zit precies in deze ontwerpkeuze.',
      },
      {
        q: 'Hoe snel is de chatbot na uploaden bruikbaar?',
        a: 'Voor een standaard objectbrochure (10–25 pagina\'s) is de chatbot binnen 10 minuten getraind en bruikbaar. Bijlagen zoals VvE-documenten of plattegronden kunt u tegelijk uploaden. Het systeem indexeert de inhoud zelf; u hoeft de tekst niet handmatig in te voeren of antwoorden vooraf te scripten.',
      },
      {
        q: 'Wat gebeurt er met de chatgeschiedenis en bezoekersgegevens?',
        a: 'Chatgeschiedenis is privé per object en zichtbaar in uw eigen dashboard. Bezoekers die hun gegevens achterlaten worden als lead in datzelfde dashboard opgeslagen. Conform AVG: u bent verwerkingsverantwoordelijke, wij zijn verwerker; we tekenen daarvoor een verwerkersovereenkomst. Gegevens van bezoekers worden niet gedeeld met derden.',
      },
      {
        q: 'Kan ik de chatbot zelf stoppen of antwoorden corrigeren?',
        a: 'Ja, op meerdere manieren. U kunt de chatbot per object aan- of uitzetten in uw dashboard, en u kunt de onderliggende documenten bewerken of vervangen — de chatbot werkt altijd op de meest recente versie. Wilt u een specifiek antwoord aanpassen? Doe dat door het bronde document te updaten, niet door het antwoord te overschrijven; zo blijft de logica consistent.',
      },
    ],
  },
]

export function getBlogPost(slug: string): BlogPost | undefined {
  return blogPosts.find((post) => post.slug === slug)
}

export function getAllSlugs(): string[] {
  return blogPosts.map((post) => post.slug)
}

function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length
}

// Scoring: same category = 2 points, same relatedTool = 1 point, sum.
// Tiebreaker: most recent post date wins. Excludes self. Always returns
// up to `limit` posts even if all scores are 0 (date-only ranking).
export function getRelatedPosts(post: BlogPost, limit = 2): BlogPost[] {
  const scored = blogPosts
    .filter((p) => p.slug !== post.slug)
    .map((p) => {
      let score = 0
      if (p.category === post.category) score += 2
      if (p.relatedTool === post.relatedTool) score += 1
      return { post: p, score }
    })
    .sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score
      return new Date(b.post.date).getTime() - new Date(a.post.date).getTime()
    })
  return scored.slice(0, limit).map((s) => s.post)
}

export function getPostWordCount(post: BlogPost): number {
  const contentWords = post.content.reduce((sum, block) => {
    switch (block.type) {
      case 'paragraph':
      case 'heading2':
      case 'heading3':
      case 'callout':
        return sum + countWords(block.text)
      case 'richText':
        return (
          sum +
          block.segments.reduce(
            (s, seg) => s + countWords(typeof seg === 'string' ? seg : seg.text),
            0
          )
        )
      case 'list':
        return sum + block.items.reduce((s, item) => s + countWords(item), 0)
    }
  }, 0)
  const faqWords =
    post.faqs?.reduce((sum, faq) => sum + countWords(faq.q) + countWords(faq.a), 0) ?? 0
  return contentWords + faqWords
}
