'use server'

export interface ContactFormState {
  status: 'idle' | 'success' | 'error'
  message: string
}

type Intent = 'contact' | 'demo'

export async function sendContactForm(
  prevState: ContactFormState,
  formData: FormData
): Promise<ContactFormState> {
  const naam = formData.get('naam')?.toString().trim() ?? ''
  const email = formData.get('email')?.toString().trim() ?? ''
  const kantoor = formData.get('kantoor')?.toString().trim() ?? ''
  const telefoon = formData.get('telefoon')?.toString().trim() ?? ''
  const bericht = formData.get('bericht')?.toString().trim() ?? ''
  const intentRaw = formData.get('intent')?.toString().trim() ?? 'contact'
  const intent: Intent = intentRaw === 'demo' ? 'demo' : 'contact'

  // Basic validation
  if (!naam || naam.length < 2) {
    return { status: 'error', message: 'Vul uw naam in.' }
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { status: 'error', message: 'Vul een geldig e-mailadres in.' }
  }

  // Demo intake: bericht is optional. Generic contact form: required.
  if (intent === 'contact' && (!bericht || bericht.length < 10)) {
    return { status: 'error', message: 'Vul een bericht in (minimaal 10 tekens).' }
  }

  const subjectPrefix = intent === 'demo' ? 'Demo-aanvraag' : 'Contactformulier'
  const successMessage = intent === 'demo'
    ? 'Bedankt voor uw aanvraag! Wij nemen binnen 1 werkdag telefonisch contact met u op.'
    : 'Bedankt voor uw bericht! Wij nemen binnen 1 werkdag contact op.'

  // Send via Resend if API key is configured, else log
  const resendApiKey = process.env.RESEND_API_KEY

  if (resendApiKey) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${resendApiKey}`,
        },
        body: JSON.stringify({
          from: 'Woninganalyse Contact <contact@woninganalyse.nl>',
          to: ['info@woninganalyse.nl'],
          replyTo: email,
          subject: `${subjectPrefix}: ${naam}${kantoor ? ` — ${kantoor}` : ''}`,
          html: `
            <h2>${intent === 'demo' ? 'Nieuwe demo-aanvraag' : 'Nieuw contactbericht'}</h2>
            <p><strong>Naam:</strong> ${naam}</p>
            <p><strong>E-mail:</strong> ${email}</p>
            ${kantoor ? `<p><strong>Kantoor:</strong> ${kantoor}</p>` : ''}
            ${telefoon ? `<p><strong>Telefoon:</strong> ${telefoon}</p>` : ''}
            ${bericht ? `<p><strong>Bericht:</strong></p><p style="white-space: pre-wrap;">${bericht}</p>` : ''}
          `,
        }),
      })

      if (!response.ok) {
        console.error('Resend error:', await response.text())
        return {
          status: 'error',
          message: 'Er ging iets mis. Probeer het later opnieuw of stuur een e-mail naar info@woninganalyse.nl.',
        }
      }
    } catch (error) {
      console.error('Contact form error:', error)
      return {
        status: 'error',
        message: 'Er ging iets mis. Probeer het later opnieuw of stuur een e-mail naar info@woninganalyse.nl.',
      }
    }
  } else {
    // Dev fallback — log to console
    console.log(`${subjectPrefix} submission (no RESEND_API_KEY set):`, {
      naam, email, kantoor, telefoon, bericht, intent,
    })
  }

  return {
    status: 'success',
    message: successMessage,
  }
}
