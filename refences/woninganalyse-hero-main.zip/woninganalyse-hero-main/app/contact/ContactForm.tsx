'use client'

import { useActionState } from 'react'
import { useFormStatus } from 'react-dom'
import { sendContactForm, type ContactFormState } from '@/app/actions/contact'
import { CheckCircle2, AlertCircle } from 'lucide-react'

const initialState: ContactFormState = { status: 'idle', message: '' }

function SubmitButton() {
  const { pending } = useFormStatus()
  return (
    <button
      type="submit"
      disabled={pending}
      className="w-full py-3 bg-[var(--brand)] text-white font-semibold text-[15px] rounded-[6px] hover:bg-[var(--brand-dark)] disabled:opacity-60 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
    >
      {pending ? (
        <>
          <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" aria-hidden="true" />
          Versturen...
        </>
      ) : (
        'Stuur bericht →'
      )}
    </button>
  )
}

export default function ContactForm() {
  const [state, formAction] = useActionState(sendContactForm, initialState)

  if (state.status === 'success') {
    return (
      <div className="flex flex-col items-center text-center py-8 gap-4">
        <div className="w-14 h-14 rounded-full bg-emerald-50 flex items-center justify-center">
          <CheckCircle2 size={28} className="text-[var(--success)]" aria-hidden="true" />
        </div>
        <h3 className="text-heading-3 text-[var(--fg)]">Bericht ontvangen</h3>
        <p className="text-[15px] text-[var(--fg-muted)]">{state.message}</p>
      </div>
    )
  }

  return (
    <form action={formAction} className="space-y-4" noValidate>
      {state.status === 'error' && (
        <div
          role="alert"
          className="flex items-start gap-2.5 bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-[13px] text-red-700"
        >
          <AlertCircle size={14} className="shrink-0 mt-0.5" aria-hidden="true" />
          {state.message}
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="contact-naam" className="block text-[13px] font-semibold text-[var(--fg)] mb-1.5">
            Naam <span aria-hidden="true" className="text-[var(--accent)]">*</span>
          </label>
          <input
            type="text"
            id="contact-naam"
            name="naam"
            required
            autoComplete="name"
            placeholder="Jan de Vries"
            className="w-full px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--brand)] transition-colors"
          />
        </div>
        <div>
          <label htmlFor="contact-kantoor" className="block text-[13px] font-semibold text-[var(--fg)] mb-1.5">
            Kantoor
          </label>
          <input
            type="text"
            id="contact-kantoor"
            name="kantoor"
            autoComplete="organization"
            placeholder="De Vries Makelaars"
            className="w-full px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--brand)] transition-colors"
          />
        </div>
      </div>

      <div>
        <label htmlFor="contact-email" className="block text-[13px] font-semibold text-[var(--fg)] mb-1.5">
          E-mailadres <span aria-hidden="true" className="text-[var(--accent)]">*</span>
        </label>
        <input
          type="email"
          id="contact-email"
          name="email"
          required
          autoComplete="email"
          placeholder="jan@kantoor.nl"
          className="w-full px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--brand)] transition-colors"
        />
      </div>

      <div>
        <label htmlFor="contact-bericht" className="block text-[13px] font-semibold text-[var(--fg)] mb-1.5">
          Bericht <span aria-hidden="true" className="text-[var(--accent)]">*</span>
        </label>
        <textarea
          id="contact-bericht"
          name="bericht"
          required
          rows={5}
          placeholder="Vertel ons wat u wilt bespreken..."
          className="w-full px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--brand)] transition-colors resize-none"
        />
      </div>

      <SubmitButton />

      <p className="text-[12px] text-[var(--fg-subtle)] text-center">
        Uw gegevens worden uitsluitend gebruikt voor het beantwoorden van uw vraag. Wij nemen binnen 1 werkdag contact op.
      </p>
    </form>
  )
}
