import type { Metadata } from 'next'
import { Badge } from '@/components/ui/Badge'
import { Linkedin, Mail } from 'lucide-react'
import ContactForm from './ContactForm'
import { buildBreadcrumbList } from '@/lib/jsonld'

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Contact', url: 'https://www.woninganalyse.nl/contact' },
])

export const metadata: Metadata = {
  title: 'Contact — Woninganalyse',
  description:
    'Neem contact op met Woninganalyse. Voor demo-aanvragen, samenwerking of vragen over onze tools voor makelaars.',
  alternates: { canonical: 'https://www.woninganalyse.nl/contact' },
  openGraph: {
    title: 'Contact — Woninganalyse',
    description:
      'Neem contact op met Woninganalyse. Voor demo-aanvragen, samenwerking of vragen over onze tools voor makelaars.',
    url: 'https://www.woninganalyse.nl/contact',
  },
}

const contactJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'ContactPage',
  name: 'Contact Woninganalyse',
  url: 'https://www.woninganalyse.nl/contact',
  mainEntity: {
    '@type': 'Organization',
    name: 'Woninganalyse',
    email: 'info@woninganalyse.nl',
    url: 'https://www.woninganalyse.nl',
    sameAs: ['https://www.linkedin.com/company/tinybasenl'],
  },
}

export default function ContactPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(contactJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />

      <section className="pt-28 pb-24 px-4 sm:px-6">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-14">
            <Badge variant="brand" className="mb-4">Contact</Badge>
            <h1 className="text-display-1 text-[var(--fg)] mb-4">
              Hoe kunnen wij u helpen?
            </h1>
            <p className="text-[18px] text-[var(--fg-muted)] max-w-[480px] mx-auto">
              Voor demo-aanvragen, partnervragen of algemene informatie over onze tools voor makelaars.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
            {/* Form */}
            <div className="lg:col-span-3">
              <div className="bg-[var(--bg-surface)] border border-[var(--border)] rounded-2xl p-7 sm:p-9">
                <h2 className="text-heading-3 text-[var(--fg)] mb-6">Stuur ons een bericht</h2>
                <ContactForm />
              </div>
            </div>

            {/* Contact info */}
            <div className="lg:col-span-2 space-y-6">
              {/* Direct contact */}
              <div className="bg-[var(--bg-muted)] rounded-xl p-6">
                <h2 className="text-heading-3 text-[var(--fg)] mb-4">Direct contact</h2>
                <div className="space-y-3">
                  <a
                    href="mailto:info@woninganalyse.nl"
                    className="flex items-center gap-3 text-[14px] text-[var(--fg-muted)] hover:text-[var(--brand)] transition-colors group"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[var(--bg-surface)] border border-[var(--border)] flex items-center justify-center shrink-0">
                      <Mail size={14} className="text-[var(--brand)]" aria-hidden="true" />
                    </div>
                    info@woninganalyse.nl
                  </a>
                  <a
                    href="https://www.linkedin.com/company/tinybasenl"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 text-[14px] text-[var(--fg-muted)] hover:text-[var(--brand)] transition-colors group"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[var(--bg-surface)] border border-[var(--border)] flex items-center justify-center shrink-0">
                      <Linkedin size={14} className="text-[var(--brand)]" aria-hidden="true" />
                    </div>
                    LinkedIn
                  </a>
                </div>
              </div>

              {/* Response time */}
              <div className="bg-[var(--brand-light)] border border-[rgba(27,79,255,0.15)] rounded-xl p-6">
                <h3 className="text-[14px] font-semibold text-[var(--fg)] mb-2">Reactietijd</h3>
                <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed">
                  Wij reageren op werkdagen binnen{' '}
                  <span className="font-semibold text-[var(--brand)]">24 uur</span> op uw bericht.
                </p>
              </div>

              {/* FAQ link */}
              <div className="border border-[var(--border)] rounded-xl p-6">
                <h3 className="text-[14px] font-semibold text-[var(--fg)] mb-2">
                  Veelgestelde vragen
                </h3>
                <p className="text-[13px] text-[var(--fg-muted)] leading-relaxed mb-3">
                  Mogelijk staat uw vraag al beantwoord in onze FAQ.
                </p>
                <a
                  href="/#faq"
                  className="text-[13px] font-semibold text-[var(--brand)] hover:text-[var(--brand-dark)] transition-colors"
                >
                  Bekijk de FAQ →
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
