import type { Metadata } from 'next'
import { DM_Sans } from 'next/font/google'
import './globals.css'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import CookieBanner from '@/components/layout/CookieBanner'
import GoogleAnalytics from '@/components/analytics/GoogleAnalytics'
import DemoModalProvider from '@/components/demo/DemoModalProvider'

const dmSans = DM_Sans({
  weight: ['400', '500', '600', '700', '800'],
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
})

export const metadata: Metadata = {
  title: {
    template: '%s | Woninganalyse',
    default: 'Woninganalyse — AI-consultancy voor makelaars',
  },
  description:
    'AI-bureau voor de Nederlandse makelaardij. We bedenken, bouwen en implementeren AI voor leadgeneratie, verkoopteksten en objectvragen.',
  metadataBase: new URL('https://www.woninganalyse.nl'),
  openGraph: {
    siteName: 'Woninganalyse',
    locale: 'nl_NL',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="nl"
      className={dmSans.variable}
    >
      <body className="min-h-screen flex flex-col antialiased overflow-x-hidden" style={{ backgroundColor: 'var(--bg)', color: 'var(--fg)' }}>
        <a href="#main-content" className="skip-to-content">
          Ga naar hoofdinhoud
        </a>
        <DemoModalProvider>
          <Navbar />
          <main id="main-content" className="flex-1 overflow-x-hidden">
            {children}
          </main>
          <Footer />
        </DemoModalProvider>
        <CookieBanner />
        <GoogleAnalytics />
      </body>
    </html>
  )
}
