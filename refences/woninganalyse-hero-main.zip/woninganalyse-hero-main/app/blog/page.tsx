import type { Metadata } from 'next'
import Link from 'next/link'
import Image from 'next/image'
import { blogPosts } from '@/lib/blog-data'
import { Badge } from '@/components/ui/Badge'
import { Clock, ArrowRight } from 'lucide-react'
import { buildBreadcrumbList } from '@/lib/jsonld'

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Blog', url: 'https://www.woninganalyse.nl/blog' },
])

export const metadata: Metadata = {
  title: 'Blog — AI voor makelaars | Woninganalyse',
  description:
    'AI voor makelaars: praktische artikelen over leadgeneratie, woningwaarde-tools, AI-woningteksten en slimme automatisering voor uw makelaarskantoor.',
  alternates: { canonical: 'https://www.woninganalyse.nl/blog' },
  openGraph: {
    title: 'Woninganalyse Blog — AI voor makelaars',
    description:
      'AI voor makelaars: praktische artikelen over leadgeneratie, woningwaarde-tools, AI-woningteksten en slimme automatisering voor uw makelaarskantoor.',
    url: 'https://www.woninganalyse.nl/blog',
  },
}

export default function BlogListPage() {
  const aiPillar = blogPosts.find((p) => p.slug === 'ai-tools-voor-makelaars')
  const featured = aiPillar ?? blogPosts[0]
  const rest = blogPosts.filter((p) => p.slug !== featured.slug)

  return (
    <div className="pt-24 pb-24 px-4 sm:px-6" aria-labelledby="blog-heading">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      {/* Header */}
      <div className="max-w-5xl mx-auto mb-14">
        <div className="border-b border-[var(--border)] pb-10">
          <Badge variant="brand" className="mb-4">Blog</Badge>
          <h1 id="blog-heading" className="text-display-1 text-[var(--fg)] mb-4 max-w-[640px]">
            AI voor makelaars
          </h1>
          <p className="text-[18px] text-[var(--fg-muted)] max-w-[620px] leading-relaxed">
            Hoe zet u AI-tools in om meer leads van uw website te halen, woningteksten sneller te
            schrijven en objectvragen 24/7 af te handelen? Praktische artikelen voor NVM- en
            VBO-makelaars die hun kantoor slimmer willen laten werken.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto">
        {/* Featured post */}
        <Link
          href={`/blog/${featured.slug}`}
          className="group grid grid-cols-1 lg:grid-cols-[0.95fr_1.05fr] mb-10 border border-[var(--border)] rounded-2xl bg-[var(--bg-surface)] hover:border-[var(--border-hover)] hover:-translate-y-1 transition-all duration-200 overflow-hidden"
        >
          {featured.image && (
            <div className="relative w-full aspect-[1200/630] lg:aspect-auto lg:min-h-[360px]">
              <Image
                src={featured.image}
                alt={featured.imageAlt ?? featured.title}
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 480px"
                priority
              />
            </div>
          )}
          <div className="p-6 sm:p-8 lg:p-10 flex flex-col justify-center">
          <div className="flex items-center gap-3 mb-5">
            <Badge variant="brand">{featured.category}</Badge>
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[var(--fg-subtle)] bg-[var(--bg-muted)] px-2.5 py-1 rounded-full">
              Uitgelicht
            </span>
          </div>
          <h2 className="text-display-2 text-[var(--fg)] mb-4 group-hover:text-[var(--brand)] transition-colors max-w-[640px]">
            {featured.title}
          </h2>
          <p className="text-[16px] text-[var(--fg-muted)] leading-relaxed mb-6 max-w-[560px]">
            {featured.description}
          </p>
          <div className="grid grid-cols-[1fr_1fr_auto] items-center gap-3 sm:flex sm:gap-5 text-[13px] text-[var(--fg-subtle)]">
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <Clock size={12} aria-hidden="true" />
              {featured.readTime} min
            </div>
            <time dateTime={featured.date}>
              {new Date(featured.date).toLocaleDateString('nl-NL', {
                day: 'numeric',
                month: 'long',
                year: 'numeric',
              })}
            </time>
            <span className="ml-auto flex items-center gap-1 font-semibold text-[var(--brand)] group-hover:gap-2 transition-all text-right">
              Lees artikel <ArrowRight size={13} aria-hidden="true" />
            </span>
          </div>
          </div>
        </Link>

        {/* Rest of posts */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {rest.map((post) => (
            <article key={post.slug} className="group flex flex-col border border-[var(--border)] rounded-xl bg-[var(--bg-surface)] hover:border-[var(--border-hover)] hover:-translate-y-1 transition-all duration-200 overflow-hidden">
              <Link href={`/blog/${post.slug}`} className="relative w-full aspect-[1200/630] bg-[var(--bg-muted)] overflow-hidden">
                {post.image ? (
                  <Image
                    src={post.image}
                    alt={post.imageAlt ?? post.title}
                    fill
                    className="object-cover"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-[var(--brand-light)] to-[var(--bg-muted)]">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--brand)]">
                      Inzicht voor makelaars
                    </span>
                  </div>
                )}
              </Link>
              <div className="p-6 flex flex-col flex-1">
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="muted">{post.category}</Badge>
                  <div className="flex items-center gap-1 text-[11px] text-[var(--fg-subtle)]">
                    <Clock size={10} aria-hidden="true" />
                    {post.readTime} min
                  </div>
                </div>

                <h2 className="text-[16px] font-bold text-[var(--fg)] leading-snug mb-3 group-hover:text-[var(--brand)] transition-colors">
                  <Link href={`/blog/${post.slug}`} className="focus-visible:outline-[var(--brand)]">
                    {post.title}
                  </Link>
                </h2>

                <p className="text-[13px] text-[var(--fg-muted)] leading-relaxed flex-1 mb-5">
                  {post.description}
                </p>

                <div className="flex items-center justify-between pt-4 border-t border-[var(--border)]">
                  <time dateTime={post.date} className="text-[11px] text-[var(--fg-subtle)]">
                    {new Date(post.date).toLocaleDateString('nl-NL', {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </time>
                  <Link
                    href={`/blog/${post.slug}`}
                    className="inline-flex items-center gap-1 text-[12px] font-semibold text-[var(--brand)] hover:text-[var(--brand-dark)] transition-colors group/link"
                    aria-label={`Lees meer: ${post.title}`}
                  >
                    Lees meer
                    <ArrowRight size={11} className="group-hover/link:translate-x-0.5 transition-transform" aria-hidden="true" />
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </div>
  )
}
