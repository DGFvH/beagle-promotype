import { getBlogPost, getAllSlugs } from '@/lib/blog-data'
import { buildOGImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE
export const alt = 'Woninganalyse Blog'

export function generateStaticParams() {
  return getAllSlugs().map((slug) => ({ slug }))
}

interface Props {
  params: Promise<{ slug: string }>
}

export default async function OGImage({ params }: Props) {
  const { slug } = await params
  const post = getBlogPost(slug)

  if (!post) {
    return buildOGImage({
      title: 'Artikel',
      subtitle: 'Inzichten voor makelaars',
      badge: 'Blog',
      accent: 'brand',
    })
  }

  return buildOGImage({
    title: post.title,
    badge: post.category,
    accent: 'brand',
  })
}
