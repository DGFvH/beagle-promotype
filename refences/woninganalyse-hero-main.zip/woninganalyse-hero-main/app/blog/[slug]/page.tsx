import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import { getBlogPost, getAllSlugs, getPostWordCount, getRelatedPosts, DEFAULT_AUTHOR, type ContentBlock } from '@/lib/blog-data'
import { Badge } from '@/components/ui/Badge'
import { Clock, ArrowLeft, ArrowRight } from 'lucide-react'
import { buildBlogPosting, buildFaqPage, buildBreadcrumbList } from '@/lib/jsonld'
import RelatedArticles from '@/components/blog/RelatedArticles'

interface Props {
  params: Promise<{ slug: string }>
}

export async function generateStaticParams() {
  return getAllSlugs().map((slug) => ({ slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const post = getBlogPost(slug)
  if (!post) return { robots: { index: false, follow: false } }

  return {
    title: `${post.title} | Woninganalyse Blog`,
    description: post.description,
    alternates: { canonical: `https://www.woninganalyse.nl/blog/${post.slug}` },
    openGraph: {
      title: post.title,
      description: post.description,
      url: `https://www.woninganalyse.nl/blog/${post.slug}`,
      type: 'article',
      publishedTime: post.date,
      ...(post.image && {
        images: [{ url: `https://www.woninganalyse.nl${post.image}`, alt: post.imageAlt ?? post.title }],
      }),
    },
  }
}

function renderBlock(block: ContentBlock, i: number) {
  switch (block.type) {
    case 'paragraph':
      return (
        <p key={i} className="text-[16px] text-[var(--fg-muted)] leading-[1.8] mb-6">
          {block.text}
        </p>
      )
    case 'richText':
      return (
        <p key={i} className="text-[16px] text-[var(--fg-muted)] leading-[1.8] mb-6">
          {block.segments.map((seg, j) => {
            if (typeof seg === 'string') return <span key={j}>{seg}</span>
            if (seg.external) {
              return (
                <a
                  key={j}
                  href={seg.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[var(--brand)] underline underline-offset-2 hover:text-[var(--brand-dark)]"
                >
                  {seg.text}
                </a>
              )
            }
            return (
              <Link
                key={j}
                href={seg.href}
                className="text-[var(--brand)] underline underline-offset-2 hover:text-[var(--brand-dark)]"
              >
                {seg.text}
              </Link>
            )
          })}
        </p>
      )
    case 'heading2':
      return (
        <h2 key={i} className="text-heading-2 text-[var(--fg)] mt-12 mb-4 pt-8 border-t border-[var(--border)]">
          {block.text}
        </h2>
      )
    case 'heading3':
      return (
        <h3 key={i} className="text-heading-3 text-[var(--fg)] mt-8 mb-3">
          {block.text}
        </h3>
      )
    case 'list':
      return (
        <ul key={i} className="list-disc pl-6 mb-6 space-y-2">
          {block.items.map((item, j) => (
            <li key={j} className="text-[15px] text-[var(--fg-muted)] leading-relaxed">
              {item}
            </li>
          ))}
        </ul>
      )
    case 'callout':
      return (
        <div
          key={i}
          className="border-l-4 border-[var(--brand)] bg-[var(--bg-surface)] rounded-r-lg px-6 py-5 my-8"
        >
          <p className="text-[15px] text-[var(--fg)] leading-relaxed">{block.text}</p>
        </div>
      )
  }
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params
  const post = getBlogPost(slug)
  if (!post) notFound()

  const author = post.author ?? DEFAULT_AUTHOR

  const jsonLd = buildBlogPosting({
    title: post.title,
    description: post.description,
    slug: post.slug,
    date: post.date,
    category: post.category,
    relatedTool: post.relatedTool,
    wordCount: getPostWordCount(post),
    author,
  })

  const breadcrumbJsonLd = buildBreadcrumbList([
    { name: 'Home', url: 'https://www.woninganalyse.nl' },
    { name: 'Blog', url: 'https://www.woninganalyse.nl/blog' },
    { name: post.title, url: `https://www.woninganalyse.nl/blog/${post.slug}` },
  ])

  const faqJsonLd = post.faqs && post.faqs.length > 0 ? buildFaqPage(post.faqs) : null

  const relatedPosts = getRelatedPosts(post, 2)

  return (
    <>
    <div className={['pt-24 px-4 sm:px-6', relatedPosts.length > 0 ? 'pb-12' : 'pb-24'].join(' ')}>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      {faqJsonLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
        />
      )}
      <article className="max-w-[680px] mx-auto">
        <Link
          href="/blog"
          className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-[var(--brand)] hover:text-[var(--brand-dark)] transition-colors mb-8"
        >
          <ArrowLeft size={13} aria-hidden="true" />
          Alle artikelen
        </Link>

        <header className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <Badge variant="brand">{post.category}</Badge>
            <div className="flex items-center gap-1.5 text-[12px] text-[var(--fg-subtle)]">
              <Clock size={11} aria-hidden="true" />
              {post.readTime} min leestijd
            </div>
          </div>
          <h1 className="text-display-1 text-[var(--fg)] mb-4 max-w-full break-words">{post.title}</h1>
          <p className="text-[18px] text-[var(--fg-muted)] leading-relaxed">{post.description}</p>
          <time
            dateTime={post.date}
            className="block mt-4 text-[13px] text-[var(--fg-subtle)]"
          >
            {new Date(post.date).toLocaleDateString('nl-NL', {
              day: 'numeric',
              month: 'long',
              year: 'numeric',
            })}
          </time>
          <p className="mt-2 text-[13px] text-[var(--fg-subtle)]">
            Door <span className="font-semibold text-[var(--fg)]">{author.name}</span> — {author.role}
          </p>
        </header>

        {post.image && (
          <div className="relative w-full aspect-[1200/630] rounded-xl overflow-hidden mb-10">
            <Image
              src={post.image}
              alt={post.imageAlt ?? post.title}
              fill
              className="object-cover"
              sizes="(max-width: 680px) 100vw, 680px"
              priority
            />
          </div>
        )}

        <div className="border-t border-[var(--border)] pt-10">
          {post.content.map(renderBlock)}
        </div>

        {post.faqs && post.faqs.length > 0 && (
          <section className="mt-12 pt-10 border-t border-[var(--border)]" aria-labelledby="post-faq-heading">
            <h2 id="post-faq-heading" className="text-heading-2 text-[var(--fg)] mb-6">
              Veelgestelde vragen
            </h2>
            <div className="space-y-6">
              {post.faqs.map((faq, i) => (
                <div key={i}>
                  <h3 className="text-heading-3 text-[var(--fg)] mb-2">{faq.q}</h3>
                  <p className="text-[15px] text-[var(--fg-muted)] leading-relaxed">{faq.a}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {post.relatedTool && (
          <div className="mt-14 p-8 border border-[var(--border)] rounded-2xl bg-[var(--bg-surface)] text-center">
            <p className="text-[15px] text-[var(--fg-muted)] mb-4">
              Meer weten over {post.relatedTool}?
            </p>
            <Link
              href={post.relatedToolSlug}
              className="inline-flex items-center gap-1.5 text-[15px] font-semibold text-[var(--brand)] hover:text-[var(--brand-dark)] transition-colors"
            >
              {post.relatedToolCta}
              <ArrowRight size={14} aria-hidden="true" />
            </Link>
          </div>
        )}
      </article>
    </div>
    <RelatedArticles posts={relatedPosts} />
    </>
  )
}
