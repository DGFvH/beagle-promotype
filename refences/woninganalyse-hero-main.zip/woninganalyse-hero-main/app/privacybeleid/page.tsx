import type { Metadata } from 'next'
import { Badge } from '@/components/ui/Badge'
import { buildBreadcrumbList } from '@/lib/jsonld'

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Privacybeleid', url: 'https://www.woninganalyse.nl/privacybeleid' },
])

export const metadata: Metadata = {
  title: 'Privacybeleid',
  description: 'Privacybeleid van Woninganalyse. Hoe wij omgaan met uw persoonsgegevens.',
  alternates: { canonical: 'https://www.woninganalyse.nl/privacybeleid' },
  openGraph: {
    title: 'Privacybeleid',
    description: 'Privacybeleid van Woninganalyse. Hoe wij omgaan met uw persoonsgegevens.',
    url: 'https://www.woninganalyse.nl/privacybeleid',
  },
}

export default function PrivacybeleidPage() {
  return (
    <article className="pt-28 pb-24 px-4 sm:px-6">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <div className="max-w-[680px] mx-auto">
        <Badge variant="muted" className="mb-4">Juridisch</Badge>
        <h1 className="text-display-1 text-[var(--fg)] mb-6">Privacybeleid</h1>
        <p className="text-[13px] text-[var(--fg-subtle)] mb-10">Laatst bijgewerkt: maart 2025</p>

        <div className="space-y-8 text-[16px] text-[var(--fg-muted)] leading-relaxed">
          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>1. Verantwoordelijke</h2>
            <p>Woninganalyse (onderdeel van TinyBase B.V.) is verantwoordelijk voor de verwerking van persoonsgegevens zoals beschreven in dit privacybeleid. Voor vragen kunt u contact opnemen via info@woninganalyse.nl.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>2. Welke gegevens verzamelen wij?</h2>
            <p>Wij verzamelen gegevens die u actief verstrekt via contactformulieren (naam, e-mailadres, telefoonnummer, bedrijfsnaam) en gegevens die automatisch worden verzameld bij het bezoeken van onze website (IP-adres, browsertype, paginabezoeken).</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>3. Doel van verwerking</h2>
            <p>Uw persoonsgegevens worden verwerkt voor het beantwoorden van uw vragen, het leveren van onze diensten, het verbeteren van onze website en het voldoen aan wettelijke verplichtingen.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>4. Bewaartermijn</h2>
            <p>Wij bewaren persoonsgegevens niet langer dan noodzakelijk voor het doel waarvoor zij zijn verzameld, tenzij een langere bewaartermijn wettelijk verplicht is.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>5. Uw rechten</h2>
            <p>U heeft het recht op inzage, rectificatie, verwijdering en overdraagbaarheid van uw gegevens. Ook kunt u bezwaar maken tegen de verwerking. Neem hiervoor contact op via info@woninganalyse.nl.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>6. Cookies</h2>
            <p>Onze website gebruikt functionele en analytische cookies. Functionele cookies zijn noodzakelijk voor het functioneren van de website. Analytische cookies helpen ons de website te verbeteren. U kunt cookies uitschakelen via uw browserinstellingen.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>7. Contact</h2>
            <p>Voor vragen over dit privacybeleid kunt u contact opnemen via <a href="mailto:info@woninganalyse.nl" className="text-[var(--brand)] hover:underline">info@woninganalyse.nl</a>.</p>
          </section>
        </div>
      </div>
    </article>
  )
}
