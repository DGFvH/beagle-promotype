import type { Metadata } from 'next'
import { Badge } from '@/components/ui/Badge'
import { CheckCircle2, Clock, Database, Shield } from 'lucide-react'
import WaardescanMockup from '@/components/ui/mockups/WaardescanMockup'
import HuistekstMockup from '@/components/ui/mockups/HuistekstMockup'
import ObjectAssistentMockup from '@/components/ui/mockups/ObjectAssistentMockup'
import SfeerimpressieMockup from '@/components/ui/mockups/SfeerimpressieMockup'
import DemoForm from './DemoForm'
import { buildBreadcrumbList, buildFaqPage } from '@/lib/jsonld'

const PAGE_URL = 'https://www.woninganalyse.nl/demo'

export const metadata: Metadata = {
  title: 'Demo aanvragen — Woninganalyse',
  description:
    'Vraag een persoonlijke demo aan. In 20 minuten ziet u hoe Waardescan, Huistekst, Object Assistent en Sfeerimpressie uw kantoor minder routinewerk en meer leads opleveren.',
  alternates: { canonical: PAGE_URL },
  openGraph: {
    title: 'Vraag een persoonlijke demo aan',
    description:
      'Zie in 20 minuten hoe Woninganalyse uw werkdag verandert: meer leads, minder routinewerk.',
    url: PAGE_URL,
  },
}

const webPageJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'WebPage',
  name: 'Demo aanvragen — Woninganalyse',
  url: PAGE_URL,
  description:
    'Vraag een persoonlijke demo aan van de Woninganalyse-tools voor makelaars: Waardescan, Huistekst, Object Assistent en Sfeerimpressie.',
  inLanguage: 'nl-NL',
  isPartOf: { '@id': 'https://www.woninganalyse.nl/#organization' },
}

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Demo', url: PAGE_URL },
])

const TOOLS_PREVIEW = [
  {
    name: 'Waardescan',
    description:
      'Hoe u in vijf minuten de widget op uw eigen site plaatst en welke gegevens u per lead ontvangt.',
    mockup: <WaardescanMockup />,
  },
  {
    name: 'Huistekst',
    description:
      'Live demo: van vijf kenmerken naar een publicatieklare Funda-tekst in onder de 30 seconden.',
    mockup: <HuistekstMockup />,
  },
  {
    name: 'Object Assistent',
    description:
      'Hoe de chatbot getraind wordt op uw brochure en hoe leads automatisch in uw dashboard belanden.',
    mockup: <ObjectAssistentMockup />,
  },
  {
    name: 'Sfeerimpressie',
    description:
      'Een sneak peek op de redesign-impressie — de tool waarop u zich kunt aanmelden voor vroege toegang.',
    mockup: <SfeerimpressieMockup />,
  },
]

const TRUST_POINTS = [
  {
    icon: Clock,
    title: '20 minuten, geen verplichtingen',
    body: 'Een focusgesprek waarin we de tools laten zien die het meest relevant zijn voor uw kantoor.',
  },
  {
    icon: Database,
    title: 'Gebouwd op officiële data',
    body: 'Kadaster (BAG), CBS, WOZ-referenties en actuele transactiedata vormen de basis onder elke tool.',
  },
  {
    icon: Shield,
    title: 'AVG-conform en NVM/VBO-vriendelijk',
    body: 'Witlabel inzetbaar in uw eigen huisstijl. Geen branding van Woninganalyse zichtbaar voor uw klanten.',
  },
]

const FAQS = [
  {
    q: 'Wie is er bij de demo aanwezig?',
    a: 'Een productspecialist van Woninganalyse. Geen verkoper-met-deadline — iemand die uw vragen kan beantwoorden over implementatie, integraties en mogelijkheden.',
  },
  {
    q: 'Hoeveel collega’s kan ik meenemen?',
    a: 'Zoveel als nuttig is. We adviseren minimaal de eindbeslisser plus de persoon die het in de praktijk gaat gebruiken. Marketing en IT zijn ook welkom.',
  },
  {
    q: 'Krijg ik na de demo gelijk toegang?',
    a: 'Ja. U kunt direct na de demo een account aanmaken en de Waardescan op uw site plaatsen. Geen creditcard nodig voor de proefperiode.',
  },
  {
    q: 'Werkt het ook voor zelfstandige makelaars?',
    a: 'Zeker. We werken zowel met zelfstandigen als met grotere VBO- en NVM-kantoren. De tools schalen mee met uw situatie.',
  },
]

const faqJsonLd = buildFaqPage(FAQS)

export default function DemoPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      {/* Hero */}
      <section className="pt-28 pb-16 px-4 sm:px-6 dot-grid" aria-labelledby="demo-hero-heading">
        <div className="max-w-[760px] mx-auto text-center">
          <Badge variant="brand" className="mb-5">Demo</Badge>
          <h1 id="demo-hero-heading" className="text-display-1 text-[var(--fg)] mb-5">
            Vraag een{' '}
            <em className="italic" style={{ color: 'var(--brand)' }}>persoonlijke demo</em>{' '}
            aan
          </h1>
          <p className="text-[18px] text-[var(--fg-muted)] leading-relaxed mb-9 max-w-[580px] mx-auto">
            In 20 minuten ziet u live hoe Woninganalyse routinewerk wegneemt en leads oplevert via uw eigen website. Wij nemen u rond door de tools die het meest relevant zijn voor uw kantoor.
          </p>
          <a
            href="#demo-form-section"
            className="inline-flex items-center justify-center gap-2 px-7 py-3 bg-[var(--brand)] text-white font-bold text-[15px] rounded-[6px] hover:bg-[var(--brand-dark)] transition-colors shadow-lg shadow-[rgba(27,79,255,0.25)]"
          >
            Naar het formulier
          </a>
          <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 mt-8">
            {['20 minuten', 'Geen creditcard nodig', 'Direct toegang na afloop'].map((t) => (
              <span key={t} className="flex items-center gap-1.5 text-[13px] text-[var(--fg-subtle)]">
                <CheckCircle2 size={12} className="text-[var(--success)]" aria-hidden="true" />
                {t}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* What you'll see */}
      <section className="py-20 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="demo-tools-heading">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <Badge variant="brand" className="mb-4">Wat ziet u in de demo</Badge>
            <h2 id="demo-tools-heading" className="text-display-2 text-[var(--fg)]">
              Vier tools, één gesprek
            </h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3 max-w-[520px] mx-auto">
              We laten u live de tools zien die het meeste opleveren voor uw situatie. U kiest wat we eerst behandelen.
            </p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {TOOLS_PREVIEW.map((tool) => (
              <div
                key={tool.name}
                className="border border-[var(--border)] rounded-2xl p-6 sm:p-8 bg-[var(--bg-surface)]"
              >
                <h3 className="text-heading-3 text-[var(--fg)] mb-2">{tool.name}</h3>
                <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed mb-6 max-w-[420px]">
                  {tool.description}
                </p>
                <div className="pointer-events-none" style={{ zoom: '0.78' }}>
                  {tool.mockup}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust block */}
      <section className="py-20 px-4 sm:px-6" aria-labelledby="demo-trust-heading">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="brand" className="mb-4">Wat u krijgt</Badge>
            <h2 id="demo-trust-heading" className="text-display-2 text-[var(--fg)]">Concreet en zonder ruis</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {TRUST_POINTS.map((point) => (
              <div key={point.title} className="card p-6">
                <div className="w-10 h-10 rounded-lg bg-[var(--brand-light)] flex items-center justify-center mb-4">
                  <point.icon size={18} className="text-[var(--brand)]" aria-hidden="true" />
                </div>
                <h3 className="text-heading-3 text-[var(--fg)] mb-2">{point.title}</h3>
                <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed">{point.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Form */}
      <section id="demo-form-section" className="py-20 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="demo-form-heading">
        <div className="max-w-xl mx-auto">
          <div className="text-center mb-10">
            <Badge variant="brand" className="mb-4">Uw aanvraag</Badge>
            <h2 id="demo-form-heading" className="text-display-2 text-[var(--fg)]">
              Plan uw demo in
            </h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3">
              Laat uw gegevens achter. Wij nemen binnen 1 werkdag contact op om een geschikt moment te plannen.
            </p>
          </div>
          <div className="bg-[var(--bg-surface)] border border-[var(--border)] rounded-2xl p-7 sm:p-9">
            <DemoForm />
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 sm:px-6" aria-labelledby="demo-faq-heading">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <Badge variant="muted" className="mb-4">Veelgestelde vragen</Badge>
            <h2 id="demo-faq-heading" className="text-display-2 text-[var(--fg)]">Over de demo</h2>
          </div>
          <div className="space-y-4">
            {FAQS.map((faq) => (
              <div key={faq.q} className="border border-[var(--border)] rounded-xl p-6 bg-[var(--bg-surface)]">
                <h3 className="text-heading-3 text-[var(--fg)] mb-2">{faq.q}</h3>
                <p className="text-[15px] text-[var(--fg-muted)] leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
