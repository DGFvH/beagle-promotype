import { buildOGImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE
export const alt = 'Demo aanvragen — Woninganalyse'

export default function OGImage() {
  return buildOGImage({
    title: 'Vraag een persoonlijke demo aan',
    subtitle: 'Zie in 20 minuten hoe Woninganalyse uw werkdag verandert.',
    badge: 'Demo',
    accent: 'brand',
  })
}
