import type { Metadata } from 'next'
import { Badge } from '@/components/ui/Badge'
import { buildBreadcrumbList } from '@/lib/jsonld'

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Gebruiksvoorwaarden', url: 'https://www.woninganalyse.nl/gebruiksvoorwaarden' },
])

export const metadata: Metadata = {
  title: 'Gebruiksvoorwaarden',
  description: 'Gebruiksvoorwaarden van Woninganalyse. Lees de voorwaarden voor het gebruik van onze tools en diensten.',
  alternates: { canonical: 'https://www.woninganalyse.nl/gebruiksvoorwaarden' },
  openGraph: {
    title: 'Gebruiksvoorwaarden',
    description: 'Gebruiksvoorwaarden van Woninganalyse. Lees de voorwaarden voor het gebruik van onze tools en diensten.',
    url: 'https://www.woninganalyse.nl/gebruiksvoorwaarden',
  },
}

export default function GebruiksvoorwaardenPage() {
  return (
    <article className="pt-28 pb-24 px-4 sm:px-6">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <div className="max-w-[680px] mx-auto">
        <Badge variant="muted" className="mb-4">Juridisch</Badge>
        <h1 className="text-display-1 text-[var(--fg)] mb-6">Gebruiksvoorwaarden</h1>
        <p className="text-[13px] text-[var(--fg-subtle)] mb-10">Laatst bijgewerkt: maart 2025</p>

        <div className="space-y-8 text-[16px] text-[var(--fg-muted)] leading-relaxed">
          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>1. Toepasselijkheid</h2>
            <p>Deze voorwaarden zijn van toepassing op het gebruik van de website en diensten van Woninganalyse (onderdeel van TinyBase B.V.). Door gebruik te maken van onze diensten gaat u akkoord met deze voorwaarden.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>2. Diensten</h2>
            <p>Woninganalyse biedt AI-tools aan voor makelaars, waaronder woningwaarderingen, tekstgeneratie en leadgeneratie. De resultaten van onze tools zijn indicatief en dienen niet als vervanging voor professioneel advies of taxatie.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>3. Aansprakelijkheid</h2>
            <p>Woninganalyse is niet aansprakelijk voor schade die voortvloeit uit het gebruik van onze tools of het vertrouwen op door ons verstrekte informatie. Woningwaarderingen zijn indicatief en kunnen afwijken van de werkelijke marktwaarde.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>4. Intellectueel eigendom</h2>
            <p>Alle rechten op de inhoud van deze website — waaronder tekst, afbeeldingen, software en merkrechten — berusten bij Woninganalyse (onderdeel van TinyBase B.V.). Het is niet toegestaan deze zonder toestemming te kopiëren of verspreiden.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>5. Wijzigingen</h2>
            <p>Woninganalyse behoudt zich het recht voor deze voorwaarden te wijzigen. Wijzigingen treden in werking zodra zij op de website zijn gepubliceerd.</p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-3" style={{ fontSize: 'clamp(20px, 3vw, 26px)' }}>6. Toepasselijk recht</h2>
            <p>Op deze voorwaarden is Nederlands recht van toepassing. Geschillen worden voorgelegd aan de bevoegde rechter in Amsterdam.</p>
          </section>
        </div>
      </div>
    </article>
  )
}
