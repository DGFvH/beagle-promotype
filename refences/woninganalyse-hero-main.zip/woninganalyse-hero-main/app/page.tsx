import type { Metadata } from 'next'
import Hero from '@/components/sections/Hero'
import ToolsShowcase from '@/components/sections/ToolsShowcase'
import SocialProof from '@/components/sections/SocialProof'
import FAQ from '@/components/sections/FAQ'
import CTABanner from '@/components/sections/CTABanner'
import { ORGANIZATION_ID } from '@/lib/jsonld'

export const metadata: Metadata = {
  title: 'Woninganalyse — AI-consultancy voor makelaars',
  description:
    'AI-bureau voor de Nederlandse makelaardij. We bedenken, bouwen en implementeren AI voor leadgeneratie, verkoopteksten en objectvragen. Plan een gesprek.',
  alternates: {
    canonical: 'https://www.woninganalyse.nl',
  },
  openGraph: {
    title: 'Woninganalyse — AI-consultancy voor makelaars',
    description:
      'AI-bureau voor de makelaardij. Bekijk wat we al bouwden — Waardescan voor leads, Huistekst voor Funda en Object Assistent voor 24/7 objectvragen — en plan een gesprek.',
    url: 'https://www.woninganalyse.nl',
    type: 'website',
  },
}

const organizationJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  '@id': ORGANIZATION_ID,
  name: 'Woninganalyse',
  url: 'https://www.woninganalyse.nl',
  logo: 'https://www.woninganalyse.nl/logo-color.png',
  description:
    'AI-bureau voor de Nederlandse makelaardij. We bedenken, bouwen en implementeren AI-oplossingen: waarde-indicaties en leads, Funda-klare teksten, sfeerimpressie en 24/7 objectvragen (Object Assistent).',
  contactPoint: {
    '@type': 'ContactPoint',
    contactType: 'customer support',
    email: 'info@woninganalyse.nl',
    availableLanguage: 'Dutch',
  },
  sameAs: [
    'https://www.linkedin.com/company/tinybasenl',
  ],
}

const serviceJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: 'AI-consultancy voor makelaars',
  serviceType: 'AI-consultancy en -ontwikkeling',
  provider: { '@id': ORGANIZATION_ID },
  areaServed: 'NL',
  description:
    'AI-consultancy voor de Nederlandse makelaardij: advies, ontwikkeling en implementatie van AI-oplossingen zoals Waardescan, Huistekst, Sfeerimpressie en Object Assistent.',
}

export default function HomePage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceJsonLd) }}
      />
      <Hero />
      <ToolsShowcase />
      <SocialProof />
      <FAQ />
      <CTABanner />
    </>
  )
}
