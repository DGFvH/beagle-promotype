import { buildOGImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE
export const alt = 'Waardescan — Leadgeneratie via woningwaarde'

export default function OGImage() {
  return buildOGImage({
    title: 'Waardescan',
    subtitle: 'Leadgeneratie via woningwaarde — gratis voor uw bezoekers, warme leads voor u.',
    badge: 'Tool',
    accent: 'brand',
  })
}
