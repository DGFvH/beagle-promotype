import type { Metadata } from 'next'
import { CheckCircle2, Database, Mail, Home, User, Clock, BarChart2 } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { GesprekInplannenButton } from '@/components/demo/GesprekInplannenButton'
import WaardescanMockup from '@/components/ui/mockups/WaardescanMockup'
import CTABanner from '@/components/sections/CTABanner'
import RelatedArticles from '@/components/blog/RelatedArticles'
import { buildBreadcrumbList, buildFaqPage, buildService } from '@/lib/jsonld'
import { getBlogPost } from '@/lib/blog-data'

const RELATED_POSTS = [
  'leads-genereren-woningwaarde-tool',
  'woningwaarde-berekenen-2026',
  'ai-tools-voor-makelaars',
]
  .map(getBlogPost)
  .filter((p): p is NonNullable<typeof p> => p !== undefined)

export const metadata: Metadata = {
  title: 'Waardescan — Woningwaarde-tool voor makelaars | Leadgeneratie',
  description:
    'Bied bezoekers een gratis woningwaardering aan en ontvang direct gekwalificeerde leads. Gebaseerd op Kadasterdata. Probeer gratis.',
  alternates: { canonical: 'https://www.woninganalyse.nl/tools/waardescan' },
  openGraph: {
    title: 'Waardescan — Leadgeneratie voor makelaars',
    description:
      'Zet websitebezoekers om in warme verkoopgesprekken met een gratis waarde-indicatie tool.',
    url: 'https://www.woninganalyse.nl/tools/waardescan',
  },
}

const softwareJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'SoftwareApplication',
  name: 'Woninganalyse Waardescan',
  applicationCategory: 'BusinessApplication',
  operatingSystem: 'Web',
  description:
    'AI-tool voor makelaars die automatisch woningwaarde berekent en leads genereert via een embeddable widget.',
  offers: { '@type': 'Offer', price: '0', priceCurrency: 'EUR' },
}

const serviceJsonLd = buildService({
  name: 'Woninganalyse Waardescan',
  description:
    'Witlabel woningwaarderings-widget voor makelaars: bezoekers krijgen een gratis indicatie, de makelaar ontvangt een warme lead met naam, e-mail en adres.',
  serviceType: 'Leadgeneratie voor makelaars',
  url: 'https://www.woninganalyse.nl/tools/waardescan',
})

const FAQS = [
  { q: 'Hoe nauwkeurig is de waarde-indicatie?', a: 'De Waardescan combineert Kadasterdata, CBS-statistieken en recente transacties in de regio. Het resultaat is een bandbreedte die dient als goed startpunt voor een gesprek, niet als vervanging voor een formele taxatie.' },
  { q: 'Ziet de bezoeker mijn logo of dat van Woninganalyse?', a: 'Uw logo. De widget is volledig white-label: u stelt uw eigen logo, primaire kleur en domeinnaam in. Voor de bezoeker is Woninganalyse onzichtbaar.' },
  { q: 'Kan ik de widget op mijn eigen domein draaien?', a: 'Ja. U plaatst de widget via één script-tag op uw eigen website; de tool opent op uw domein. Er is geen aparte pagina of subdomain nodig.' },
  { q: 'Welke gegevens ontvangt u van een lead?', a: 'Naam, e-mailadres, adres van het object en de gegenereerde indicatie. Alles beschikbaar in uw dashboard en direct per e-mail.' },
  { q: 'Werkt het ook op een bestaande WordPress-site?', a: 'Ja. De widget werkt op elk platform dat een script-tag ondersteunt: WordPress, Webflow, Wix, Squarespace of een zelfgebouwde site.' },
  { q: 'Wat kost de Waardescan en zijn er opstartkosten?', a: 'De Waardescan werkt op een maandelijks gebruiksgebaseerd abonnement zonder opstartkosten. Het exacte tarief hangt af van uw transactievolume en de witlabel-configuratie. Voor een prijsindicatie die past bij uw kantoor: vraag een korte demo aan. We zijn vooraf transparant over wat u betaalt en werken niet met langlopende contracten.' },
  { q: 'Hoe lang duurt de implementatie van begin tot live?', a: 'Voor een standaard CMS (WordPress, Webflow, Wix, Squarespace) typisch 30 minuten tot een werkdag. De configuratie van logo, kleur en welkomsttekst doet u zelf via een dashboard. Een script-tag in uw site, een korte test, en u ontvangt uw eerste leads. Geen IT-team of maatwerktraject nodig.' },
]

const faqJsonLd = buildFaqPage(FAQS)

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Tools', url: 'https://www.woninganalyse.nl/#tools' },
  { name: 'Waardescan', url: 'https://www.woninganalyse.nl/tools/waardescan' },
])

export default function WaardescanPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      {/* Hero */}
      <section className="pt-28 pb-16 px-4 sm:px-6 dot-grid" aria-labelledby="tool-hero-heading">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-14 items-center">
            <div className="flex-1">
              <Badge variant="brand" className="mb-4">Waardescan</Badge>
              <h1 id="tool-hero-heading" className="text-display-1 text-[var(--fg)] mb-5">
                Meer leads via<br />
                <em className="italic" style={{ color: 'var(--brand)' }}>woningwaarde</em>
              </h1>
              <p className="text-[18px] text-[var(--fg-muted)] leading-relaxed mb-4 max-w-[480px]">
                Bied een gratis waarde-indicatie aan op uw website en ontvang direct contactgegevens van potentiële verkopers. Gebaseerd op officiële Kadasterdata.
              </p>
              <p className="text-[15px] text-[var(--fg-subtle)] leading-relaxed mb-8 max-w-[480px]">
                U plaatst de widget via één script-tag op uw site. Bezoekers voeren hun adres in en ontvangen een indicatie. U ontvangt hun naam en e-mailadres, klaar voor opvolging.
              </p>
              <div className="flex flex-wrap gap-3">
                <GesprekInplannenButton variant="primary" size="lg" className="w-full sm:w-auto" />
              </div>
              <p className="mt-6 text-[12px] text-[var(--fg-subtle)]">
                Gebouwd op Kadaster · CBS · WOZ · BAG · AVG-conform · NVM/VBO
              </p>
            </div>
            <div className="hidden lg:block lg:w-[45%] shrink-0">
              <WaardescanMockup />
            </div>
          </div>
        </div>
      </section>

      {/* What you receive per lead — directly after hero */}
      <section className="py-20 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="waardescan-lead">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="brand" className="mb-4">Per lead ontvangt u</Badge>
            <h2 id="waardescan-lead" className="text-display-2 text-[var(--fg)]">Wat zit er in een lead?</h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3 max-w-[480px] mx-auto">
              Zodra iemand een waarde-indicatie opvraagt, ontvangt u direct een melding. Dit is wat erin staat:
            </p>
          </div>
          <div className="max-w-xl mx-auto">
            {/* Email mockup */}
            <div className="bg-white border border-[var(--border)] rounded-2xl overflow-hidden shadow-lg">
              {/* Email header */}
              <div className="px-5 py-3 border-b border-[var(--border)] bg-[var(--bg-muted)] flex items-center gap-3">
                <div className="w-7 h-7 rounded-full bg-[var(--brand)] flex items-center justify-center shrink-0">
                  <Mail size={13} className="text-white" aria-hidden="true" />
                </div>
                <div>
                  <div className="text-[12px] font-semibold text-[var(--fg)]">Nieuwe lead via Waardescan</div>
                  <div className="text-[10px] text-[var(--fg-subtle)]">van: noreply@woninganalyse.nl</div>
                </div>
              </div>
              {/* Email body */}
              <div className="p-6 space-y-4">
                <p className="text-[13px] text-[var(--fg-muted)]">Er is een nieuwe waarde-indicatie aangevraagd via uw website. Hieronder de gegevens:</p>
                <div className="space-y-3">
                  {[
                    { icon: User, label: 'Naam', value: 'Anna Jansen' },
                    { icon: Mail, label: 'E-mailadres', value: 'a.jansen@email.nl' },
                    { icon: Home, label: 'Adres', value: 'Kerkstraat 14, 1234 AB Utrecht' },
                    { icon: BarChart2, label: 'Waarde-indicatie', value: '€ 385.000 – € 415.000' },
                    { icon: Clock, label: 'Aangevraagd op', value: 'vrijdag 20 mrt, 19:42' },
                  ].map((row) => (
                    <div key={row.label} className="flex items-center gap-3 text-[13px]">
                      <div className="w-6 h-6 rounded bg-[var(--brand-light)] flex items-center justify-center shrink-0">
                        <row.icon size={11} className="text-[var(--brand)]" aria-hidden="true" />
                      </div>
                      <span className="text-[var(--fg-subtle)] w-32 shrink-0">{row.label}</span>
                      <span className="font-semibold text-[var(--fg)]">{row.value}</span>
                    </div>
                  ))}
                </div>
                <div className="pt-3 border-t border-[var(--border)]">
                  <button className="w-full py-2 bg-[var(--brand)] text-white text-[12px] font-bold rounded-lg">
                    Bekijk lead in dashboard →
                  </button>
                </div>
              </div>
            </div>
            <p className="text-center text-[12px] text-[var(--fg-subtle)] mt-4">
              Naast de e-mail vindt u alle leads overzichtelijk terug in uw dashboard.
            </p>
          </div>
        </div>
      </section>

      {/* Why this converts */}
      <section className="py-20 px-4 sm:px-6" aria-labelledby="waardescan-convert">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="brand" className="mb-4">Waarom het werkt</Badge>
            <h2 id="waardescan-convert" className="text-display-2 text-[var(--fg)]">Beter dan een contactformulier</h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3 max-w-[520px] mx-auto">
              Een gewoon contactformulier vraagt iets van de bezoeker zonder er iets voor terug te geven. De Waardescan werkt andersom.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="border border-[var(--border)] rounded-xl p-7">
              <div className="text-[11px] font-bold uppercase tracking-wider text-[var(--fg-subtle)] mb-4">Contactformulier</div>
              <ul className="space-y-3">
                {[
                  'Vraagt naam en e-mail maar geeft niks terug',
                  'Bezoeker heeft geen reden om in te vullen',
                  'Conversie gemiddeld 1–2% van bezoekers',
                  'Anonieme bezoekers verlaten de site zonder spoor',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-[14px] text-[var(--fg-muted)]">
                    <span className="text-[var(--fg-subtle)] mt-0.5 shrink-0">—</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="border border-[var(--brand)] bg-[var(--brand-light)] rounded-xl p-7">
              <div className="text-[11px] font-bold uppercase tracking-wider text-[var(--brand)] mb-4">Waardescan widget</div>
              <ul className="space-y-3">
                {[
                  'Geeft de bezoeker direct iets waardevols: een indicatie',
                  'Bezoeker heeft een concrete reden om zijn gegevens achter te laten',
                  'Actief geïnteresseerde bezoekers zetten door',
                  'U ontvangt naam, e-mail en adres. Klaar voor opvolging.',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-[14px] text-[var(--fg)]">
                    <CheckCircle2 size={14} className="text-[var(--brand)] shrink-0 mt-0.5" aria-hidden="true" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Data sources */}
      <section className="py-20 px-4 sm:px-6" aria-labelledby="waardescan-data">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="brand" className="mb-4">Databronnen</Badge>
            <h2 id="waardescan-data" className="text-display-2 text-[var(--fg)]">Gebouwd op betrouwbare data</h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3 max-w-[480px] mx-auto">
              De Waardescan combineert officiële Nederlandse bronnen voor de meest nauwkeurige indicatie.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { name: 'Kadaster', desc: 'BAG-gegevens en historische transactieprijzen uit uw regio. De grondslag van elke waardebepaling.', color: 'bg-[var(--brand-light)]', textColor: 'text-[var(--brand)]' },
              { name: 'CBS', desc: 'Buurtontwikkeling, woningmarktstatistieken en prijsindexen per postcodegebied en gemeente.', color: 'bg-[var(--brand-light)]', textColor: 'text-[var(--brand)]' },
              { name: 'WOZ-referenties', desc: 'Openbaar beschikbare WOZ-gegevens als extra referentie naast transacties en buurtcijfers.', color: 'bg-[var(--brand-light)]', textColor: 'text-[var(--brand)]' },
            ].map((source) => (
              <div key={source.name} className="card p-6">
                <div className="w-10 h-10 rounded-lg bg-[var(--brand-light)] flex items-center justify-center mb-4">
                  <Database size={18} className="text-[var(--brand)]" aria-hidden="true" />
                </div>
                <h3 className="text-heading-3 text-[var(--fg)] mb-2">{source.name}</h3>
                <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed">{source.desc}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 p-5 border border-[var(--border)] rounded-xl bg-[var(--bg-surface)] text-center">
            <p className="text-[14px] text-[var(--fg-muted)]">
              <strong className="text-[var(--fg)]">Belangrijk:</strong> De Waardescan geeft een <em>indicatie</em> van de marktwaarde op basis van beschikbare data. Voor een formele taxatie verwijzen wij naar een gecertificeerd taxateur (NWWI/NRVT).
            </p>
            <p className="mt-3 text-[12px] text-[var(--fg-subtle)]">
              De gegevens worden AVG-conform verwerkt en afgestemd op NVM- en VBO-richtlijnen.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="waardescan-faq">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <h2 id="waardescan-faq" className="text-display-2 text-[var(--fg)]">Veelgestelde vragen</h2>
          </div>
          <div className="space-y-4">
            {FAQS.map((faq) => (
              <div key={faq.q} className="border border-[var(--border)] rounded-xl p-6 bg-[var(--bg-surface)]">
                <h3 className="text-heading-3 text-[var(--fg)] mb-2">{faq.q}</h3>
                <p className="text-[15px] text-[var(--fg-muted)] leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <RelatedArticles posts={RELATED_POSTS} heading="Artikelen over leadgeneratie voor makelaars" />

      <CTABanner />
    </>
  )
}
