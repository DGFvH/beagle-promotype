import type { Metadata } from 'next'
import { Badge } from '@/components/ui/Badge'
import SfeerimpressieMockup from '@/components/ui/mockups/SfeerimpressieMockup'
import { Star, Clock3 } from 'lucide-react'
import RelatedArticles from '@/components/blog/RelatedArticles'
import { buildBreadcrumbList, buildFaqPage, buildService } from '@/lib/jsonld'
import { getBlogPost } from '@/lib/blog-data'

const RELATED_POSTS = [
  'ai-tools-voor-makelaars',
  'leads-genereren-woningwaarde-tool',
]
  .map(getBlogPost)
  .filter((p): p is NonNullable<typeof p> => p !== undefined)

export const metadata: Metadata = {
  title: 'Sfeerimpressie — Laat zien hoe het kan worden | Woninganalyse',
  description:
    'Binnenkort: upload een foto van een ouder pand of ruimte en krijg een impressie van hoe het eruit kan zien na een redesign. Ideaal voor woningen die verbeeldingskracht vragen.',
  alternates: { canonical: 'https://www.woninganalyse.nl/tools/sfeerimpressie' },
  openGraph: {
    title: 'Sfeerimpressie — Laat zien hoe het kan worden | Woninganalyse',
    description:
      'Binnenkort: upload een foto van een ouder pand of ruimte en krijg een impressie van hoe het eruit kan zien na een redesign. Ideaal voor woningen die verbeeldingskracht vragen.',
    url: 'https://www.woninganalyse.nl/tools/sfeerimpressie',
  },
}

const USE_CASES = [
  {
    title: 'Opknappers en verbouwingsprojecten',
    body: 'Kopers zien alleen wat er nu staat, niet wat er kan zijn. Een sfeerimpressie laat zien hoe een kluspand er na verbouwing uit kan zien en verlaagt de drempel om een bod te doen.',
  },
  {
    title: 'Panden met verouderd interieur',
    body: 'Gedateerde kleuren, vloeren of keukenkasten bepalen te veel de eerste indruk. Met een redesign-impressie naast de originele foto geeft u kopers een eerlijker beeld van het potentieel.',
  },
  {
    title: 'Lege of onafgewerkte ruimtes',
    body: 'Een lege ruimte laat nauwelijks zien hoe groot of functioneel hij is. Een ingerichte impressie maakt maat en sfeer direct voelbaar.',
  },
]

const FAQS = [
  {
    q: 'Is de impressie bedoeld als architectuurtekening?',
    a: 'Nee. Het is een marketing-impressie om kopers te helpen de mogelijkheden van een pand te zien — niet een technische of juridisch bindende weergave.',
  },
  {
    q: 'Mag ik de gegenereerde beelden commercieel gebruiken?',
    a: 'Ja. Alle gegenereerde beelden zijn van u en mogen worden gebruikt voor marketingdoeleinden, inclusief Funda, sociale media en drukwerk.',
  },
  {
    q: 'Wanneer komt Sfeerimpressie beschikbaar en wat wordt het kostenmodel?',
    a: 'Sfeerimpressie is in ontwikkeling. Aangemelde makelaars krijgen als eersten toegang zodra de tool live gaat. Het exacte kostenmodel wordt bepaald op basis van de pilot-fase met early adopters; we mikken op een gebruiksgebaseerd abonnement vergelijkbaar met onze andere tools. Meld u aan via het formulier op deze pagina om als eerste op de hoogte te zijn.',
  },
  {
    q: 'Hoe upload ik foto\'s en hoe lang duurt het om resultaten te krijgen?',
    a: 'Bij lancering verwachten we een eenvoudige upload-flow: u kiest een foto van een ruimte (jpg/png), selecteert een gewenste interieurstijl, en ontvangt binnen enkele minuten een gerenderd resultaat. Voor de pilot-versie testen we ook batch-uploads voor kantoren die meerdere objecten tegelijk willen verwerken.',
  },
]

const faqJsonLd = buildFaqPage(FAQS)

const softwareJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'SoftwareApplication',
  name: 'Woninganalyse Sfeerimpressie',
  applicationCategory: 'BusinessApplication',
  operatingSystem: 'Web',
  description:
    'AI-tool die sfeerimpressies genereert voor verbouwingspanden, zodat kopers het potentieel direct zien.',
  offers: { '@type': 'Offer', price: '0', priceCurrency: 'EUR' },
}

const serviceJsonLd = buildService({
  name: 'Woninganalyse Sfeerimpressie',
  description:
    'AI-gestuurde redesign-impressies voor opknappers en verouderde panden — kopers zien direct het potentieel.',
  serviceType: 'Vastgoedvisualisatie',
  url: 'https://www.woninganalyse.nl/tools/sfeerimpressie',
})

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Tools', url: 'https://www.woninganalyse.nl/#tools' },
  { name: 'Sfeerimpressie', url: 'https://www.woninganalyse.nl/tools/sfeerimpressie' },
])

export default function SfeerimpressiePage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      {/* Hero */}
      <section className="pt-28 pb-16 px-4 sm:px-6 dot-grid" aria-labelledby="sfeer-heading">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-14 items-center">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-4">
                <Badge variant="accent">Sfeerimpressie</Badge>
                <span className="text-[11px] font-bold uppercase tracking-wider text-orange-700 bg-orange-50 px-2.5 py-1 rounded-full">
                  Binnenkort
                </span>
              </div>
              <h1 id="sfeer-heading" className="text-display-1 text-[var(--fg)] mb-5">
                Laat zien<br />
                <em className="italic" style={{ color: 'var(--accent)' }}>wat er mogelijk is</em>
              </h1>
              <p className="text-[18px] text-[var(--fg-muted)] leading-relaxed mb-8 max-w-[480px]">
                Upload een foto van een opknapper, verbouwingsproject of pand met verouderd interieur. Sfeerimpressie genereert een beeld van hoe de ruimte eruit kan zien na een redesign, zodat kopers de mogelijkheden zien — niet alleen de huidige staat.
              </p>
              <div className="flex flex-wrap gap-3">
                <form action="/contact" method="GET" className="flex flex-col sm:flex-row gap-3 w-full max-w-md">
                  <input
                    type="text"
                    name="naam"
                    required
                    placeholder="Uw naam"
                    className="flex-1 px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--accent)] transition-colors"
                  />
                  <input
                    type="email"
                    name="email"
                    required
                    placeholder="Uw e-mailadres"
                    className="flex-1 px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--accent)] transition-colors"
                  />
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-orange-700 text-white font-semibold text-[14px] rounded-[6px] hover:bg-orange-800 transition-colors whitespace-nowrap"
                  >
                    Aanmelden
                  </button>
                </form>
              </div>
              <p className="mt-3 text-[13px] text-[var(--fg-subtle)]">
                Aangemelde makelaars ontvangen als eerste toegang bij de lancering.
              </p>
            </div>
            <div className="hidden lg:block lg:w-[45%] shrink-0">
              <SfeerimpressieMockup />
            </div>
          </div>
        </div>
      </section>

      {/* Coming soon banner */}
      <section className="py-4 px-4 sm:px-6 bg-orange-50 border-y border-orange-100">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-[14px] text-orange-700">
            <strong>Sfeerimpressie is in ontwikkeling.</strong>{' '}
            Meld u aan om als eerste toegang te krijgen zodra de tool beschikbaar is.
          </p>
        </div>
      </section>

      {/* Use cases */}
      <section className="py-20 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="sfeer-usecases">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="accent" className="mb-4">Toepassingen</Badge>
            <h2 id="sfeer-usecases" className="text-display-2 text-[var(--fg)]">Wanneer gebruiken makelaars Sfeerimpressie?</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {USE_CASES.map((uc, i) => (
              <div key={i} className="bg-[var(--bg-surface)] border border-[var(--border)] rounded-xl p-6">
                <div className="flex items-center gap-2 mb-3">
                  <Star size={14} className="text-[var(--accent)]" aria-hidden="true" />
                  <h3 className="text-heading-3 text-[var(--fg)]">{uc.title}</h3>
                </div>
                <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed">{uc.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 sm:px-6" aria-labelledby="sfeer-faq">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <h2 id="sfeer-faq" className="text-display-2 text-[var(--fg)]">Veelgestelde vragen</h2>
          </div>
          <div className="space-y-4">
            {FAQS.map((faq) => (
              <div key={faq.q} className="border border-[var(--border)] rounded-xl p-6">
                <h3 className="text-heading-3 text-[var(--fg)] mb-2">{faq.q}</h3>
                <p className="text-[15px] text-[var(--fg-muted)] leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <RelatedArticles posts={RELATED_POSTS} heading="Artikelen over AI voor makelaars" />

      {/* CTA */}
      <section className="py-16 px-4 sm:px-6 bg-[var(--bg-muted)]">
        <div className="max-w-2xl mx-auto text-center">
          <Clock3 size={32} className="text-[var(--accent)] mx-auto mb-4" aria-hidden="true" />
          <h2 className="text-display-2 text-[var(--fg)] mb-4">Op de hoogte blijven?</h2>
          <p className="text-[17px] text-[var(--fg-muted)] mb-7 max-w-[440px] mx-auto">
            Meld u aan en ontvang een bericht zodra Sfeerimpressie beschikbaar is.
          </p>
          <form action="/contact" method="GET" className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="text"
              name="naam"
              required
              placeholder="Uw naam"
              className="flex-1 px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--accent)] transition-colors"
            />
            <input
              type="email"
              name="email"
              required
              placeholder="Uw e-mailadres"
              className="flex-1 px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--accent)] transition-colors"
            />
            <button
              type="submit"
              className="px-5 py-2.5 bg-orange-700 text-white font-semibold text-[14px] rounded-[6px] hover:bg-orange-800 transition-colors whitespace-nowrap"
            >
              Aanmelden
            </button>
          </form>
        </div>
      </section>
    </>
  )
}
