import { buildOGImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE
export const alt = 'Sfeerimpressie — Laat zien hoe het kan worden'

export default function OGImage() {
  return buildOGImage({
    title: 'Sfeerimpressie',
    subtitle: 'Laat kopers zien wat een pand kan worden — niet alleen wat het nu is.',
    badge: 'Tool · Binnenkort',
    accent: 'accent',
  })
}
