import { buildOGImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE
export const alt = 'Huistekst — AI woningbeschrijvingen in seconden'

export default function OGImage() {
  return buildOGImage({
    title: 'Huistekst',
    subtitle: 'AI woningbeschrijvingen in seconden — klaar voor Funda, in elke gewenste taal.',
    badge: 'Tool',
    accent: 'brand',
  })
}
