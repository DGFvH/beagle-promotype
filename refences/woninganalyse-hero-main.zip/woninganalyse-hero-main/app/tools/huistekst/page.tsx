import type { Metadata } from 'next'
import { Clock, Languages, Shield, ArrowRight } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { GesprekInplannenButton } from '@/components/demo/GesprekInplannenButton'
import HuistekstMockup from '@/components/ui/mockups/HuistekstMockup'
import CTABanner from '@/components/sections/CTABanner'
import RelatedArticles from '@/components/blog/RelatedArticles'
import { buildBreadcrumbList, buildFaqPage, buildService } from '@/lib/jsonld'
import { getBlogPost } from '@/lib/blog-data'

const RELATED_POSTS = [
  'woningbeschrijving-schrijven-tips',
  'ai-tools-voor-makelaars',
  'leads-genereren-woningwaarde-tool',
]
  .map(getBlogPost)
  .filter((p): p is NonNullable<typeof p> => p !== undefined)

export const metadata: Metadata = {
  title: 'Huistekst — AI woningbeschrijvingen in seconden',
  description:
    'Genereer professionele woningbeschrijvingen met AI. Van steekwoorden naar publicatieklare verkooptekst in alle talen. Probeer gratis.',
  alternates: { canonical: 'https://www.woninganalyse.nl/tools/huistekst' },
  openGraph: {
    title: 'Huistekst — Schrijf woningbeschrijvingen met AI',
    description:
      'Genereer professionele woningbeschrijvingen met AI. Van steekwoorden naar publicatieklare verkooptekst in alle talen. Probeer gratis.',
    url: 'https://www.woninganalyse.nl/tools/huistekst',
  },
}

const FEATURES = [
  { icon: Clock, title: 'Van kenmerken naar tekst in seconden', body: 'U vult het type, oppervlak, kamers, energielabel en bijzonderheden in. Huistekst schrijft de verkooptekst — klaar voor Funda en uw eigen site.' },
  { icon: Languages, title: 'Meertalige ondersteuning', body: 'Nederlands, Engels, Duits en Frans. Kies bij elke tekst de gewenste toon: zakelijk, warm of luxe.' },
  { icon: Shield, title: 'Altijd aanpasbaar', body: 'De gegenereerde tekst is een sterke basis, geen definitief product. U bewerkt hem naar wens voordat u publiceert.' },
]

const softwareJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'SoftwareApplication',
  name: 'Woninganalyse Huistekst',
  applicationCategory: 'BusinessApplication',
  operatingSystem: 'Web',
  description:
    'AI-tool voor makelaars die in seconden professionele woningbeschrijvingen genereert voor Funda en andere platforms.',
  offers: { '@type': 'Offer', price: '0', priceCurrency: 'EUR' },
}

const serviceJsonLd = buildService({
  name: 'Woninganalyse Huistekst',
  description:
    'AI-gegenereerde Nederlandse, Engelse, Duitse en Franse verkoopteksten voor woningen — klaar voor Funda en eigen kanalen.',
  serviceType: 'Verkooptekstgeneratie',
  url: 'https://www.woninganalyse.nl/tools/huistekst',
})

const FAQS = [
  { q: 'Klinkt de tekst niet robotachtig?', a: 'In de meeste gevallen niet — de AI schrijft in lopende zinnen en past de toon aan op uw keuze. Dat gezegd: het is een startpunt, geen definitief product. Even nalezen en waar nodig bijstellen is altijd verstandig.' },
  { q: 'Wat als mijn kantoor een specifieke schrijfstijl heeft?', a: 'U kiest een toon (warm, zakelijk of luxe) en lengte bij het genereren. Handmatige aanpassingen zijn altijd mogelijk. Fijnere stijlafstemming per kantoor is iets we verder ontwikkelen.' },
  { q: 'Welke talen worden ondersteund?', a: 'Op dit moment Nederlands, Engels, Duits en Frans. Handig als u internationaal georiënteerde kopers bedient of objecten in grensregio\'s heeft.' },
  { q: 'Hoe lang is een gegenereerde beschrijving?', a: 'De standaardtekst is 200–350 woorden — goed bruikbaar voor Funda. U kunt ook een kortere variant kiezen voor social media of een langere voor brochures.' },
  { q: 'Kan ik de tekst aanpassen na het genereren?', a: 'Ja. De gegenereerde tekst is volledig bewerkbaar. U kopieert hem naar uw eigen CMS of bewerkt hem direct. Er zijn geen beperkingen op hoe u de output gebruikt.' },
  { q: 'Wat kost Huistekst per gegenereerde tekst?', a: 'Huistekst werkt met een gebruiksgebaseerd abonnement waarbij u een bundel teksten per maand krijgt. Voor de meeste makelaarskantoren komt dat neer op enkele euro\'s per gegenereerde tekst — een fractie van de tijd die u ermee bespaart. Voor een prijsmodel dat past bij uw transactievolume: vraag een korte demo aan voor een offerte.' },
  { q: 'Voldoen de gegenereerde teksten aan NVM/VBO presentatierichtlijnen?', a: 'De teksten zijn stilistisch en feitelijk consistent met wat NVM- en VBO-makelaars op Funda en eigen websites publiceren. We genereren geen claims of beoordelingen die buiten de objectkenmerken vallen. U houdt altijd de redactionele controle: u kunt elke tekst aanpassen voor publicatie, in lijn met uw branche-richtlijnen en eigen kantoorstijl.' },
]

const faqJsonLd = buildFaqPage(FAQS)

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Tools', url: 'https://www.woninganalyse.nl/#tools' },
  { name: 'Huistekst', url: 'https://www.woninganalyse.nl/tools/huistekst' },
])

export default function HuistekstPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      {/* Hero */}
      <section className="pt-28 pb-16 px-4 sm:px-6 dot-grid" aria-labelledby="huistekst-heading">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row-reverse gap-14 items-center">
            <div className="flex-1">
              <Badge variant="brand" className="mb-4">Huistekst</Badge>
              <h1 id="huistekst-heading" className="text-display-1 text-[var(--fg)] mb-5">
                Woningbeschrijvingen<br />
                in{' '}
                <em className="italic" style={{ color: 'var(--brand)' }}>seconden</em>
              </h1>
              <p className="text-[18px] text-[var(--fg-muted)] leading-relaxed mb-8 max-w-[480px]">
                Van steekwoorden naar een perfecte verkooptekst. Creëer automatisch unieke beschrijvingen in elke gewenste stijl en taal — klaar voor Funda en uw eigen website.
              </p>
              <div className="flex flex-wrap gap-3">
                <GesprekInplannenButton variant="primary" size="lg" className="w-full sm:w-auto" />
              </div>
            </div>
            <div className="hidden lg:block lg:w-[45%] shrink-0">
              <HuistekstMockup />
            </div>
          </div>
        </div>
      </section>

      {/* Why section */}
      <section className="py-16 px-4 sm:px-6 bg-[var(--fg)]" aria-label="Waarom Huistekst">
        <div className="max-w-4xl mx-auto text-center">
          <p
            className="text-[28px] sm:text-[32px] text-white leading-relaxed"
            style={{  fontStyle: 'italic' }}
          >
            &ldquo;Gemiddeld besteedt een makelaar{' '}
            <span style={{ color: 'var(--brand-light)' }}>45 minuten</span>{' '}
            aan het schrijven van één woningbeschrijving. Huistekst doet het in onder de{' '}
            <span style={{ color: 'var(--brand-light)' }}>30 seconden</span>.&rdquo;
          </p>
        </div>
      </section>

      {/* Before / after example */}
      <section className="py-20 px-4 sm:px-6" aria-labelledby="huistekst-voorbeeld">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="brand" className="mb-4">Voorbeeld</Badge>
            <h2 id="huistekst-voorbeeld" className="text-display-2 text-[var(--fg)]">
              Van kenmerken naar verkooptekst
            </h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3 max-w-[480px] mx-auto">
              Dit is wat u invoert — en wat Huistekst er in seconden van maakt.
            </p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr] gap-6 items-start">
            {/* Input */}
            <div className="border border-[var(--border)] rounded-xl overflow-hidden bg-[var(--bg-surface)]">
              <div className="px-5 py-3 border-b border-[var(--border)] bg-[var(--bg-muted)]">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--fg-subtle)]">Uw invoer</span>
              </div>
              <div className="p-5 space-y-3">
                {[
                  { label: 'Type', value: 'Tussenwoning' },
                  { label: 'Oppervlak', value: '110 m²' },
                  { label: 'Slaapkamers', value: '4' },
                  { label: 'Bouwjaar', value: '1987' },
                  { label: 'Energielabel', value: 'C' },
                  { label: 'Bijzonderheden', value: 'Gerenoveerde keuken (2021), zonnepanelen, diepe tuin, nabij centrum' },
                  { label: 'Toon', value: 'Warm / toegankelijk' },
                ].map((row) => (
                  <div key={row.label} className="flex gap-3 text-[13px]">
                    <span className="text-[var(--fg-subtle)] w-28 shrink-0">{row.label}</span>
                    <span className="text-[var(--fg)] font-medium">{row.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Arrow */}
            <div className="hidden lg:flex items-center justify-center pt-32">
              <ArrowRight size={24} className="text-[var(--brand)]" aria-hidden="true" />
            </div>

            {/* Output */}
            <div className="border border-[var(--brand)] rounded-xl overflow-hidden bg-[var(--brand-light)]">
              <div className="px-5 py-3 border-b border-[var(--brand)] bg-[var(--brand-light)]">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[var(--brand)]">Gegenereerde tekst</span>
              </div>
              <div className="p-5 bg-white">
                <p className="text-[14px] text-[var(--fg)] leading-relaxed">
                  Ruim opgezette tussenwoning op een gewilde locatie nabij het centrum. De woning beschikt over vier slaapkamers en een volledig gerenoveerde keuken uit 2021, uitgerust met moderne apparatuur en een strak design.
                </p>
                <p className="text-[14px] text-[var(--fg)] leading-relaxed mt-3">
                  De diepe achtertuin is een echte troef — royaal, zonnig en voorzien van privacy. Dankzij de aanwezige zonnepanelen profiteert u van lagere energielasten, ondanks het C-energielabel.
                </p>
                <p className="text-[14px] text-[var(--fg)] leading-relaxed mt-3">
                  Op loopafstand van winkels, scholen en openbaar vervoer. Een fijne gezinswoning in een rustige straat, met alles wat u nodig heeft binnen handbereik.
                </p>
                <div className="mt-4 flex items-center gap-2 text-[11px] text-[var(--brand)] font-semibold">
                  <Clock size={11} aria-hidden="true" />
                  Gegenereerd in &lt; 10 seconden
                </div>
              </div>
            </div>
          </div>
          <p className="text-center text-[13px] text-[var(--fg-subtle)] mt-6">
            Dit is één van de beschikbare tonen. U kunt ook kiezen voor zakelijk of luxe — en de tekst altijd aanpassen voor publicatie.
          </p>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="huistekst-features">
        <div className="max-w-4xl mx-auto">
          <h2 id="huistekst-features" className="sr-only">Functionaliteit</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            {FEATURES.map((feat) => (
              <div key={feat.title} className="card p-6">
                <div className="w-9 h-9 rounded-lg bg-[var(--brand-light)] flex items-center justify-center mb-4">
                  <feat.icon size={17} className="text-[var(--brand)]" aria-hidden="true" />
                </div>
                <h3 className="text-heading-3 text-[var(--fg)] mb-1.5">{feat.title}</h3>
                <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed">{feat.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="huistekst-faq">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <h2 id="huistekst-faq" className="text-display-2 text-[var(--fg)]">Veelgestelde vragen</h2>
          </div>
          <div className="space-y-4">
            {FAQS.map((faq) => (
              <div key={faq.q} className="border border-[var(--border)] rounded-xl p-6 bg-[var(--bg-surface)]">
                <h3 className="text-heading-3 text-[var(--fg)] mb-2">{faq.q}</h3>
                <p className="text-[15px] text-[var(--fg-muted)] leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <RelatedArticles posts={RELATED_POSTS} heading="Artikelen over AI-woningteksten" />

      <CTABanner />
    </>
  )
}
