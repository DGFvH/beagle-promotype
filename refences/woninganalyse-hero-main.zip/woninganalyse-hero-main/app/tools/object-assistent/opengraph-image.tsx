import { buildOGImage, OG_SIZE, OG_CONTENT_TYPE } from '@/lib/og'

export const size = OG_SIZE
export const contentType = OG_CONTENT_TYPE
export const alt = 'Object Assistent — AI beantwoordt 24/7 objectvragen'

export default function OGImage() {
  return buildOGImage({
    title: 'Object Assistent',
    subtitle: 'AI beantwoordt vragen over uw objecten — 24/7, op basis van uw eigen documentatie.',
    badge: 'Tool',
    accent: 'accent',
  })
}
