import type { Metadata } from 'next'
import { Badge } from '@/components/ui/Badge'
import { GesprekInplannenButton } from '@/components/demo/GesprekInplannenButton'
import ObjectAssistentMockup from '@/components/ui/mockups/ObjectAssistentMockup'
import { MessageCircle, BookOpen, Moon, Shield, Zap, BarChart2 } from 'lucide-react'
import FAQAccordion from '@/components/ui/FAQAccordion'
import RelatedArticles from '@/components/blog/RelatedArticles'
import { buildBreadcrumbList, buildFaqPage, buildService } from '@/lib/jsonld'
import { getBlogPost } from '@/lib/blog-data'

const RELATED_POSTS = [
  'ai-chatbot-objectpagina-use-cases',
  'ai-tools-voor-makelaars',
]
  .map(getBlogPost)
  .filter((p): p is NonNullable<typeof p> => p !== undefined)

export const metadata: Metadata = {
  title: 'Object Assistent — AI beantwoordt 24/7 objectvragen | Woninganalyse',
  description:
    'Upload een brochure; bezoekers stellen vragen over het object wanneer het hen uitkomt. Leads automatisch vastgelegd — ook buiten kantooruren.',
  alternates: { canonical: 'https://www.woninganalyse.nl/tools/object-assistent' },
  openGraph: {
    title: 'Object Assistent — AI beantwoordt 24/7 objectvragen | Woninganalyse',
    description:
      'Upload een brochure; bezoekers stellen vragen over het object wanneer het hen uitkomt. Leads automatisch vastgelegd — ook buiten kantooruren.',
    url: 'https://www.woninganalyse.nl/tools/object-assistent',
  },
}

const FEATURES = [
  { icon: BookOpen, title: 'Gebaseerd op uw documentatie', body: 'Upload uw PDF-brochure of VvE-documenten. De AI leest alles en antwoordt uitsluitend op basis van wat u heeft aangeleverd — geen verzonnen informatie.' },
  { icon: Moon, title: '24/7 beschikbaar', body: 'Werkt op zaterdagavond even goed als op dinsdagochtend. Bezoekers hoeven niet te wachten tot kantooruren voor een antwoord.' },
  { icon: Shield, title: 'Transparant over wat het is', body: 'De assistent stelt zichzelf voor als AI bij aanvang van het gesprek. Geïnteresseerden worden herkend; hun gegevens komen in uw dashboard.' },
]

const SCENARIOS = [
  {
    question: '"Is er vloerverwarming aanwezig?"',
    answer: 'Ja, de woning beschikt over vloerverwarming op de begane grond en de eerste verdieping.',
    tag: 'Technisch',
  },
  {
    question: '"Wat is de maandelijkse VvE-bijdrage?"',
    answer: 'De VvE-bijdrage bedraagt € 145 per maand. Dit dekt het beheer, onderhoud en reservefonds.',
    tag: 'VvE / eigendom',
  },
  {
    question: '"Is de woning geschikt voor een kantoor aan huis?"',
    answer: 'Op basis van het bestemmingsplan is gebruik als werkruimte aan huis toegestaan, mits dit ondergeschikt is aan de woonfunctie.',
    tag: 'Juridisch',
  },
  {
    question: '"Wanneer is de woning beschikbaar voor bezichtiging?"',
    answer: 'De woning staat open voor bezichtigingen op werkdagen tussen 10:00 en 18:00, en op zaterdag op afspraak. U kunt een bezichtiging inplannen via het contactformulier of telefonisch bij het kantoor.',
    tag: 'Praktisch',
  },
  {
    question: '"Is er voldoende parkeergelegenheid in de buurt?"',
    answer: 'Ja. De woning beschikt over een eigen oprit met ruimte voor twee auto\'s. Daarnaast is er parkeerruimte op de openbare weg voor bezoekers.',
    tag: 'Praktisch',
  },
  {
    question: '"Wat is de vraagprijs en zijn er al biedingen?"',
    answer: 'De vraagprijs bedraagt € 425.000 kosten koper. Over de biedingsstatus kan ik geen uitspraken doen — daarvoor verwijs ik u graag door naar het kantoor.',
    tag: 'Prijs / bieden',
  },
]

const FAQS = [
  {
    q: 'Wat als de AI een vraag niet kan beantwoorden?',
    a: 'De assistent geeft eerlijk aan wanneer een antwoord niet in de beschikbare documentatie staat. Hij vraagt de bezoeker dan om hun gegevens achter te laten of verwijst door naar uw kantoor.',
  },
  {
    q: 'Kunnen bezoekers zien dat het een AI is en niet een echte medewerker?',
    a: 'Ja. De assistent stelt zichzelf voor als AI-assistent bij het begin van het gesprek. Er is geen verwarring over wie — of wat — de vragen beantwoordt.',
  },
  {
    q: 'Kan ik de antwoorden aanpassen als de AI iets verkeerd zegt?',
    a: 'Ja. U past de onderliggende documentatie aan in uw dashboard. De assistent werkt altijd op basis van wat u heeft geüpload — pas de bron aan, en de antwoorden veranderen mee.',
  },
  {
    q: 'Hoe accuraat zijn de antwoorden?',
    a: 'Alle antwoorden komen direct uit de documentatie die u heeft geüpload. De AI voegt geen informatie toe die niet in uw brochure of bijlagen staat.',
  },
  {
    q: 'Kan ik de assistent inzetten voor meerdere objecten tegelijk?',
    a: 'Ja. Elk object krijgt zijn eigen assistent met eigen documentatie. U beheert alle objecten vanuit één dashboard.',
  },
  {
    q: 'Wat kost Object Assistent per object of per maand?',
    a: 'Object Assistent werkt op een gebruiksgebaseerd abonnement: u betaalt voor het aantal actieve objecten waarop de chatbot draait. Voor de meeste kantoren komt dat neer op enkele euro\'s per object per maand — vergelijkbaar met of lager dan de tijd die het bespaart op repetitieve vragen. Voor een prijsmodel dat past bij uw aantal actieve objecten: vraag een persoonlijke offerte aan via een korte demo.',
  },
  {
    q: 'Hoe snel staat de chatbot live in mijn merkidentiteit?',
    a: 'Voor een standaard objectpagina is de installatie ~10 minuten: u plakt één regel code op de pagina en uploadt de objectbrochure. De configuratie van uw merkidentiteit (logo, kleur, welkomstboodschap) doet u in het dashboard. De chatbot leest de documentatie zelf in en is direct bruikbaar. Geen aparte training, geen IT-traject.',
  },
]

const faqJsonLd = buildFaqPage(FAQS)

const softwareJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'SoftwareApplication',
  name: 'Woninganalyse Object Assistent',
  applicationCategory: 'BusinessApplication',
  operatingSystem: 'Web',
  description:
    'AI-chatbot voor makelaars die 24/7 objectvragen beantwoordt op basis van de woningbrochure.',
  offers: { '@type': 'Offer', price: '0', priceCurrency: 'EUR' },
}

const serviceJsonLd = buildService({
  name: 'Woninganalyse Object Assistent',
  description:
    'AI-chatbot per object: beantwoordt vragen 24/7 op basis van uw eigen brochure en vangt serieuze interesse als lead op.',
  serviceType: 'AI-objectassistentie',
  url: 'https://www.woninganalyse.nl/tools/object-assistent',
})

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Tools', url: 'https://www.woninganalyse.nl/#tools' },
  { name: 'Object Assistent', url: 'https://www.woninganalyse.nl/tools/object-assistent' },
])

export default function ObjectAssistentPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(softwareJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      {/* Hero */}
      <section className="pt-28 pb-16 px-4 sm:px-6 dot-grid" aria-labelledby="assistent-heading">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row-reverse gap-14 items-center">
            <div className="flex-1">
              <Badge variant="accent" className="mb-4">Object Assistent</Badge>
              <h1 id="assistent-heading" className="text-display-1 text-[var(--fg)] mb-5">
                24/7 vragen<br />
                <em className="italic" style={{ color: 'var(--accent)' }}>beantwoorden</em>
              </h1>
              <p className="text-[18px] text-[var(--fg-muted)] leading-relaxed mb-4 max-w-[480px]">
                Upload een brochure en laat AI alle vragen over het object beantwoorden. Serieuze geïnteresseerden worden automatisch vastgelegd — ook buiten kantooruren.
              </p>
              <p className="text-[15px] text-[var(--fg-subtle)] leading-relaxed mb-8 max-w-[480px]">
                U plaatst de widget via één regel code op uw objectpagina. De assistent leest uw documentatie en geeft direct antwoord — op basis van precies wat u heeft geüpload, niets meer.
              </p>
              <div className="flex flex-wrap gap-3">
                <GesprekInplannenButton variant="primary" size="lg" className="w-full sm:w-auto" />
              </div>
            </div>
            <div className="hidden lg:block lg:w-[45%] shrink-0">
              <ObjectAssistentMockup />
            </div>
          </div>
        </div>
      </section>

      {/* Scenarios */}
      <section className="py-20 px-4 sm:px-6" aria-labelledby="assistent-scenarios">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="accent" className="mb-4">Voorbeelden</Badge>
            <h2 id="assistent-scenarios" className="text-display-2 text-[var(--fg)]">
              Vragen die de assistent beantwoordt
            </h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3 max-w-[460px] mx-auto">
              Op basis van uw eigen documentatie — altijd accuraat, nooit verzonnen.
            </p>
          </div>
          <div className="space-y-4">
            {SCENARIOS.map((s, i) => (
              <div key={i} className="border border-[var(--border)] rounded-xl p-6 bg-[var(--bg-surface)]">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 rounded-full bg-[var(--bg-muted)] flex items-center justify-center shrink-0 mt-0.5">
                    <MessageCircle size={14} className="text-[var(--fg-subtle)]" aria-hidden="true" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <p className="text-[15px] font-semibold text-[var(--fg)]">{s.question}</p>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[var(--fg-subtle)] bg-[var(--bg-muted)] px-2 py-0.5 rounded-full shrink-0">
                        {s.tag}
                      </span>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-full bg-orange-50 flex items-center justify-center shrink-0">
                        <Zap size={13} className="text-[var(--accent)]" aria-hidden="true" />
                      </div>
                      <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed pt-1">{s.answer}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="assistent-features">
        <div className="max-w-4xl mx-auto">
          <h2 id="assistent-features" className="sr-only">Functionaliteit</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            {FEATURES.map((feat) => (
              <div key={feat.title} className="card p-6 flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-orange-50 flex items-center justify-center shrink-0">
                  <feat.icon size={18} className="text-[var(--accent)]" aria-hidden="true" />
                </div>
                <div>
                  <h3 className="text-heading-3 text-[var(--fg)] mb-1">{feat.title}</h3>
                  <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed">{feat.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 sm:px-6" aria-labelledby="assistent-faq">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <h2 id="assistent-faq" className="text-display-2 text-[var(--fg)]">Veelgestelde vragen</h2>
          </div>
          <FAQAccordion items={FAQS} />
        </div>
      </section>

      <RelatedArticles posts={RELATED_POSTS} heading="Artikelen over AI-chatbots en objectvragen" />

      {/* CTA */}
      <section className="py-16 px-4 sm:px-6 bg-[var(--bg-muted)]">
        <div className="max-w-2xl mx-auto text-center">
          <BarChart2 size={32} className="text-[var(--accent)] mx-auto mb-4" aria-hidden="true" />
          <h2 className="text-display-2 text-[var(--fg)] mb-4">Nooit meer een vraag missen</h2>
          <p className="text-[17px] text-[var(--fg-muted)] mb-7 max-w-[440px] mx-auto">
            Zet Object Assistent op uw objectpagina&apos;s en laat bezoekers 24/7 geholpen worden — terwijl u serieuze leads binnenkrijgt.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <GesprekInplannenButton variant="primary" size="lg" />
          </div>
        </div>
      </section>
    </>
  )
}
