import { ImageResponse } from 'next/og'

export const alt = 'Woninganalyse — Slimme tools voor makelaars'
export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'

export default function OGImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #2563eb 100%)',
          fontFamily: 'system-ui, sans-serif',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: 80,
            height: 80,
            background: 'rgba(255,255,255,0.15)',
            borderRadius: 20,
            marginBottom: 32,
          }}
        >
          <span style={{ fontSize: 48, fontWeight: 700, color: '#fff' }}>W</span>
        </div>
        <span
          style={{
            fontSize: 52,
            fontWeight: 700,
            color: '#fff',
            marginBottom: 16,
          }}
        >
          Woninganalyse
        </span>
        <span
          style={{
            fontSize: 24,
            color: 'rgba(255,255,255,0.8)',
            maxWidth: 600,
            textAlign: 'center',
          }}
        >
          Slimme tools voor makelaars: leads, teksten en meer
        </span>
      </div>
    ),
    { ...size }
  )
}
