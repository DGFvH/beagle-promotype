import type { Metadata } from 'next'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { GesprekInplannenButton } from '@/components/demo/GesprekInplannenButton'
import { buildBreadcrumbList } from '@/lib/jsonld'

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Over ons', url: 'https://www.woninganalyse.nl/over-ons' },
])

export const metadata: Metadata = {
  title: 'Over Woninganalyse',
  description: 'Woninganalyse ontwikkelt AI-tools voor makelaars. Leer meer over onze missie, visie en de technologie achter onze producten.',
  alternates: { canonical: 'https://www.woninganalyse.nl/over-ons' },
  openGraph: {
    title: 'Over Woninganalyse',
    description: 'Woninganalyse ontwikkelt AI-tools voor makelaars. Leer meer over onze missie, visie en de technologie achter onze producten.',
    url: 'https://www.woninganalyse.nl/over-ons',
  },
}

export default function OverOnsPage() {
  return (
    <article className="pt-28 pb-24 px-4 sm:px-6">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-14">
          <Badge variant="brand" className="mb-4">Over ons</Badge>
          <h1 className="text-display-1 text-[var(--fg)] mb-5">
            Technologie voor de makelaar van morgen
          </h1>
          <p className="text-[18px] text-[var(--fg-muted)] leading-relaxed max-w-[560px] mx-auto">
            Woninganalyse is het AI-bureau voor de Nederlandse makelaardij. We bedenken, bouwen en implementeren AI-oplossingen die makelaars helpen sneller te werken, meer leads te genereren en professioneler te presenteren.
          </p>
        </div>

        <div className="space-y-10 text-[16px] text-[var(--fg-muted)] leading-relaxed">
          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-4" style={{ fontSize: 'clamp(20px, 3vw, 28px)' }}>
              Onze missie
            </h2>
            <p>
              De Nederlandse woningmarkt is competitief en snel. Makelaars die vooroplopen investeren in technologie. Toch zijn de meeste tools op de markt complex, duur of niet afgestemd op de dagelijkse realiteit van een makelaarskantoor.
            </p>
            <p className="mt-3">
              Wij geloven dat AI-tools eenvoudig, betrouwbaar en direct inzetbaar moeten zijn. Geen langdurige implementaties, geen ingewikkelde dashboards — gewoon tools die werken. Vanaf dag één.
            </p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-4" style={{ fontSize: 'clamp(20px, 3vw, 28px)' }}>
              Onze technologie
            </h2>
            <p>
              Woninganalyse combineert officiële data van het Kadaster en het CBS met openbare marktgegevens en moderne AI-modellen. Het resultaat: bruikbare waarde-indicaties, professionele verkoopteksten en slimme leadgeneratie — alles binnen seconden.
            </p>
          </section>

          <section>
            <h2 className="text-display-2 text-[var(--fg)] mb-4" style={{ fontSize: 'clamp(20px, 3vw, 28px)' }}>
              Vertrouwd door makelaars
            </h2>
            <p>
              Actief bij makelaars door heel Nederland — van zelfstandige NVM-makelaars tot grotere VBO-kantoren.
            </p>
          </section>
        </div>

        <div className="mt-12 pt-8 border-t border-[var(--border)] text-center">
          <h2 className="text-display-2 text-[var(--fg)] mb-4" style={{ fontSize: 'clamp(20px, 3vw, 28px)' }}>
            Zelf ervaren?
          </h2>
          <p className="text-[16px] text-[var(--fg-muted)] mb-6">
            Plan een vrijblijvend gesprek of neem contact met ons op.
          </p>
          <div className="flex flex-col sm:flex-row sm:flex-wrap justify-center gap-3">
            <GesprekInplannenButton variant="primary" size="lg" className="w-full sm:w-auto" />
            <Button href="/contact" variant="secondary" size="lg" className="w-full sm:w-auto">
              Contact opnemen
            </Button>
          </div>
        </div>
      </div>
    </article>
  )
}
