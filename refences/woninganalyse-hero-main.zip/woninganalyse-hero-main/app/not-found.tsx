import Link from 'next/link'
import { Button } from '@/components/ui/Button'
import { Home, ArrowLeft } from 'lucide-react'

export default function NotFound() {
  return (
    <section className="flex flex-col items-center justify-center min-h-[60vh] px-4 py-20 text-center">
      <div
        className="text-[120px] font-bold leading-none mb-6 select-none"
        style={{
          color: 'var(--border)',
          lineHeight: 1,
        }}
        aria-hidden="true"
      >
        404
      </div>
      <h1 className="text-display-2 text-[var(--fg)] mb-4">
        Pagina niet gevonden
      </h1>
      <p className="text-[17px] text-[var(--fg-muted)] max-w-[400px] leading-relaxed mb-9">
        De pagina die u zoekt bestaat niet meer of is verplaatst. Ga terug naar de homepage.
      </p>
      <div className="flex flex-wrap items-center justify-center gap-3">
        <Button href="/" variant="primary" size="lg">
          <Home size={15} aria-hidden="true" />
          Terug naar homepage
        </Button>
        <Button href="/tools/waardescan" variant="secondary" size="lg">
          Bekijk onze tools
        </Button>
      </div>
    </section>
  )
}
