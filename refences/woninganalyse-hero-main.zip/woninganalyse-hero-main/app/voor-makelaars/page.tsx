import type { Metadata } from 'next'
import { Badge } from '@/components/ui/Badge'
import { GesprekInplannenButton } from '@/components/demo/GesprekInplannenButton'
import CTABanner from '@/components/sections/CTABanner'
import {
  CheckCircle2, X, ArrowRight,
} from 'lucide-react'
import Link from 'next/link'
import { buildBreadcrumbList } from '@/lib/jsonld'

const breadcrumbJsonLd = buildBreadcrumbList([
  { name: 'Home', url: 'https://www.woninganalyse.nl' },
  { name: 'Voor Makelaars', url: 'https://www.woninganalyse.nl/voor-makelaars' },
])

export const metadata: Metadata = {
  title: 'Woninganalyse voor Makelaars — AI-consultancy voor de makelaardij',
  description:
    'Hoe een AI-bureau makelaars helpt meer leads te genereren, routineklussen weg te nemen en professioneler te presenteren. Voor zelfstandigen en kantoren.',
  alternates: { canonical: 'https://www.woninganalyse.nl/voor-makelaars' },
  openGraph: {
    title: 'Woninganalyse voor Makelaars',
    description:
      'Hoe een AI-bureau makelaars helpt meer leads te genereren, routineklussen weg te nemen en professioneler te presenteren. Voor zelfstandigen en kantoren.',
    url: 'https://www.woninganalyse.nl/voor-makelaars',
  },
}

const COMPARISONS = [
  {
    task: 'Woningbeschrijving voor Funda',
    before: { label: 'Zoals het nu gaat', detail: '30–45 minuten per woning. Inconsistent afhankelijk van vermoeidheid of haast.' },
    after: { label: 'Met de juiste AI', detail: 'Onder de 30 seconden, in uw eigen toon. Wij bouwden Huistekst precies hiervoor — een voorbeeld van wat we voor makelaars maken.', tool: 'Huistekst', href: '/tools/huistekst' },
  },
  {
    task: 'Leads van uw website',
    before: { label: 'Zoals het nu gaat', detail: 'Een contactformulier dat bezoekers zelden invullen. Waardevolle interesse loopt ongezien weg.' },
    after: { label: 'Met de juiste AI', detail: 'Bezoekers vragen een waarde-indicatie aan en laten hun gegevens achter. We bouwden de Waardescan om dit verkeer in leads om te zetten.', tool: 'Waardescan', href: '/tools/waardescan' },
  },
  {
    task: 'Vragen over een object',
    before: { label: 'Zoals het nu gaat', detail: 'Dezelfde vragen, steeds opnieuw. Buiten kantooruren komen ze binnen, maar worden ze pas de volgende dag beantwoord.' },
    after: { label: 'Met de juiste AI', detail: 'AI beantwoordt elke vraag op basis van uw eigen brochure — 24/7, direct. Object Assistent laat zien hoe we dat voor uw objecten inrichten.', tool: 'Object Assistent', href: '/tools/object-assistent' },
  },
]

const OBJECTIONS = [
  {
    objection: '"Is AI niet te complex voor mijn kantoor?"',
    answer: 'Daarom werkt u met ons. Wij vertalen AI naar concrete oplossingen die in uw werkdag passen — u hoeft de techniek niet te begrijpen. We adviseren wat zinvol is, bouwen het en zorgen dat het werkt. U houdt de regie, wij doen het zware werk.',
  },
  {
    objection: '"Moet ik mijn website of systemen vervangen?"',
    answer: 'Nee. Onze oplossingen werken bóven op wat u al heeft. De Waardescan staat met één script-tag op uw bestaande site, in uw eigen huisstijl. We sluiten aan op uw werkwijze in plaats van die om te gooien.',
  },
  {
    objection: '"Werkt dit ook voor een klein kantoor?"',
    answer: 'Juist voor zelfstandigen en kleinere kantoren maakt AI het verschil: u doet meer met minder handen. We werken met zowel zelfstandige NVM-makelaars als grotere VBO-kantoren en schalen de aanpak op uw situatie.',
  },
  {
    objection: '"Hoe ziet een traject met jullie eruit?"',
    answer: 'We beginnen met een vrijblijvend gesprek over waar in uw kantoor de meeste tijd of omzet blijft liggen. Daarna adviseren we gericht, laten we zien wat we al bouwden en zetten we stap voor stap in wat aantoonbaar oplevert. Geen langdurige IT-projecten.',
  },
]

export default function VoorMakelaarsPage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />
      {/* Hero */}
      <section className="pt-28 pb-20 px-4 sm:px-6 dot-grid" aria-labelledby="makelaars-heading">
        <div className="max-w-[760px] mx-auto text-center">
          <Badge variant="brand" className="mb-5">Voor makelaars</Badge>
          <h1 id="makelaars-heading" className="text-display-1 text-[var(--fg)] mb-5">
            AI die uw kantoor{' '}
            <em className="italic" style={{ color: 'var(--brand)' }}>écht verder helpt</em>
          </h1>
          <p className="text-[18px] text-[var(--fg-muted)] leading-relaxed mb-9 max-w-[580px] mx-auto">
            Als AI-bureau voor de makelaardij kijken we mee waar uw tijd en leads weglekken — en bouwen we de oplossing. Van Funda-teksten en leadgeneratie tot 24/7 objectvragen. Wat we al maakten, ziet u hieronder.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-3 mb-8">
            <GesprekInplannenButton variant="primary" size="lg" />
          </div>
          <div className="flex flex-wrap justify-center gap-x-6 gap-y-2">
            {['Vrijblijvend kennismaken', 'Werkt op uw bestaande website', 'Bewezen bij NVM- & VBO-makelaars'].map((t) => (
              <span key={t} className="flex items-center gap-1.5 text-[13px] text-[var(--fg-subtle)]">
                <CheckCircle2 size={12} className="text-[var(--success)]" aria-hidden="true" />
                {t}
              </span>
            ))}
          </div>
          <p className="mt-6 text-[12px] text-[var(--fg-subtle)] text-center">
            Gebouwd op Kadaster · CBS · WOZ · BAG · AVG-conform · NVM/VBO
          </p>
        </div>
      </section>

      {/* Old vs. new comparison */}
      <section className="py-24 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="vergelijking-heading">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <Badge variant="brand" className="mb-4">Oud vs. nieuw</Badge>
            <h2 id="vergelijking-heading" className="text-display-2 text-[var(--fg)]">
              Waar AI het verschil maakt in uw werkdag
            </h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3 max-w-[560px] mx-auto">
              Drie plekken waar makelaars dagelijks tijd of leads verliezen — en hoe wij die met AI oplossen. De tools zijn voorbeelden van wat we al voor de markt bouwden.
            </p>
          </div>
          <div className="space-y-8">
            {COMPARISONS.map((item) => (
              <div key={item.task} className="border border-[var(--border)] rounded-2xl overflow-hidden">
                <div className="px-6 py-3 bg-[var(--bg-surface)] border-b border-[var(--border)]">
                  <span className="text-[12px] font-bold uppercase tracking-wider text-[var(--fg-subtle)]">{item.task}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2">
                  {/* Before */}
                  <div className="p-6 md:border-r border-[var(--border)]">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-5 h-5 rounded-full bg-[var(--bg-muted)] flex items-center justify-center shrink-0">
                        <X size={11} className="text-[var(--fg-subtle)]" aria-hidden="true" />
                      </div>
                      <span className="text-[13px] font-semibold text-[var(--fg-muted)]">{item.before.label}</span>
                    </div>
                    <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed">{item.before.detail}</p>
                  </div>
                  {/* After */}
                  <div className="p-6 bg-[var(--brand-light)]">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-5 h-5 rounded-full bg-[var(--brand)] flex items-center justify-center shrink-0">
                        <CheckCircle2 size={11} className="text-white" aria-hidden="true" />
                      </div>
                      <span className="text-[13px] font-semibold text-[var(--brand)]">{item.after.label}</span>
                    </div>
                    <p className="text-[14px] text-[var(--fg)] leading-relaxed mb-3">{item.after.detail}</p>
                    <Link
                      href={item.after.href}
                      className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-[var(--brand)] hover:text-[var(--brand-dark)] transition-colors group"
                    >
                      Meer over {item.after.tool}
                      <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" aria-hidden="true" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Objections */}
      <section className="py-24 px-4 sm:px-6" aria-labelledby="bezwaren-heading">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-14">
            <Badge variant="brand" className="mb-4">Veelgestelde vragen</Badge>
            <h2 id="bezwaren-heading" className="text-display-2 text-[var(--fg)]">
              Wat makelaars zich afvragen
            </h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3 max-w-[520px] mx-auto">
              De vragen die we het vaakst horen over samenwerken met een AI-bureau — en onze eerlijke antwoorden.
            </p>
          </div>
          <div className="space-y-5">
            {OBJECTIONS.map((item) => (
              <div
                key={item.objection}
                className="border border-[var(--border)] rounded-xl p-6 sm:p-7 hover:border-[var(--border-hover)] transition-colors"
              >
                <p className="text-[16px] font-semibold text-[var(--fg)] mb-3 italic">{item.objection}</p>
                <p className="text-[15px] text-[var(--fg-muted)] leading-relaxed">{item.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Blog links */}
      <section className="py-16 px-4 sm:px-6 bg-[var(--bg-muted)]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-display-2 text-[var(--fg)] mb-4">Meer lezen over AI voor makelaars</h2>
          <p className="text-[17px] text-[var(--fg-muted)] mb-8 max-w-[520px] mx-auto">
            Op onze blog schrijven we over AI-tools, leadgeneratie en woningwaardering — specifiek voor de Nederlandse makelaarsmarkt.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              href="/blog/ai-tools-voor-makelaars"
              className="inline-flex items-center gap-1.5 text-[15px] font-semibold text-[var(--brand)] hover:text-[var(--brand-dark)] transition-colors"
            >
              AI-tools voor makelaars <ArrowRight size={14} aria-hidden="true" />
            </Link>
            <Link
              href="/blog/leads-genereren-woningwaarde-tool"
              className="inline-flex items-center gap-1.5 text-[15px] font-semibold text-[var(--brand)] hover:text-[var(--brand-dark)] transition-colors"
            >
              Leadgeneratie met een woningwaarde-tool <ArrowRight size={14} aria-hidden="true" />
            </Link>
          </div>
        </div>
      </section>

      {/* Demo form */}
      <section id="demo-form" className="py-20 px-4 sm:px-6 bg-[var(--bg-muted)]" aria-labelledby="demo-heading">
        <div className="max-w-xl mx-auto">
          <div className="text-center mb-10">
            <Badge variant="brand" className="mb-4">Gesprek inplannen</Badge>
            <h2 id="demo-heading" className="text-display-2 text-[var(--fg)]">
              Vrijblijvend kennismaken in 20 minuten
            </h2>
            <p className="text-[17px] text-[var(--fg-muted)] mt-3">
              Laat uw gegevens achter. We denken met u mee over waar AI uw kantoor het meeste oplevert — en laten zien wat we al bouwden.
            </p>
          </div>
          <div className="bg-[var(--bg-surface)] border border-[var(--border)] rounded-2xl p-7 sm:p-9">
            <form action="/contact" method="GET" className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="naam" className="block text-[13px] font-semibold text-[var(--fg)] mb-1.5">
                    Naam <span aria-hidden="true" className="text-[var(--accent)]">*</span>
                  </label>
                  <input type="text" id="naam" name="naam" required placeholder="Jan de Vries"
                    className="w-full px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--brand)] transition-colors" />
                </div>
                <div>
                  <label htmlFor="kantoor" className="block text-[13px] font-semibold text-[var(--fg)] mb-1.5">Kantoor</label>
                  <input type="text" id="kantoor" name="kantoor" placeholder="De Vries Makelaars"
                    className="w-full px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--brand)] transition-colors" />
                </div>
              </div>
              <div>
                <label htmlFor="email-makelaars" className="block text-[13px] font-semibold text-[var(--fg)] mb-1.5">
                  E-mailadres <span aria-hidden="true" className="text-[var(--accent)]">*</span>
                </label>
                <input type="email" id="email-makelaars" name="email" required placeholder="jan@kantoor.nl"
                  className="w-full px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--brand)] transition-colors" />
              </div>
              <div>
                <label htmlFor="telefoon" className="block text-[13px] font-semibold text-[var(--fg)] mb-1.5">Telefoonnummer</label>
                <input type="tel" id="telefoon" name="telefoon" placeholder="+31 6 12 34 56 78"
                  className="w-full px-3.5 py-2.5 text-[14px] border border-[var(--border)] rounded-[6px] bg-[var(--bg)] text-[var(--fg)] placeholder:text-[var(--fg-subtle)] focus:outline-none focus:border-[var(--brand)] transition-colors" />
              </div>
              <button type="submit"
                className="w-full py-3 bg-[var(--brand)] text-white font-semibold text-[15px] rounded-[6px] hover:bg-[var(--brand-dark)] transition-colors mt-1">
                Gesprek inplannen →
              </button>
              <p className="text-[12px] text-[var(--fg-subtle)] text-center">Geen verplichtingen. Wij nemen binnen 1 werkdag contact op.</p>
            </form>
          </div>
        </div>
      </section>

      <CTABanner />
    </>
  )
}
