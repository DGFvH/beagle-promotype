import type { MetadataRoute } from 'next'
import { blogPosts } from '@/lib/blog-data'

export default function sitemap(): MetadataRoute.Sitemap {
  const staticRoutes: MetadataRoute.Sitemap = [
    {
      url: 'https://www.woninganalyse.nl',
      changeFrequency: 'weekly',
      priority: 1.0,
    },
    {
      url: 'https://www.woninganalyse.nl/voor-makelaars',
      changeFrequency: 'monthly',
      priority: 0.9,
    },
    {
      url: 'https://www.woninganalyse.nl/tools/waardescan',
      changeFrequency: 'monthly',
      priority: 0.9,
    },
    {
      url: 'https://www.woninganalyse.nl/tools/huistekst',
      changeFrequency: 'monthly',
      priority: 0.8,
    },
    {
      url: 'https://www.woninganalyse.nl/tools/sfeerimpressie',
      changeFrequency: 'monthly',
      priority: 0.7,
    },
    {
      url: 'https://www.woninganalyse.nl/tools/object-assistent',
      changeFrequency: 'monthly',
      priority: 0.7,
    },
    {
      url: 'https://www.woninganalyse.nl/demo',
      changeFrequency: 'monthly',
      priority: 0.8,
    },
    {
      url: 'https://www.woninganalyse.nl/blog',
      changeFrequency: 'weekly',
      priority: 0.8,
    },
    {
      url: 'https://www.woninganalyse.nl/over-ons',
      changeFrequency: 'yearly',
      priority: 0.4,
    },
    {
      url: 'https://www.woninganalyse.nl/contact',
      changeFrequency: 'yearly',
      priority: 0.5,
    },
    {
      url: 'https://www.woninganalyse.nl/privacybeleid',
      changeFrequency: 'yearly',
      priority: 0.2,
    },
    {
      url: 'https://www.woninganalyse.nl/gebruiksvoorwaarden',
      changeFrequency: 'yearly',
      priority: 0.2,
    },
  ]

  const blogRoutes: MetadataRoute.Sitemap = blogPosts.map((post) => ({
    url: `https://www.woninganalyse.nl/blog/${post.slug}`,
    lastModified: new Date(post.date),
    changeFrequency: 'monthly' as const,
    priority: 0.7,
  }))

  return [...staticRoutes, ...blogRoutes]
}
