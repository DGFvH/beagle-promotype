import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: {
      userAgent: '*',
      allow: '/',
      // /m/ intentionally NOT disallowed — marketing's /m/{slug} is canonical
      // for makelaar pages (see HANDOFF.md §2). Google must crawl here to
      // read the canonical tag emitted by platform's proxied HTML.
      disallow: ['/api/', '/preview/'],
    },
    sitemap: 'https://www.woninganalyse.nl/sitemap.xml',
  }
}
