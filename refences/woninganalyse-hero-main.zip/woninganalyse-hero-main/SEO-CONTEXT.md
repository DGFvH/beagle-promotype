# SEO Context — Woninganalyse Platform

> **Purpose**: This document is a hand-off from the **platform repo** (`platform.woninganalyse.nl`, this repo) to the **marketing/landing repo** (`woninganalyse.nl`, hosted separately on Framer). It captures everything an SEO project needs to know about the product, audience, current SEO surface area, domain architecture, and the cross-domain pitfalls that need to be coordinated between the two repos.

---

## 1. Product summary

**Woninganalyse** is a Dutch B2B SaaS for real-estate agents (NVM- en VBO-makelaars). It ships 5 tools that makelaars embed on their own websites or use from a dashboard:

| Product | Description | Primary value |
|---|---|---|
| **Waardescan** | White-label AI woningwaardering tool ("wat is mijn huis waard?") embedded on a makelaar's site. Lead-capture flow at the end. | Leadgeneratie voor makelaars |
| **Huistekst Generator** | AI-generated Nederlandse woningteksten (verkoopteksten) | Tijdsbesparing op listings |
| **Sfeerimpressie** | Virtuele inrichting + renovatievisualisatie van foto's | Verkoop-conversie |
| **Woningchat** | Embeddable AI chatbot per object/listing (`widget.js`) — drijft op object-data | 24/7 vragen beantwoorden over een woning |
| **Lead Management** | Dashboard met alle leads uit alle tools | CRM-light voor makelaars |

The Waardescan is the flagship and the lead-magnet that brings makelaars into the funnel. The end-consumer (huiseigenaar) sees the white-labelled makelaar branding, not Woninganalyse.

**Data sources used (mention in trust-content)**: Kadaster (BAG), CBS, WOZ-waardes, PDOK, EP-online (energielabel).

---

## 2. Domain & URL architecture

This is the single most important SEO concern — there are TWO codebases serving ONE brand and they need to stay aligned.

```
woninganalyse.nl              → Framer marketing site (separate repo)
www.woninganalyse.nl          → same (canonical host, see commit 41fc77a)
platform.woninganalyse.nl     → THIS React app (login, dashboard, branded tools)
```

### Public routes on the platform (this app) the marketing site may want to link to or canonicalise:

| Route | Purpose | Public/Indexable? |
|---|---|---|
| `/login` | Makelaar login | Indexable but low priority |
| `/register?ref=<slug>` | Sign-up, with optional referral attribution | Indexable |
| `/demo` | Public demo flow of the Waardescan | **High SEO value** — should likely be linked from marketing as "Probeer demo" |
| `/m/:slug` | White-label makelaar page (consumer-facing waardescan, e.g. `/m/janssen-makelaars`) | **High volume, high value** — long-tail "{makelaar-naam} waardecheck" / local SEO surface |
| `/chat/:agentSlug/:objectSlug` | Public WoningChat for a specific listing | Indexable, but typically deep-linked from a listing — likely `noindex` to avoid thin-content |
| `/preview/:slug` | Sales demo previews (internal, marketing-y) | Should probably be `noindex` |
| `/dashboard/*`, `/admin/*`, `/onboarding`, `/verify-email`, `/reset-password`, `/forgot-password` | Authenticated app | `noindex` — must be excluded from sitemap |

### Canonical / cross-domain rules

- **Marketing pages** → canonical to `https://www.woninganalyse.nl/...`
- **Tool/product detail pages on marketing** that mirror functionality at `platform.woninganalyse.nl` → keep canonical on **marketing** and link out to platform as a CTA, not as a duplicate page
- **Branded makelaar pages** (`/m/:slug`) live on platform — they should self-canonical to the platform URL. Marketing should never duplicate these.
- **Demo** → the marketing site likely has a "Probeer de demo" CTA; the actual interactive demo is at `platform.woninganalyse.nl/demo`. Decide ONE canonical home for the word "demo" — recommend marketing has the explainer page, platform has the live tool, and they cross-link.

---

## 3. Target audience & search intent

There are **two distinct audiences** with different keywords. The marketing site (woninganalyse.nl) should serve the B2B audience first; the platform's `/m/:slug` pages serve the B2C audience under the makelaar's brand.

### B2B (primary for marketing site)
Buyer = NVM/VBO makelaar, kantoorhouder, marketing-verantwoordelijke bij een makelaardij.

Target keywords (Dutch):
- woningwaarde tool makelaar
- leadgeneratie makelaars
- white-label woningwaarde
- AI tools voor makelaars
- woningteksten generator
- AI chatbot makelaar / woningchat
- virtuele inrichting makelaar
- NVM makelaar tools / VBO makelaar tools
- waardecheck op eigen website

### B2C (primary for platform `/m/:slug` and `/demo`, secondary on marketing)
Searcher = huiseigenaar overweegt verkoop / nieuwsgierig naar waarde.

Target keywords (Dutch):
- hoeveel is mijn huis waard
- wat is mijn huis waard
- woningwaarde berekenen
- huiswaarde online
- gratis woningtaxatie
- WOZ-waarde vs marktwaarde
- huiswaarde + {gemeente/postcode}  ← long-tail, most volume

The B2C terms historically anchored an old domain (`hoeveelismijnhuiswaard.net` — see §6) and still appear in this app's `index.html`. The marketing repo should decide whether to chase B2C terms on `woninganalyse.nl` or keep them on the makelaar's branded `/m/:slug` pages.

---

## 4. Brand voice & messaging

- **Language**: Dutch (`nl_NL`), `<html lang="nl">`. Never English on public pages.
- **Tone B2B**: zakelijk, helder, vakgenoot. "Genereer meer leads", "in uw eigen huisstijl", "voor NVM en VBO makelaars". `u`-vorm.
- **Tone B2C** (consumer-facing waardescan): warm, vriendelijk, betrouwbaar. `je`-vorm. "Wat is jouw huis waard?", "binnen 30 seconden", "gratis en vrijblijvend".
- **Trust anchors** (use everywhere): Kadaster · CBS · WOZ · BAG · AVG-conform · NVM/VBO

### Established taglines/copy from this repo (reuse as-is for brand consistency)

- "Slimme tools voor makelaars" (huidige `<title>`)
- "Genereer meer leads met een gepersonaliseerde woningwaarde tool in uw eigen huisstijl"
- "Voor NVM en VBO makelaars"
- "Slimme analyse van je huiswaarde met AI" (consumer)
- "Krijg binnen 30 seconden een betrouwbare schatting"
- "Deze waardebepaling is indicatief en geen officiële taxatie." (legal disclaimer — keep on every consumer-facing page)

### Three pillars (trust block)
1. **Altijd in de buurt** — "Met officiële BAG-data analyseren we je exacte buurt"
2. **Betrouwbare databronnen** — "CBS-statistieken, Kadaster-data en actuele verkoopprijzen"
3. **Direct resultaat** — "Binnen 2 minuten een gedetailleerde waardering"

### Three feature pillars (process block)
1. **Betrouwbaar & Veilig** — "Je gegevens worden vertrouwelijk behandeld"
2. **Slim waarderingsmodel** — "Gebaseerd op publieke data zoals verkopen, CBS-cijfers en kadasterinformatie"
3. **Vrijblijvend** — "Geen verplichtingen. Krijg direct inzicht, volledig gratis."

---

## 5. Structured data (Schema.org) — current state

This app emits the following JSON-LD. The marketing repo should mirror or own the canonical versions (better placed on marketing because crawlers reach marketing first):

| Schema | Where it lives now | Recommendation for marketing |
|---|---|---|
| `WebApplication` (RealEstateApplication) | `index.html` | Mirror on marketing, with `applicationCategory: "BusinessApplication"` framing for B2B |
| `WebSite` + `SearchAction` | `index.html` | Move to marketing; one per domain |
| `Service` (Woningwaardering) | `index.html` | Marketing should host this on the relevant product page |
| `FAQPage` | `src/components/FAQ.tsx` (rendered on consumer pages) | Marketing can mirror with B2B-flavoured FAQs (pricing, integratie, white-label, NVM/VBO) |
| `Organization` | **NOT yet emitted** — gap | Marketing should add: name, logo, sameAs (LinkedIn, etc.), contactPoint |
| `Product` / `Offer` per tool | **NOT yet emitted** — gap | Marketing should add per product page (Waardescan, Huistekst, Sfeerimpressie, Woningchat) |
| `BreadcrumbList` | **NOT yet emitted** — gap | Marketing should add on nested pages |

The current `aggregateRating` (`4.8` over `25000` ratings) in `index.html` is **not substantiated** by visible reviews. Google's policy requires aggregate ratings to be backed by real, on-page reviews — keep this only if the marketing site adds a reviews section, otherwise remove to avoid manual action risk.

The full FAQ list (11 questions) is in `src/components/FAQ.tsx` of this repo — copy it for B2C FAQ content on marketing if useful.

---

## 6. Known SEO inconsistencies in this repo (clean up during the SEO project)

These are issues already in this codebase that should be reconciled across both repos:

1. **Stale legacy domain**: `index.html` canonicals to `https://hoeveelismijnhuiswaard.net/`, OG/Twitter URLs and `og:image` use the same domain, AND `public/robots.txt` and `public/sitemap.xml` reference it. Recent commits (b6fa520, 41fc77a, 4fa2c36, f07ceca, 2f3ad59) made the platform live at `platform.woninganalyse.nl` — so this metadata is wrong. **Action**: decide if `hoeveelismijnhuiswaard.net` is being kept as a B2C-funnel domain (with 301s or as its own brand), or sunset it with 301 → woninganalyse.nl. Either way the platform's `index.html`/`robots.txt`/`sitemap.xml` need to match reality.
2. **Sitemap mismatch**: `public/sitemap.xml` lists routes (`/woningwaarde`, `/sfeerimpressie`, `/huistekst`) that **don't exist** in this app's router (`src/App.tsx`) — those are marketing pages that live on the Framer site. The platform sitemap should only list its own indexable routes (`/login`, `/register`, `/demo`, and dynamically the public `/m/:slug` pages from Supabase).
3. **OG image**: `og-image.png` exists in `public/` but is referenced under the stale domain. Make sure both repos serve consistent OG images at consistent absolute URLs.
4. **Twitter handle**: `@woningwaarde` is referenced in OG meta — confirm this account exists and is owned, otherwise remove.
5. **No `Organization` JSON-LD** anywhere — gap to fill on marketing.
6. **Analytics**: GA4 (`G-FBNJCP71XS`) and Leadsy (`r2.leadsy.ai`) tags live in this repo's `index.html`. Marketing repo should use the **same GA4 property** (cross-domain tracking on `woninganalyse.nl` ↔ `platform.woninganalyse.nl`) so funnel attribution survives the hop.

---

## 7. Cross-domain SEO concerns

- **Cross-domain GA4**: configure linker for `woninganalyse.nl` and `platform.woninganalyse.nl` in the same GA4 property so `_ga` cookie carries across. Otherwise marketing will see traffic abandon at the platform link and platform will see all sessions as "direct".
- **Internal linking**: marketing should link to `platform.woninganalyse.nl/register`, `/demo`, `/login` with descriptive anchor text. Platform should link back to `www.woninganalyse.nl` from the dashboard footer / marketing CTAs.
- **Sitemap split**: keep two sitemaps, one per origin. Optionally publish a `sitemap-index.xml` on `www.woninganalyse.nl` that references both.
- **robots.txt** on `platform.woninganalyse.nl` should `Disallow: /dashboard/`, `/admin/`, `/onboarding`, `/verify-email`, `/reset-password`, `/forgot-password`, `/preview/` and explicitly `Allow: /m/`, `/demo`, `/chat/` (if you want chat indexable — probably not, see §2).
- **Duplicate content**: avoid having marketing's "Waardescan" product page repeat the consumer-facing landing copy from `/m/:slug`. Marketing = explainer for makelaars (B2B). Platform = the actual tool (B2C/branded).
- **hreflang**: not needed currently (NL-only). If a Belgium/Flemish version is ever added, add `nl-NL` / `nl-BE`.

---

## 8. Programmatic SEO opportunity

The `/m/:slug` route serves a unique branded page per makelaar (data from Supabase). Each one is a long-tail landing page for `"{makelaar naam} woningwaarde"` / `"{makelaar naam} waardecheck"`. To unlock this:

- Generate `/m/:slug` URLs into the platform sitemap dynamically (query Supabase for active agents with `hasWaardecheckAccess` — see `src/pages/MakelaarPage.tsx:72`).
- Per-page `<Helmet>` already sets `<title>` and `<meta description>` (`MakelaarPage.tsx:111-117`). Consider adding `LocalBusiness` JSON-LD per agent (with phone, email, website, area-served) — the data is already in the `agent` object.
- The `noscript` SEO shell in `index.html` is generic; per-route prerender (or SSR via a Vite plugin / Cloudflare Worker) would massively improve indexability of `/m/:slug` and `/demo`. Currently a JS-disabled crawler sees the same generic shell on every URL.

Same opportunity exists for `/chat/:agentSlug/:objectSlug` if you want object/listing pages to rank on `"{adres} te koop bij {makelaar}"` searches — but be careful, listing pages typically also exist on Funda and you'd be competing with them.

---

## 9. Quick reference — what to copy into the marketing repo

If you want to bootstrap the marketing repo's SEO with proven copy from this repo, these are the files to read:

- `index.html` — `<title>`, `<meta description>`, OG tags, JSON-LD blocks
- `src/components/FAQ.tsx` — full FAQ list with consumer-language answers (11 Q&A, already wrapped in FAQPage schema)
- `src/components/TrustIndicators.tsx` — three-pillar trust block copy
- `src/components/ProcessFeatures.tsx` — three feature cards copy
- `src/pages/Register.tsx` — the 5-product feature list (lines ~24-30) is the cleanest one-liner description of each product
- `src/components/LandingPage.tsx` — the consumer flow shape, useful for shaping CTAs on marketing

---

## 10. Open questions for the SEO project

1. Is `hoeveelismijnhuiswaard.net` being kept (as a separate B2C funnel) or sunset? This drives canonical/redirect strategy.
2. Should `/m/:slug` pages canonical to themselves on `platform.woninganalyse.nl`, or to a marketing-side directory of makelaars on `www.woninganalyse.nl`?
3. Is the `aggregateRating` in `index.html` substantiated? If not, remove before Google issues a manual action.
4. Is per-route SSR/prerender on the agenda? Without it, all marketing-driven traffic landing on `/m/:slug` will see the noscript shell in source view, hurting rich-result eligibility.
5. Is a B2B blog planned on the marketing site? If yes, that's the lever for ranking on the makelaar-side keywords in §3.
