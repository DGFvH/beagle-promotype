import type { NextConfig } from 'next'

const PLATFORM_ORIGIN = 'https://platform.woninganalyse.nl'

const nextConfig: NextConfig = {
  images: {
    // Serve AVIF where supported (~30% smaller than WebP), fall back to
    // WebP, then to the original PNG. The Next.js Image component
    // negotiates the best format per request based on the Accept header.
    formats: ['image/avif', 'image/webp'],
  },
  async rewrites() {
    return {
      // Run before filesystem / App Router matching so /chat/* is always proxied to the
      // platform SPA (plain-array rewrites can lose to the 404 path on some versions).
      beforeFiles: [
        {
          source: '/m/:path*',
          destination: `${PLATFORM_ORIGIN}/m/:path*`,
        },
        {
          source: '/preview/:path*',
          destination: `${PLATFORM_ORIGIN}/preview/:path*`,
        },
        {
          source: '/assets/:path*',
          destination: `${PLATFORM_ORIGIN}/assets/:path*`,
        },
        {
          source: '/~api/:path*',
          destination: `${PLATFORM_ORIGIN}/~api/:path*`,
        },
        {
          source: '/~flock.js',
          destination: `${PLATFORM_ORIGIN}/~flock.js`,
        },
        {
          source: '/woningchat-favicon.svg',
          destination: `${PLATFORM_ORIGIN}/woningchat-favicon.svg`,
        },
        {
          // The platform HTML references /favicon.png for its icon. Proxy it to
          // the woningchat favicon so chat pages show the correct icon.
          source: '/favicon.png',
          destination: `${PLATFORM_ORIGIN}/woningchat-favicon.svg`,
        },
      ],
    }
  },
  async redirects() {
    return [
      { source: '/avg', destination: '/privacybeleid', permanent: true },
      { source: '/integraties', destination: '/contact', permanent: true },
      { source: '/blog/woningwaarde-berekenen-2025', destination: '/blog/woningwaarde-berekenen-2026', permanent: true },
      { source: '/blog/nvm-vs-vbo-makelaarstools', destination: '/blog/ai-tools-voor-makelaars', permanent: true },
      { source: '/blog/white-label-woningwaardering', destination: '/blog/leads-genereren-woningwaarde-tool', permanent: true },
    ]
  },
}

export default nextConfig
