# Claude Code Prompt — SEO Optimization for `woninganalyse.nl`

> Paste this entire file as the first message to Claude Code in the **marketing repo** (Next.js, hosts `www.woninganalyse.nl`). The prompt is phased; **wait for my confirmation between phases.**

---

## 1. Mission

Optimize the SEO surface area of the `woninganalyse.nl` marketing site (this repo) to:

1. Rank for the **B2B keywords** in `SEO-CONTEXT.md` §3 (NVM/VBO makelaar tools, leadgeneratie, white-label woningwaarde, AI tools voor makelaars).
2. Reconcile cross-domain concerns with the platform repo (`platform.woninganalyse.nl`) — analytics, sitemaps, internal links, canonical strategy.
3. Fill structured-data gaps and improve crawl quality without touching the visual design of the homepage.
4. Expand topical authority via new content pages (blog + supporting landing pages).

The platform repo is **out of scope** — do not attempt to modify it. Anything that needs platform-side work goes into `HANDOFF.md` (see Phase 7).

---

## 2. Hard constraints — DO NOT VIOLATE

These are non-negotiable. Stop and ask if any task seems to require breaking one.

- **Homepage look stays identical.** No visual changes to `app/page.tsx` and the components it composes (`components/sections/Hero.tsx`, `ToolsShowcase.tsx`, `SocialProof.tsx`, `FAQ.tsx`, `CTABanner.tsx`). You may:
  - Add `<script type="application/ld+json">` blocks (these don't render visually).
  - Add `<Helmet>` / `metadata` / `<head>` entries.
  - Edit copy *only* if I explicitly approve it in a phase review.
  You may **not** restructure JSX, change Tailwind classes, swap components, change copy in Hero/ToolsShowcase/SocialProof/CTABanner, or alter spacing/typography on the homepage.
- **No `aggregateRating` schema** anywhere unless real, on-page reviews back it up. The platform repo already has an unsubstantiated `4.8 / 25000` rating that risks a Google manual action — do not replicate it here.
- **Don't introduce duplicate content with the platform's `/m/:slug` pages.** Marketing = B2B explainer. Platform = B2C branded tool.
- **Don't change canonical hosts** without flagging it. The current canonical is `https://woninganalyse.nl` (no `www.`); preserve that unless `SEO-CONTEXT.md` §2 motivates a change AND I confirm. (`SEO-CONTEXT.md` mentions `www.` as canonical — verify which is actually being served by Vercel/DNS before changing anything.)
- **No new dependencies without justification.** If you want to add `@vercel/og`, `next-seo`, `schema-dts`, etc., propose first.
- **Dutch only.** Never English on public pages. `nl_NL`. `u`-vorm in B2B context, `je`-vorm for any consumer-facing copy.
- **Don't break existing GA4** (`G-FBNJCP71XS`) or remove the Leadsy tag — the platform shares the same property; cross-domain attribution depends on it.

---

## 3. Context to read first (in this order)

1. `SEO-CONTEXT.md` — the hand-off document from the platform repo. Treat its §1, §3, §4, §6, §7, §10 as ground truth. §6 lists known inconsistencies in the *platform* repo — most are not your problem, but they tell you what NOT to do here.
2. `app/layout.tsx` — current root metadata, `metadataBase`, font setup.
3. `app/page.tsx` — homepage metadata + JSON-LD.
4. `app/sitemap.ts` and `app/robots.ts` — current crawl config.
5. `app/blog/page.tsx`, `app/blog/[slug]/page.tsx`, `lib/blog-data.ts` — current blog architecture.
6. `app/tools/{waardescan,huistekst,sfeerimpressie,object-assistent}/page.tsx` — current tool-page metadata patterns.
7. `components/layout/Navbar.tsx` and `components/layout/Footer.tsx` — internal-link surface.
8. `components/layout/CookieBanner.tsx` — needed for GA4 consent gating.

After reading, produce a one-page **Audit Report** (Phase 1 below) before touching any file.

---

## 4. Phased plan

Work phase by phase. **At the end of each phase, post a diff summary and wait for my confirmation before starting the next phase.** Do not chain phases.

---

### Phase 1 — Audit & inventory (read-only)

Produce a single Markdown report `seo-audit.md` at the repo root with these sections:

1. **Current metadata coverage** — table of every public route, its `<title>`, `description`, canonical, OG image, and which JSON-LD types it emits. Flag any mismatch against `SEO-CONTEXT.md` (e.g., naming: platform calls it "Woningchat", marketing calls it "Object Assistent" — the marketing naming is correct here, but verify the homepage copy and FAQ are consistent).
2. **Structured data gaps** — what's missing per page vs. the recommendation in `SEO-CONTEXT.md` §5 (Organization ✓ on home, SoftwareApplication ✓ per tool, BlogPosting ✓ per post; **missing: FAQPage on homepage FAQ component, BreadcrumbList everywhere except home, Service per tool, Product/Offer per tool**).
3. **Sitemap accuracy** — list every URL in `app/sitemap.ts` and confirm each route file actually exists. Flag anything in the sitemap that 404s.
4. **Internal-link inventory** — list every `<Link>` from blog posts to tool pages and from tool pages to blog posts. The goal in Phase 5 is to densify this; Phase 1 just measures.
5. **Cross-domain link inventory** — every link from this repo to `platform.woninganalyse.nl/*`. We need at least: `/register`, `/login`, `/demo`. Flag CTAs that go to `platform.woninganalyse.nl` without descriptive anchor text (e.g., "Klik hier" → bad; "Start gratis met de Waardescan" → good).
6. **GA4 + cookie-consent state** — does GA4 fire? Is it gated behind `CookieBanner` consent? Is `linker` configured for `woninganalyse.nl` ↔ `platform.woninganalyse.nl`?
7. **OG image audit** — does each page have a unique `og:image`, or do they all fall back to `/og-image.png`? List which pages share an image.
8. **Lighthouse / Core Web Vitals notes** — if you can run a local Lighthouse pass, include scores. Otherwise list visible perf risks (large LCP image on Hero, font weights loaded, etc.).
9. **Open questions** — anything ambiguous in `SEO-CONTEXT.md` you need me to answer before Phase 2 (especially `SEO-CONTEXT.md` §10).

**Stop after Phase 1.** Do not edit code yet.

---

### Phase 2 — Foundational technical SEO

Goals: fix the plumbing so every later page change is automatically discoverable, indexable, and tracked.

Tasks:

- **2a. `app/robots.ts`** — confirm `Disallow: /api/` is sufficient, add `Disallow: /preview/` and any internal/admin routes if they exist in this repo. Add the `host` directive if Vercel deploy URLs are publicly reachable; otherwise leave as-is.
- **2b. `app/sitemap.ts`** — keep the current static + blog routes. Verify priorities: `/` = 1.0, `/voor-makelaars` = 0.9, `/tools/*` = 0.7–0.9, `/blog` = 0.8, blog posts = 0.6–0.7, legal = 0.2. Set `lastModified` for blog posts from `blog-data.ts` `date` field, not `now`.
- **2c. Cross-domain GA4** — wrap GA4 in a client component that reads consent from `CookieBanner` state (or `localStorage` key it sets). Add the GA4 `linker` config so the `_ga` cookie spans `woninganalyse.nl` and `platform.woninganalyse.nl`:
  ```js
  gtag('config', 'G-FBNJCP71XS', {
    linker: { domains: ['woninganalyse.nl', 'platform.woninganalyse.nl'] }
  })
  ```
  Use Next.js `<Script strategy="afterInteractive">` — do not block render. Verify the Leadsy tag (`r2.leadsy.ai`) is also present and consent-gated.
- **2d. `metadataBase`** — already set in `app/layout.tsx` to `https://woninganalyse.nl`. Confirm. Make sure no per-page `openGraph.url` hardcodes `www.` if the canonical is bare-domain (or vice versa). Be consistent.
- **2e. Per-page unique OG images** — propose ONE of:
  - **Option A (cheap):** create 4 static OG images (`/og-waardescan.png`, `/og-huistekst.png`, `/og-sfeerimpressie.png`, `/og-object-assistent.png`) and reference them per tool page.
  - **Option B (powerful):** add `@vercel/og` and generate OG images dynamically per route from a single template (logo + page title + brand colors).

  Wait for my pick before implementing.
- **2f. Skip-to-content link & semantic landmarks** — `app/layout.tsx` already has `#main-content`. Verify each page uses one `<h1>`, has a logical heading hierarchy, and that decorative SVGs are `aria-hidden`. Don't change visual output; this is an a11y/SEO audit pass.
- **2g. Twitter handle** — `SEO-CONTEXT.md` §6 flags `@woningwaarde` as possibly unowned. Remove `twitter:site` from `app/layout.tsx` metadata until I confirm ownership.

**Diff summary required.** Stop.

---

### Phase 3 — Structured data completion

Add JSON-LD across the site to fill the gaps from Phase 1, item 2.

Tasks:

- **3a. `FAQPage` schema on homepage** — the homepage `<FAQ />` section renders Q&A. Wrap the *same* questions/answers (no copy change) in `FAQPage` JSON-LD, emitted from `app/page.tsx` or a co-located `<script>` in the FAQ component. Do not duplicate Q&A on tool pages — only one `FAQPage` block per URL, and it must reflect on-page content exactly.
- **3b. `BreadcrumbList` on every non-home page** — generate from the route. E.g., `/tools/waardescan` → Home › Tools › Waardescan. Keep the visible breadcrumb optional (we're not adding visual breadcrumbs to the homepage), but emit the JSON-LD on tool pages, blog pages, blog posts, `/voor-makelaars`, `/over-ons`, `/contact`. Visible breadcrumb on tool pages is fine if it doesn't disturb existing layout — propose a design first.
- **3c. `Service` per tool** — augment each tool page's existing `SoftwareApplication` JSON-LD with a sibling `Service` block referencing `provider: { @id: 'https://woninganalyse.nl/#organization' }` (means: also give the homepage Organization an `@id`). `serviceType` = "Leadgeneratie voor makelaars" / "Verkooptekstgeneratie" / etc.
- **3d. `Product` + `Offer` per tool** — already partially present via `SoftwareApplication.offers`. Keep that, do not duplicate as a separate `Product`. Adding both would confuse Google. Note in `seo-audit.md` that the spec in `SEO-CONTEXT.md` recommends Product/Offer, but `SoftwareApplication.offers` is the more correct schema for SaaS — defend the choice in code comments.
- **3e. `Organization` `@id` + `sameAs`** — give the Organization JSON-LD on `app/page.tsx` an `@id: 'https://woninganalyse.nl/#organization'` so other schemas can reference it. Confirm `sameAs` only includes verified accounts — currently `https://www.linkedin.com/company/tinybasenl`. Do not add the unverified Twitter handle.
- **3f. `BlogPosting` enrichment** — current `BlogPosting` is fine but add `image` (use the post's lead image if present, else the homepage OG), `wordCount`, `articleSection` (= `category`), and `keywords` (derive from `relatedTool` and `category`).

Validate everything with [Schema.org Validator](https://validator.schema.org/) and Google Rich Results Test before declaring done. Paste validation results in the phase diff summary.

---

### Phase 4 — New SEO surface area (content pages)

This is where the ranking lift comes from. We're adding **net-new pages**, not modifying existing ones.

Tasks (propose specifics for each before writing — we'll pick which to do):

- **4a. `/demo` explainer page** — `SEO-CONTEXT.md` §2 explicitly recommends this. The actual interactive demo lives at `platform.woninganalyse.nl/demo`. This page is a 400–600 word B2B explainer of what the demo shows, with a single primary CTA → `https://platform.woninganalyse.nl/demo` (descriptive anchor: "Probeer de Waardescan demo"). Add to sitemap, link from Navbar (under Tools or as a top-level item — propose a Navbar change separately, do not commit it without my approval). Emit `BreadcrumbList` and a `WebPage` JSON-LD.
- **4b. `/integraties` page** — list integrations (Funda, Realworks, Kolibri, generic CMS via script tag, WordPress). Even stub-level content ranks for "{Tool} Realworks koppeling" type queries. Keep visual style consistent with existing `/voor-makelaars` page.
- **4c. New blog posts** — propose 4 titles targeting B2B keywords from `SEO-CONTEXT.md` §3, plus 2 posts targeting B2C-leaning keywords that still funnel to makelaars. Suggested:
  1. "Hoe genereer je leads met een woningwaarde-tool op je website" (B2B, primary)
  2. "NVM vs VBO: welke makelaarstools horen erbij?" (B2B, branded keyword)
  3. "White-label woningwaardering: wat het is en waarom het werkt" (B2B)
  4. "AI-chatbot voor je objectpagina: 5 use cases die leads opleveren" (B2B)
  5. "WOZ-waarde vs marktwaarde: wat is het verschil?" (B2C, funnels to makelaar pages)
  6. "Wat is mijn huis waard in 2026? De data achter een betrouwbare schatting" (B2C)

  Each post: 1000–1500 words, 1 lead image, 3+ internal links to tool pages and to other blog posts, 1 callout, 1 conclusion CTA. Add to `lib/blog-data.ts`. **Wait for my approval on titles before drafting.**
- **4d. `/kennisbank` index (optional)** — if we end up with 8+ blog posts, propose a topical hub at `/kennisbank` grouping by category (Leadgeneratie / Copywriting / Marktdata / Tools). Don't build it yet.
- **4e. Programmatic landing pages — defer.** `SEO-CONTEXT.md` §8 flags `/m/:slug` on the platform side as the place for makelaar-specific pages. We do NOT want to mirror that here. Instead, propose a `/makelaarstools-{regio}` set (Amsterdam, Rotterdam, Utrecht, Den Haag, Eindhoven) only if I confirm — these are B2B regional pages, not B2C makelaar pages. Risk: thin content. Don't build yet.

For each task, deliver: route file + metadata + JSON-LD + sitemap entry + at least 2 inbound internal links from existing pages.

---

### Phase 5 — Internal linking, copy hardening, and FAQ depth

No new pages. Tighten what's there.

Tasks:

- **5a. Internal linking pass** — every blog post links to its `relatedTool` page (already in data) AND to one other relevant blog post. Every tool page links to 2–3 relevant blog posts in a "Lees verder" / "Verwante artikelen" block at the bottom. Visual style: copy the existing card pattern; do not invent a new component.
- **5b. Tool-page FAQs** — each `/tools/*` page already has FAQs. Verify each one has a `FAQPage` JSON-LD block (separate from the homepage one — these are about the specific tool). Add 2 missing FAQs per tool focused on B2B objections from `SEO-CONTEXT.md` §3 (pricing, NVM/VBO compatibility, white-label setup time, integration steps).
- **5c. Anchor-text audit** — every link to `platform.woninganalyse.nl/register` should have descriptive anchor text, not "klik hier" or "registreer". Same for `/login` and `/demo`. Replace generic anchors with action-keyword anchors.
- **5d. Footer links** — verify the footer surfaces: Tools (4), Voor Makelaars, Blog, Over ons, Contact, Privacybeleid, Gebruiksvoorwaarden. Add an `<address>` block with `Organization` contact info if missing. No visual restructure.
- **5e. Trust anchors block** — `SEO-CONTEXT.md` §4 lists "Kadaster · CBS · WOZ · BAG · AVG-conform · NVM/VBO" as trust phrases to use everywhere. Verify these appear on at least: homepage (existing), `/voor-makelaars`, `/tools/waardescan`. Don't restructure existing components — if a tool page is missing the data-source mention, add it as a single-sentence inline addition only.

---

### Phase 6 — Performance & technical hardening

SEO ranking depends on Core Web Vitals. This phase is small but high-leverage.

Tasks:

- **6a. Image optimization** — every `<Image>` has explicit `width`/`height`, `alt`, and appropriate `priority` (only `hero-bg.png` should be `priority`). Audit `public/` for raw `.png` that could be `.webp` or `.avif`; convert if savings >40%.
- **6b. Font loading** — `app/layout.tsx` uses `DM_Sans` with weights `300,400,500,600,700,800`. Drop `300` if no element uses it. `display: 'swap'` is correct.
- **6c. Third-party scripts** — Leadsy and GA4 should be `strategy="afterInteractive"` via `next/script`. Verify no `<script async src="...">` lives directly in `<head>`.
- **6d. `next.config.ts`** — confirm `images.formats` includes `image/avif, image/webp`, `compress: true`, and a sensible `images.remotePatterns` if any external images are used.
- **6e. Lighthouse run** — execute against `/`, `/voor-makelaars`, `/tools/waardescan`, `/blog`, and one blog post. Target: Performance ≥ 90, SEO = 100, Accessibility ≥ 95, Best Practices ≥ 95. Paste scores in the phase diff summary.

---

### Phase 7 — Cross-domain handoff document

Produce `HANDOFF.md` at the repo root. This is the doc to send to whoever maintains the platform repo. Sections:

1. **Platform-side fixes that block our SEO** — restate the §6 issues from `SEO-CONTEXT.md` with current status (canonical to legacy domain, sitemap mismatch, OG image with stale URL, possibly unverified Twitter handle, missing Organization JSON-LD on platform). For each: severity, recommended fix, link to a code location in the platform repo if known.
2. **Cross-domain GA4 linker config required on platform** — paste the linker snippet that needs to go on `platform.woninganalyse.nl`'s `<head>`.
3. **Sitemap-index proposal** — should `https://woninganalyse.nl/sitemap-index.xml` reference both the marketing sitemap and the platform sitemap? Pros/cons. Recommend yes if the platform's sitemap can be fetched cross-origin.
4. **`/demo` cross-link** — confirm `platform.woninganalyse.nl/demo` is reachable and has its own canonical to itself. Marketing `/demo` should `rel="canonical"` to itself, not to the platform.
5. **`/m/:slug` pages on platform** — these should self-canonical. Confirm they do, and that they're in the platform's sitemap. Marketing must NOT reference these in its own sitemap.
6. **Open questions from `SEO-CONTEXT.md` §10** — answer each one with our current direction and what needs the platform's confirmation.
7. **Shared assets** — the OG image should be served from one canonical URL. Decide which domain hosts it (recommend marketing) and have the platform reference that absolute URL.

---

## 5. Acceptance criteria (overall)

The optimization is "done" when:

- [ ] Every public route has unique `<title>`, `description`, canonical, OG title/description/image.
- [ ] Every public route emits at least one valid JSON-LD block. Tool pages emit `SoftwareApplication` + `Service` + `BreadcrumbList` + `FAQPage`. Blog posts emit `BlogPosting` + `BreadcrumbList`. Homepage emits `Organization` + `SoftwareApplication` + `FAQPage` + `WebSite` (with `SearchAction` if site search exists; skip if not).
- [ ] No JSON-LD validator errors. Paste validator URL + screenshot in final summary.
- [ ] Sitemap lists every indexable URL and nothing else. No 404s, no `noindex` pages, no platform routes.
- [ ] `robots.txt` blocks `/api/` and any preview/admin routes; allows everything else.
- [ ] GA4 fires once, after consent, with `linker` config covering both domains.
- [ ] Lighthouse SEO = 100 on all five sampled routes.
- [ ] At least 4 new blog posts shipped (Phase 4c).
- [ ] At least 1 net-new explainer page (`/demo` minimum).
- [ ] `seo-audit.md` and `HANDOFF.md` present at repo root.
- [ ] Homepage visual look is byte-for-byte identical (excluding the head/JSON-LD additions). Verify with a before/after screenshot.

---

## 6. Reporting format per phase

After each phase, post in this exact structure:

```
## Phase N summary

### What changed
- file path: <one-line description>
- file path: <one-line description>

### What I did NOT change (and why)
- file path: <reason>

### Verification
- Lighthouse / validator / build output / type-check result

### Open questions for you
- ...

### Proposed next phase
- summary of the next phase, ready to start on your "go"
```

Then **stop and wait**. Do not proceed to the next phase without my explicit "go".

---

## 7. Style notes for new content

When writing copy for new pages or blog posts:

- Reuse the established taglines from `SEO-CONTEXT.md` §4 verbatim where they fit.
- B2B pages: zakelijk, helder, `u`-vorm. Concrete benefit phrasing ("genereer meer leads", "in uw eigen huisstijl", "voor NVM en VBO makelaars"). No marketing fluff.
- B2C pages (blog posts targeting huiseigenaren): warm, vriendelijk, `je`-vorm. End with a soft handover to a makelaar tool, not a hard sell.
- Always include the legal disclaimer on consumer-facing content: "Deze waardebepaling is indicatief en geen officiële taxatie."
- Trust anchors (`Kadaster · CBS · WOZ · BAG · AVG-conform · NVM/VBO`) belong in trust blocks and headers, not in body prose.
- Use the existing component primitives: `Badge`, `Button`, `CTABanner`, `FAQAccordion`. Don't invent new components unless a phase task explicitly requires one.

---

## 8. Files you should never touch in this project

- `components/sections/Hero.tsx` — visual or copy changes forbidden by user constraint.
- Any file in `/mnt/skills/` — read-only.
- Any platform-repo file — different repo.
- Existing blog post content in `lib/blog-data.ts` — additions only, never edits to existing posts.

---

## 9. Kickoff

Start with **Phase 1 only**. Produce `seo-audit.md`. Do not edit any other file. When the audit is in, ping me and I'll release Phase 2.
