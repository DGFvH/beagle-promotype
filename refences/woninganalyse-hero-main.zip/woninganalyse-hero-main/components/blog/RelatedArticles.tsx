import Link from 'next/link'
import { Clock, ArrowRight } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import type { BlogPost } from '@/lib/blog-data'

interface Props {
  posts: BlogPost[]
  heading?: string
}

// Reuses the card pattern from app/blog/page.tsx so visitors recognize
// the "this is a blog post" affordance. Renders nothing if posts is empty.
export default function RelatedArticles({ posts, heading = 'Verwante artikelen' }: Props) {
  if (posts.length === 0) return null

  return (
    <section
      className="py-16 px-4 sm:px-6 bg-[var(--bg-muted)]"
      aria-labelledby="related-articles-heading"
    >
      <div className="max-w-5xl mx-auto">
        <h2
          id="related-articles-heading"
          className="text-display-2 text-[var(--fg)] mb-10 text-center"
        >
          {heading}
        </h2>
        <div
          className={[
            'grid grid-cols-1 gap-5',
            posts.length === 2 ? 'sm:grid-cols-2' : 'sm:grid-cols-2 lg:grid-cols-3',
          ].join(' ')}
        >
          {posts.map((post) => (
            <article
              key={post.slug}
              className="group flex flex-col border border-[var(--border)] rounded-xl bg-[var(--bg-surface)] hover:border-[var(--border-hover)] hover:-translate-y-1 transition-all duration-200 overflow-hidden"
            >
              <div className="p-6 flex flex-col flex-1">
                <div className="flex items-center justify-between mb-4">
                  <Badge variant="muted">{post.category}</Badge>
                  <div className="flex items-center gap-1 text-[11px] text-[var(--fg-subtle)]">
                    <Clock size={10} aria-hidden="true" />
                    {post.readTime} min
                  </div>
                </div>

                <h3 className="text-[16px] font-bold text-[var(--fg)] leading-snug mb-3 group-hover:text-[var(--brand)] transition-colors">
                  <Link href={`/blog/${post.slug}`} className="focus-visible:outline-[var(--brand)]">
                    {post.title}
                  </Link>
                </h3>

                <p className="text-[13px] text-[var(--fg-muted)] leading-relaxed flex-1 mb-5">
                  {post.description}
                </p>

                <div className="flex items-center justify-end pt-4 border-t border-[var(--border)]">
                  <Link
                    href={`/blog/${post.slug}`}
                    className="inline-flex items-center gap-1 text-[12px] font-semibold text-[var(--brand)] hover:text-[var(--brand-dark)] transition-colors group/link"
                    aria-label={`Lees meer: ${post.title}`}
                  >
                    Lees meer
                    <ArrowRight
                      size={11}
                      className="group-hover/link:translate-x-0.5 transition-transform"
                      aria-hidden="true"
                    />
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
