'use client'

import { useEffect, useState } from 'react'
import Script from 'next/script'
import { hasConsent, CONSENT_EVENT } from '@/lib/consent'

const GA_ID = 'G-FBNJCP71XS'

// Cross-domain linker keeps the _ga cookie consistent across the brand domains,
// so funnel attribution survives the hop from marketing to the platform app.
// HANDOFF.md §8 documents the matching change required on the platform side.
const LINKER_DOMAINS = [
  'woninganalyse.nl',
  'www.woninganalyse.nl',
  'platform.woninganalyse.nl',
]

// Note: B2B visitor identification (Leadsy / RB2B / Leadfeeder etc.) is
// intentionally NOT installed. Deferred per seo-audit.md §9 "Deferred".

export default function GoogleAnalytics() {
  const [consented, setConsented] = useState(false)

  useEffect(() => {
    if (hasConsent()) setConsented(true)

    function onConsent() {
      setConsented(true)
    }
    window.addEventListener(CONSENT_EVENT, onConsent)
    return () => window.removeEventListener(CONSENT_EVENT, onConsent)
  }, [])

  if (!consented) return null

  return (
    <>
      <Script
        src={`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`}
        strategy="afterInteractive"
      />
      <Script id="ga-init" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${GA_ID}', {
            linker: { domains: ${JSON.stringify(LINKER_DOMAINS)} }
          });
        `}
      </Script>
    </>
  )
}
