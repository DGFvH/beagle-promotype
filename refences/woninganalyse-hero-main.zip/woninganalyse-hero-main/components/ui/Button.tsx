import { forwardRef } from 'react'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

type Variant = 'primary' | 'secondary' | 'ghost' | 'outline'
type Size = 'sm' | 'md' | 'lg'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  href?: string
  external?: boolean
  arrow?: boolean
  loading?: boolean
}

const variantClasses: Record<Variant, string> = {
  primary:
    'bg-[var(--brand)] text-white hover:bg-[var(--brand-dark)] border border-[var(--brand)] hover:border-[var(--brand-dark)]',
  secondary:
    'bg-[var(--bg-surface)] text-[var(--fg)] border border-[var(--border)] hover:border-[var(--border-hover)] hover:bg-[var(--bg-muted)]',
  ghost:
    'bg-transparent text-[var(--brand)] border border-transparent hover:bg-[var(--brand-light)]',
  outline:
    'bg-transparent text-[var(--brand)] border border-[var(--brand)] hover:bg-[var(--brand-light)]',
}

const sizeClasses: Record<Size, string> = {
  sm: 'px-4 py-2 text-sm gap-1.5',
  md: 'px-5 py-2.5 text-[15px] gap-2',
  lg: 'px-6 py-3 text-base gap-2',
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = 'primary',
      size = 'md',
      href,
      external,
      arrow,
      loading,
      className = '',
      children,
      disabled,
      ...props
    },
    ref
  ) => {
    const classes = [
      'inline-flex items-center justify-center font-semibold rounded-[6px] transition-all duration-150 focus-visible:ring-2 focus-visible:ring-[var(--brand)] focus-visible:ring-offset-2 focus-visible:outline-none select-none',
      variantClasses[variant],
      sizeClasses[size],
      disabled || loading ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'cursor-pointer',
      className,
    ]
      .filter(Boolean)
      .join(' ')

    const content = (
      <>
        {loading ? (
          <span
            className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin"
            aria-hidden="true"
          />
        ) : null}
        <span>{children}</span>
        {arrow && !loading ? (
          <ArrowRight size={14} aria-hidden="true" />
        ) : null}
      </>
    )

    if (href) {
      if (external) {
        return (
          <a
            href={href}
            target="_blank"
            rel="noopener noreferrer"
            className={classes}
          >
            {content}
          </a>
        )
      }
      return (
        <Link href={href} className={classes}>
          {content}
        </Link>
      )
    }

    return (
      <button ref={ref} className={classes} disabled={disabled || loading} {...props}>
        {content}
      </button>
    )
  }
)

Button.displayName = 'Button'
