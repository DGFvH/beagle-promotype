'use client'

import { useState } from 'react'
import { Copy, Check } from 'lucide-react'

const LANGUAGES = ['NL', 'EN', 'DE']

const TEXTS: Record<string, string> = {
  NL: 'Dit sfeervolle hoekappartement in het hart van Amsterdam biedt een unieke combinatie van authentieke details en modern comfort. Met 85m² woonoppervlak verdeeld over drie ruime kamers geniet u van hoge plafonds en originele ornamenten. De open leefkeuken van 32m² is voorzien van hoogwaardige materialen...',
  EN: 'This charming corner apartment in the heart of Amsterdam offers a unique blend of authentic details and modern comfort. With 85m² of living space across three spacious rooms, you\'ll enjoy high ceilings and original ornamental features. The open-plan kitchen of 32m² features premium materials...',
  DE: 'Diese stimmungsvolle Eckwohnung im Herzen Amsterdams bietet eine einzigartige Kombination aus authentischen Details und modernem Komfort. Mit 85m² Wohnfläche auf drei geräumigen Zimmern genießen Sie hohe Decken und originale Ornamente...',
}

export default function HuistekstMockup() {
  const [lang, setLang] = useState('NL')
  const [copied, setCopied] = useState(false)

  function handleCopy() {
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="mockup-browser w-full max-w-full sm:max-w-[420px] mx-auto">
      {/* Chrome */}
      <div className="mockup-chrome">
        <div className="mockup-dot bg-red-400" />
        <div className="mockup-dot bg-yellow-400" />
        <div className="mockup-dot bg-green-400" />
        <div className="mockup-url">uwkantoor.nl</div>
        {/* Language tabs */}
        <div className="flex gap-1 ml-2">
          {LANGUAGES.map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={[
                'px-2 py-0.5 rounded text-[10px] font-semibold transition-colors',
                lang === l
                  ? 'bg-[var(--brand)] text-white'
                  : 'bg-[var(--bg-surface)] text-[var(--fg-muted)] hover:bg-[var(--border)]',
              ].join(' ')}
            >
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Label */}
        <div className="flex items-center gap-1.5 mb-3">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
          </svg>
          <span className="text-[11px] font-semibold text-[var(--brand)] uppercase tracking-wider">
            Gegenereerde tekst
          </span>
        </div>

        {/* Text area */}
        <div className="relative bg-[var(--bg-muted)] rounded-lg p-3.5 min-h-[120px] mb-3">
          <p className="text-[12px] text-[var(--fg-muted)] leading-relaxed">
            {TEXTS[lang]}
          </p>
          {/* Fade out at bottom */}
          <div className="absolute bottom-0 left-0 right-0 h-8 rounded-b-lg bg-gradient-to-t from-[var(--bg-muted)] to-transparent" />
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-[11px] text-[var(--fg-subtle)]">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <circle cx="12" cy="12" r="10"/>
              <polyline points="12 6 12 12 16 14"/>
            </svg>
            Gegenereerd in 2.8s
          </div>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-[var(--bg-surface)] border border-[var(--border)] text-[11px] font-semibold text-[var(--fg-muted)] rounded-[4px] hover:border-[var(--border-hover)] transition-colors"
          >
            {copied ? (
              <Check size={11} className="text-[var(--success)]" aria-hidden="true" />
            ) : (
              <Copy size={11} aria-hidden="true" />
            )}
            {copied ? 'Gekopieerd' : 'Kopiëren'}
          </button>
        </div>
      </div>
    </div>
  )
}
