'use client'

import { useState, useRef } from 'react'

const STYLES = ['Modern Scandinavisch', 'Klassiek', 'Industrieel', 'Mediterraan']

export default function SfeerimpressieMockup() {
  const [sliderPos, setSliderPos] = useState(50)
  const [activeStyle, setActiveStyle] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  function getPos(clientX: number) {
    if (!containerRef.current) return
    const rect = containerRef.current.getBoundingClientRect()
    const x = ((clientX - rect.left) / rect.width) * 100
    setSliderPos(Math.max(10, Math.min(90, x)))
  }

  function handleMouseDown(e: React.MouseEvent<HTMLDivElement>) {
    setIsDragging(true)
    getPos(e.clientX)
  }

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    if (!isDragging) return
    getPos(e.clientX)
  }

  function handleMouseUp() {
    setIsDragging(false)
  }

  function handleTouchMove(e: React.TouchEvent<HTMLDivElement>) {
    getPos(e.touches[0].clientX)
  }

  return (
    <div className="mockup-browser w-full max-w-full sm:max-w-[420px] mx-auto">
      {/* Chrome */}
      <div className="mockup-chrome">
        <div className="mockup-dot bg-red-400" />
        <div className="mockup-dot bg-yellow-400" />
        <div className="mockup-dot bg-green-400" />
        <div className="mockup-url">uwkantoor.nl</div>
        <span className="ml-2 text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-orange-100 text-orange-600">
          BINNENKORT
        </span>
      </div>

      {/* Slider area */}
      <div
        ref={containerRef}
        className="relative h-44 cursor-ew-resize overflow-hidden select-none"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchMove={handleTouchMove}
        role="img"
        aria-label="Voor-na vergelijking van virtuele styling"
      >
        {/* VOOR side — empty room simulation */}
        <div className="absolute inset-0 bg-[#D5D0C8]">
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 opacity-40">
            {/* Empty room lines */}
            {[...Array(6)].map((_, i) => (
              <div key={i} className="w-4/5 h-2 bg-[#B0AAA0] rounded" />
            ))}
          </div>
          <div
            className="absolute bottom-3 left-0 right-0 text-center text-[10px] font-bold tracking-widest text-[#8A8480] uppercase"
          >
            Voor
          </div>
        </div>

        {/* NA side — styled room simulation */}
        <div
          className="absolute inset-0"
          style={{ clipPath: `inset(0 ${100 - sliderPos}% 0 0)` }}
        >
          <div className="absolute inset-0 bg-[#F5F0E8]">
            {/* Sofa */}
            <div className="absolute bottom-10 left-6 w-24 h-10 bg-[#8B7355] rounded-t-lg rounded-b-sm" />
            <div className="absolute bottom-14 left-6 w-24 h-4 bg-[#7A6447] rounded-sm" />
            {/* Plant */}
            <div className="absolute bottom-10 right-10 w-6 h-14">
              <div className="w-4 h-4 bg-[#5C7A3E] rounded-full mx-auto -mt-2" />
              <div className="w-3 h-3 bg-[#4A6832] rounded-full mx-auto" />
              <div className="w-2 h-8 bg-[#8B6914] mx-auto" />
              <div className="w-6 h-3 bg-[#6B4F10] rounded-sm" />
            </div>
            {/* Painting */}
            <div className="absolute top-5 left-10 w-16 h-12 bg-[#D4B896] rounded border-2 border-[#A08060]">
              <div className="w-full h-full bg-gradient-to-br from-[#E8D5BA] to-[#C4A882] rounded-sm" />
            </div>
            {/* Rug */}
            <div className="absolute bottom-10 left-4 w-32 h-3 bg-[#C4956A] opacity-40 rounded-full blur-sm" />
            <div
              className="absolute bottom-3 left-0 right-0 text-center text-[10px] font-bold tracking-widest text-[#6B5540] uppercase"
            >
              Na
            </div>
          </div>
        </div>

        {/* Slider handle */}
        <div
          className="absolute top-0 bottom-0 flex items-center justify-center"
          style={{ left: `${sliderPos}%`, transform: 'translateX(-50%)' }}
        >
          <div className="w-0.5 h-full bg-white opacity-80" />
          <div className="absolute w-7 h-7 rounded-full bg-white shadow-lg border-2 border-[var(--border)] flex items-center justify-center">
            <svg width="10" height="10" viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path d="M5 4l-3 4 3 4M11 4l3 4-3 4" stroke="#5C5B58" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        </div>
      </div>

      {/* Style selector */}
      <div className="p-3 border-t border-[var(--border)]">
        <div className="flex items-center gap-1.5 mb-2">
          <div className="w-3 h-3 rounded-sm bg-[var(--accent)] opacity-80" aria-hidden="true" />
          <span className="text-[10px] font-semibold text-[var(--fg-muted)] uppercase tracking-wider">
            Interieurstijl
          </span>
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {STYLES.map((style, i) => (
            <button
              key={style}
              onClick={() => setActiveStyle(i)}
              className={[
                'text-[10px] font-semibold px-2 py-1 rounded-[4px] transition-colors',
                activeStyle === i
                  ? 'bg-[var(--brand)] text-white'
                  : 'bg-[var(--bg-muted)] text-[var(--fg-muted)] hover:bg-[var(--border)]',
              ].join(' ')}
            >
              {style}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
