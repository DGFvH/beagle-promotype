'use client'

import { useEffect, useState } from 'react'

const MESSAGES = [
  { from: 'user', text: 'Is er vloerverwarming aanwezig?' },
  {
    from: 'bot',
    text: 'Ja! De woning is voorzien van vloerverwarming op de begane grond en de eerste verdieping. Op de tweede verdieping zijn radiatoren aanwezig.',
  },
  { from: 'user', text: 'Wat is de VvE-bijdrage per maand?' },
]

export default function ObjectAssistentMockup() {
  const [cycle, setCycle] = useState(0)
  const [visibleCount, setVisibleCount] = useState(0)
  const [showTyping, setShowTyping] = useState(false)

  useEffect(() => {
    setVisibleCount(0)
    setShowTyping(false)

    const timers: ReturnType<typeof setTimeout>[] = []
    let delay = 600

    MESSAGES.forEach((msg, i) => {
      if (msg.from === 'bot') {
        timers.push(setTimeout(() => setShowTyping(true), delay))
        delay += 700
        timers.push(
          setTimeout(() => {
            setShowTyping(false)
            setVisibleCount(i + 1)
          }, delay)
        )
      } else {
        timers.push(setTimeout(() => setVisibleCount(i + 1), delay))
      }
      delay += 900
    })

    const loop = setTimeout(() => {
      setCycle((c) => c + 1)
    }, delay + 2000)

    return () => {
      timers.forEach(clearTimeout)
      clearTimeout(loop)
    }
  }, [cycle])

  return (
    <div className="mockup-browser w-full max-w-full sm:max-w-[420px] mx-auto">
      {/* Chrome */}
      <div className="mockup-chrome">
        <div className="mockup-dot bg-red-400" />
        <div className="mockup-dot bg-yellow-400" />
        <div className="mockup-dot bg-green-400" />
        <div className="mockup-url">uwkantoor.nl</div>
        <span className="ml-2 text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-orange-100 text-orange-600">
          BINNENKORT
        </span>
      </div>

      {/* Chat header */}
      <div className="flex items-center gap-2.5 px-4 py-2.5 border-b border-[var(--border)] bg-[var(--bg-muted)]">
        <div className="w-7 h-7 rounded-full bg-orange-50 flex items-center justify-center">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
            <polyline points="9 22 9 12 15 12 15 22"/>
          </svg>
        </div>
        <div>
          <div className="text-[11px] font-semibold text-[var(--fg)]">Object Assistent</div>
          <div className="text-[10px] text-[var(--success)] flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--success)] inline-block" />
            Online
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="p-3 space-y-2.5 min-h-[200px]">
        {MESSAGES.slice(0, visibleCount).map((msg, i) => (
          <div
            key={i}
            className={['flex', msg.from === 'user' ? 'justify-end' : 'justify-start'].join(' ')}
          >
            <div
              className={[
                'max-w-[80%] px-3 py-2 rounded-xl text-[11px] leading-relaxed',
                msg.from === 'user'
                  ? 'bg-[#cb4811] text-white rounded-br-sm'
                  : 'bg-[var(--bg-muted)] text-[var(--fg)] rounded-bl-sm',
              ].join(' ')}
            >
              {msg.text}
            </div>
          </div>
        ))}

        {/* Typing indicator */}
        {showTyping && (
          <div className="flex justify-start">
            <div className="bg-[var(--bg-muted)] px-3 py-2.5 rounded-xl rounded-bl-sm flex gap-1 items-center">
              {[0, 1, 2].map((i) => (
                <span
                  key={i}
                  className="w-1.5 h-1.5 bg-[var(--fg-subtle)] rounded-full animate-bounce"
                  style={{ animationDelay: `${i * 0.15}s` }}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Input bar */}
      <div className="flex items-center gap-2 px-3 py-2.5 border-t border-[var(--border)]">
        <div className="flex-1 bg-[var(--bg-muted)] rounded-lg px-3 py-1.5 text-[11px] text-[var(--fg-subtle)]">
          Stel een vraag over dit object...
        </div>
        <button
          aria-label="Verstuur"
          className="w-7 h-7 bg-[#cb4811] rounded-lg flex items-center justify-center hover:bg-[#a83d0e] transition-colors"
        >
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <line x1="22" y1="2" x2="11" y2="13"/>
            <polygon points="22 2 15 22 11 13 2 9 22 2"/>
          </svg>
        </button>
      </div>
    </div>
  )
}
