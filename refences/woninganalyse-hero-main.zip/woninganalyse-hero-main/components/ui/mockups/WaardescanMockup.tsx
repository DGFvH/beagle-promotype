'use client'

import { motion } from 'motion/react'

export default function WaardescanMockup() {
  return (
    <div className="relative w-full max-w-full sm:max-w-[420px] mx-auto">
      {/* Floating notification toast */}
      <motion.div
        initial={{ opacity: 0, y: -8, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ delay: 0.8, duration: 0.4, ease: 'easeOut' }}
        className="absolute -top-3 right-2 z-10 flex items-center gap-2 bg-[var(--fg)] text-white text-[11px] font-semibold px-3 py-1.5 rounded-full shadow-lg"
      >
        <span className="w-2 h-2 bg-[var(--success)] rounded-full animate-pulse" />
        Nieuwe lead! J. de Vries
      </motion.div>

      {/* Browser card */}
      <div className="mockup-browser">
        {/* Chrome bar */}
        <div className="mockup-chrome">
          <div className="mockup-dot bg-red-400" />
          <div className="mockup-dot bg-yellow-400" />
          <div className="mockup-dot bg-green-400" />
          <div className="mockup-url">uwkantoor.nl</div>
        </div>

        {/* Content */}
        <div className="p-5">
          {/* Header row */}
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-[10px] font-semibold uppercase tracking-wider text-[var(--fg-subtle)] mb-1">
                Geschatte woningwaarde
              </div>
              <div
                className="text-[32px] font-bold leading-none"
                style={{ color: 'var(--brand)', fontFamily: 'var(--font-dm-sans)' }}
              >
                € 450.000
              </div>
              <div className="text-[11px] text-[var(--fg-subtle)] mt-1">
                Gebaseerd op Kadaster &amp; marktanalyse
              </div>
            </div>
            <div className="w-12 h-12 rounded-full bg-[var(--brand-light)] flex items-center justify-center">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            {[
              { label: 'Oppervlak', value: '95 m²' },
              { label: 'Bouwjaar', value: '1935' },
              { label: 'Energielabel', value: 'C' },
            ].map((stat) => (
              <div
                key={stat.label}
                className="bg-[var(--bg-muted)] rounded-lg p-2.5 text-center"
              >
                <div className="text-[10px] text-[var(--fg-subtle)] mb-0.5">{stat.label}</div>
                <div className="text-[13px] font-semibold text-[var(--fg)]">{stat.value}</div>
              </div>
            ))}
          </div>

          {/* Progress bar */}
          <div className="space-y-1.5 mb-3">
            <div className="flex justify-between text-[10px] text-[var(--fg-subtle)]">
              <span>Marktpositie</span>
              <span>78/100</span>
            </div>
            <div className="h-1.5 bg-[var(--bg-muted)] rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: '78%' }}
                transition={{ delay: 0.5, duration: 1, ease: 'easeOut' }}
                className="h-full rounded-full"
                style={{ backgroundColor: 'var(--brand)' }}
              />
            </div>
          </div>

          {/* CTA hint */}
          <div className="text-center py-1.5 text-[11px] text-[var(--fg-subtle)]">
            Rapport wordt verstuurd naar uw e-mail
          </div>
        </div>
      </div>
    </div>
  )
}
