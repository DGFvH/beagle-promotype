'use client'

import { useState } from 'react'
import { ChevronDown } from 'lucide-react'

interface FAQItem {
  q: string
  a: string
}

export default function FAQAccordion({ items }: { items: FAQItem[] }) {
  const [open, setOpen] = useState<number | null>(null)
  return (
    <div className="space-y-2">
      {items.map((item, i) => (
        <div key={item.q} className="border border-[var(--border)] rounded-xl bg-[var(--bg-surface)] overflow-hidden">
          <button
            onClick={() => setOpen(open === i ? null : i)}
            className="w-full flex items-center justify-between px-6 py-5 text-left gap-4"
            aria-expanded={open === i}
          >
            <span className="text-heading-3 text-[var(--fg)]">{item.q}</span>
            <ChevronDown
              size={16}
              className={['text-[var(--fg-subtle)] transition-transform duration-200', open === i ? 'rotate-180' : ''].join(' ')}
              aria-hidden="true"
            />
          </button>
          {open === i && (
            <div className="px-6 pb-5">
              <p className="text-[15px] text-[var(--fg-muted)] leading-relaxed">{item.a}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  )
}
