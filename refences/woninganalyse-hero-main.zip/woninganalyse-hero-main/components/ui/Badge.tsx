interface BadgeProps {
  children: React.ReactNode
  variant?: 'brand' | 'accent' | 'success' | 'muted'
  className?: string
}

const variantClasses = {
  brand: 'bg-[var(--brand-light)] text-[var(--brand)]',
  accent: 'bg-orange-50 text-orange-700',
  success: 'bg-emerald-50 text-[var(--success)]',
  muted: 'bg-[var(--bg-muted)] text-[var(--fg-muted)]',
}

export function Badge({ children, variant = 'brand', className = '' }: BadgeProps) {
  return (
    <span
      className={[
        'inline-flex items-center text-label-sm px-2.5 py-1 rounded-[4px]',
        variantClasses[variant],
        className,
      ].join(' ')}
    >
      {children}
    </span>
  )
}
