'use client'

import * as Accordion from '@radix-ui/react-accordion'
import { ChevronDown } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'

const FAQS = [
  {
    q: 'Wat doet Woninganalyse precies?',
    a: 'Wij zijn een AI-bureau voor de Nederlandse makelaardij. We adviseren waar AI uw kantoor het meeste oplevert, bouwen de oplossing en zorgen dat die in de praktijk werkt. De tools op deze site — Waardescan, Huistekst, Object Assistent en Sfeerimpressie — zijn voorbeelden van wat we al maakten.',
  },
  {
    q: 'Bouwen jullie ook iets op maat voor mijn kantoor?',
    a: 'Ja. Naast de getoonde oplossingen ontwikkelen we maatwerk: van een aangepaste leadtool tot een AI-koppeling met uw bestaande systemen. We beginnen bij uw situatie, niet bij een standaardpakket.',
  },
  {
    q: 'Hoe verloopt een samenwerking?',
    a: 'We starten met een vrijblijvend gesprek over waar in uw kantoor tijd of omzet blijft liggen. Daarna adviseren we gericht, bouwen we stap voor stap en blijven we betrokken bij de implementatie. Geen langdurige IT-trajecten.',
  },
  {
    q: 'Werken jullie samen met onze website en CRM?',
    a: 'Ja. Onze oplossingen werken bóven op uw bestaande website en koppelen waar mogelijk met uw CRM en met bronnen zoals Funda, NVM en het Kadaster. We sluiten aan op uw werkwijze in plaats van die om te gooien.',
  },
  {
    q: 'Welke databronnen gebruiken jullie?',
    a: 'Onder meer het Kadaster (BAG, WOZ en transactie-inzichten), het CBS, Funda, NVM-data en FunderMaps, aangevuld met een koppeling naar uw eigen CRM. Zo zijn analyses en leads gebaseerd op actuele, betrouwbare data.',
  },
  {
    q: 'Is dit ook geschikt voor een klein of zelfstandig kantoor?',
    a: 'Zeker. Juist voor zelfstandigen en kleinere kantoren maakt AI het verschil: u doet meer met minder handen. We werken met zowel zelfstandige NVM-makelaars als grotere VBO-kantoren en schalen de aanpak op uw situatie.',
  },
  {
    q: 'Hoe zit het met privacy en AVG?',
    a: 'Onze oplossingen zijn AVG-conform en draaien waar gewenst white-label in uw eigen huisstijl. De gegevens van uw klanten blijven van u; we gaan zorgvuldig en transparant met data om.',
  },
]

const faqJsonLd = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: FAQS.map((faq) => ({
    '@type': 'Question',
    name: faq.q,
    acceptedAnswer: {
      '@type': 'Answer',
      text: faq.a,
    },
  })),
}

export default function FAQ() {
  return (
    <section
      id="faq"
      className="py-24 px-4 sm:px-6 bg-[var(--bg-muted)]"
      aria-labelledby="faq-heading"
    >
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-12">
          <Badge variant="muted" className="mb-4">FAQ</Badge>
          <h2 id="faq-heading" className="text-display-2 text-[var(--fg)]">
            Veelgestelde vragen
          </h2>
        </div>

        <Accordion.Root type="single" collapsible className="space-y-3">
          {FAQS.map((faq, i) => (
            <Accordion.Item
              key={i}
              value={`item-${i}`}
              className="bg-[var(--bg-surface)] border border-[var(--border)] rounded-xl overflow-hidden hover:border-[var(--border-hover)] transition-colors"
            >
              <Accordion.Header>
                <Accordion.Trigger
                  className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left text-[15px] font-semibold text-[var(--fg)] hover:text-[var(--brand)] transition-colors group focus-visible:outline-[var(--brand)] [&[data-state=open]]:text-[var(--brand)]"
                >
                  {faq.q}
                  <ChevronDown
                    size={16}
                    className="shrink-0 text-[var(--fg-subtle)] group-data-[state=open]:rotate-180 transition-transform duration-200"
                    aria-hidden="true"
                  />
                </Accordion.Trigger>
              </Accordion.Header>
              <Accordion.Content className="overflow-hidden data-[state=open]:animate-[accordion-down_0.2s_ease-out] data-[state=closed]:animate-[accordion-up_0.2s_ease-out]">
                <p className="px-5 pb-5 text-[15px] text-[var(--fg-muted)] leading-relaxed">
                  {faq.a}
                </p>
              </Accordion.Content>
            </Accordion.Item>
          ))}
        </Accordion.Root>
      </div>
    </section>
  )
}
