'use client'

import { useRef } from 'react'
import { useInView } from 'motion/react'
import { motion } from 'motion/react'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import WaardescanMockup from '@/components/ui/mockups/WaardescanMockup'
import HuistekstMockup from '@/components/ui/mockups/HuistekstMockup'
import SfeerimpressieMockup from '@/components/ui/mockups/SfeerimpressieMockup'
import ObjectAssistentMockup from '@/components/ui/mockups/ObjectAssistentMockup'

interface Tool {
  badge: string
  badgeVariant: 'brand' | 'accent'
  heading: string
  body: string
  ctaLabel: string
  ctaHref: string
  ctaDisabled?: boolean
  ctaColor?: 'brand' | 'accent'
  status: 'available' | 'coming-soon'
  mockup: React.ReactNode
  reverse: boolean
}

const TOOLS: Tool[] = [
  {
    badge: 'Waardescan',
    badgeVariant: 'brand',
    heading: 'Waardescan voor leads',
    body: 'Potentiële kopers en verkopers krijgen een indicatie van de waarde van hun huis; u ontvangt hun gegevens als lead. Alles via uw eigen website, in uw huisstijl.',
    ctaLabel: 'Bekijk Waardescan',
    ctaHref: '/tools/waardescan',
    ctaColor: 'brand',
    status: 'available',
    mockup: <WaardescanMockup />,
    reverse: false,
  },
  {
    badge: 'Object Assistent',
    badgeVariant: 'accent',
    heading: '24/7 vragen over het object',
    body: 'Upload een brochure; bezoekers stellen vragen over het huis wanneer het hen uitkomt. U vangt serieuze interesse op, ook \'s avonds en in het weekend.',
    ctaLabel: 'Bekijk Object Assistent',
    ctaHref: '/tools/object-assistent',
    ctaColor: 'accent',
    status: 'available',
    mockup: <ObjectAssistentMockup />,
    reverse: true,
  },
  {
    badge: 'Huistekst',
    badgeVariant: 'brand',
    heading: 'Huistekst in seconden, klaar voor Funda',
    body: 'Van steekwoorden naar een publicatieklare verkooptekst. Perfect voor Funda en uw eigen site. Kies stijl en taal; de AI doet de rest.',
    ctaLabel: 'Bekijk Huistekst',
    ctaHref: '/tools/huistekst',
    ctaColor: 'brand',
    status: 'available',
    mockup: <HuistekstMockup />,
    reverse: false,
  },
  {
    badge: 'Sfeerimpressie',
    badgeVariant: 'accent',
    heading: 'Laat zien wat er mogelijk is',
    body: 'Upload een foto van een opknapper, verbouwingsproject of pand met verouderd interieur. Sfeerimpressie toont hoe de ruimte er na een redesign uit kan zien. Kopers kopen sneller een woning als ze de mogelijkheden kunnen zien.',
    ctaLabel: 'Bekijk Sfeerimpressie',
    ctaHref: '/tools/sfeerimpressie',
    ctaColor: 'accent',
    status: 'available',
    mockup: <SfeerimpressieMockup />,
    reverse: true,
  },
]

function ToolBlock({ tool, index }: { tool: Tool; index: number }) {
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 32 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: 0.1, ease: 'easeOut' }}
      className={[
        'flex flex-col gap-10 items-center',
        tool.reverse ? 'lg:flex-row-reverse' : 'lg:flex-row',
      ].join(' ')}
    >
      {/* Text side — 55% */}
      <div className="flex-1 min-w-0">
        <Badge variant={tool.badgeVariant} className="mb-4">
          {tool.badge}
          {tool.status === 'coming-soon' && (
            <span className="ml-2 text-[9px] font-bold">· Binnenkort</span>
          )}
        </Badge>
        <h3 className="text-display-2 text-[var(--fg)] mb-4">{tool.heading}</h3>
        <p className="text-[17px] text-[var(--fg-muted)] leading-relaxed mb-7 max-w-[480px]">
          {tool.body}
        </p>

        {tool.ctaDisabled ? (
          <span className="inline-flex items-center gap-2 px-5 py-2.5 text-[15px] font-semibold rounded-[6px] border border-[var(--border)] text-[var(--fg-subtle)] cursor-not-allowed">
            {tool.ctaLabel}
          </span>
        ) : (
          <Link
            href={tool.ctaHref}
            className={[
              'inline-flex items-center gap-2 px-5 py-2.5 text-[15px] font-semibold rounded-[6px] text-white transition-colors group',
              tool.ctaColor === 'accent'
                ? 'bg-[#cb4811] hover:bg-[#a83d0e]'
                : 'bg-[var(--brand)] hover:bg-[var(--brand-dark)]',
            ].join(' ')}
          >
            {tool.ctaLabel}
            <ArrowRight
              size={14}
              className="group-hover:translate-x-1 transition-transform"
              aria-hidden="true"
            />
          </Link>
        )}
      </div>

      {/* Mockup side — compact preview on mobile, full size on desktop */}
      <div className="w-full lg:w-[45%] shrink-0">
        {/* Mobile: zoomed-down preview */}
        <div className="lg:hidden pointer-events-none" style={{ zoom: '0.62' }}>
          {tool.mockup}
        </div>
        {/* Desktop: full size */}
        <div className="hidden lg:block">
          {tool.mockup}
        </div>
      </div>
    </motion.div>
  )
}

export default function ToolsShowcase() {
  return (
    <section
      id="tools"
      className="py-24 px-4 sm:px-6"
      aria-labelledby="tools-heading"
    >
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <Badge variant="brand" className="mb-4">Wat we bouwen</Badge>
          <h2 id="tools-heading" className="text-display-2 text-[var(--fg)] mb-4">
            Een greep uit ons werk
          </h2>
          <p className="text-[17px] text-[var(--fg-muted)] max-w-[560px] mx-auto mb-8">
            Vier oplossingen die routineklussen overnemen en leads opleveren. Ze laten zien wat we voor de makelaardij kunnen ontwikkelen en wat we ook voor uw kantoor kunnen bouwen.
          </p>
        </div>

        {/* Tool blocks */}
        <div className="space-y-20">
          {TOOLS.map((tool, i) => (
            <div
              key={tool.badge}
              className="border border-[var(--border)] rounded-2xl p-8 sm:p-12 hover:border-[var(--border-hover)] transition-colors"
            >
              <ToolBlock tool={tool} index={i} />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
