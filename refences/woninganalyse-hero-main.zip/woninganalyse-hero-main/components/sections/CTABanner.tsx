'use client'

import { useRef } from 'react'
import { useInView } from 'motion/react'
import { motion } from 'motion/react'
import { useDemoModal } from '@/components/demo/DemoModalProvider'

export default function CTABanner() {
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-60px' })
  const { open } = useDemoModal()

  return (
    <section
      className="py-20 px-4 sm:px-6"
      style={{ background: 'linear-gradient(135deg, #0D2EB8 0%, #1B4FFF 50%, #3B6FFF 100%)' }}
      aria-labelledby="cta-heading"
    >
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 24 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.55, ease: 'easeOut' }}
        className="max-w-2xl mx-auto text-center"
      >
        <h2
          id="cta-heading"
          className="text-display-2 text-white mb-4"
        >
          Benieuwd wat AI voor uw kantoor kan betekenen?
        </h2>
        <p className="text-[17px] text-[rgba(255,255,255,0.78)] leading-relaxed mb-9 max-w-[520px] mx-auto">
          Plan een vrijblijvend gesprek. We denken met u mee over waar AI uw kantoor het meeste oplevert — en laten zien wat we al voor andere makelaars bouwden.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={open}
            className="inline-flex items-center justify-center gap-2 px-7 py-3 text-[15px] font-semibold rounded-[6px] bg-white text-[var(--brand)] hover:bg-[var(--brand-light)] transition-colors w-full sm:w-auto cursor-pointer"
          >
            Gesprek inplannen
          </button>
        </div>
      </motion.div>
    </section>
  )
}
