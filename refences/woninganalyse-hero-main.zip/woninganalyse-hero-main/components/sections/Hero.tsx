'use client'

import Image from 'next/image'
import { motion } from 'motion/react'
import { TrendingUp, Bell } from 'lucide-react'
import { useDemoModal } from '@/components/demo/DemoModalProvider'

// Compact card shown on mobile — small footprint, key info only
function MobileAnalysisCard() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6, duration: 0.5, ease: 'easeOut' }}
      className="w-full max-w-sm"
    >
      {/* Lead pill */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.0, duration: 0.35 }}
        className="inline-flex items-center gap-1.5 bg-[var(--fg)] text-white text-[10px] font-semibold px-2.5 py-1.5 rounded-full shadow-lg mb-2"
      >
        <span className="w-1.5 h-1.5 bg-[var(--success)] rounded-full animate-pulse" aria-hidden="true" />
        <Bell size={9} className="opacity-70" aria-hidden="true" />
        Nieuwe lead! J. de Vries
      </motion.div>

      {/* Card */}
      <div className="bg-white/95 backdrop-blur-md rounded-xl overflow-hidden shadow-xl border border-white/50">
        {/* Header */}
        <div className="flex items-center justify-between px-4 pt-3 pb-2 border-b border-[var(--border)]">
          <div className="flex items-center gap-1.5">
            <div className="w-5 h-5 rounded bg-[var(--brand)] flex items-center justify-center shrink-0">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
            </div>
            <span className="text-[11px] font-bold text-[var(--fg)]">Woninganalyse</span>
          </div>
          <span className="text-[9px] font-semibold px-1.5 py-0.5 bg-[var(--brand-light)] text-[var(--brand)] rounded-full">Live</span>
        </div>

        {/* Value */}
        <div className="px-4 py-3 bg-[var(--brand-light)]">
          <div className="text-[9px] font-bold uppercase tracking-wider text-[var(--brand)] mb-1">
            Geschatte marktwaarde
          </div>
          <div className="flex items-end justify-between">
            <span className="text-[26px] font-extrabold text-[var(--brand)] leading-none" style={{ letterSpacing: '-1px' }}>
              € 450.000
            </span>
            <div className="flex items-center gap-1 text-[var(--success)] text-[11px] font-semibold">
              <TrendingUp size={11} aria-hidden="true" />
              +3.2%
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="flex items-center divide-x divide-[var(--border)] px-0 py-2.5">
          {[{ label: 'Oppervlak', value: '95 m²' }, { label: 'Bouwjaar', value: '1935' }, { label: 'Label', value: 'C' }].map((s) => (
            <div key={s.label} className="flex-1 text-center px-2">
              <div className="text-[8px] font-bold uppercase tracking-wider text-[var(--fg-subtle)] mb-0.5">{s.label}</div>
              <div className="text-[12px] font-bold text-[var(--fg)]">{s.value}</div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  )
}

// Full card shown on desktop
function DesktopAnalysisCard() {
  return (
    <div className="relative w-full max-w-[340px]">
      {/* Lead notification */}
      <motion.div
        initial={{ opacity: 0, y: -10, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ delay: 1.0, duration: 0.4, ease: 'easeOut' }}
        className="absolute -top-4 right-3 z-10 flex items-center gap-2 bg-[var(--fg)] text-white text-[11px] font-semibold px-3 py-1.5 rounded-full shadow-xl"
      >
        <span className="w-1.5 h-1.5 bg-[var(--success)] rounded-full animate-pulse" />
        <Bell size={10} className="opacity-70" aria-hidden="true" />
        Nieuwe lead! J. de Vries
      </motion.div>

      {/* Main card */}
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ delay: 0.5, duration: 0.6, ease: 'easeOut' }}
        className="relative bg-white/95 backdrop-blur-md rounded-2xl overflow-hidden shadow-2xl border border-white/60"
      >
        <div className="flex items-center justify-between px-5 pt-4 pb-3 border-b border-[var(--border)]">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-[var(--brand)] flex items-center justify-center">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                <polyline points="9 22 9 12 15 12 15 22"/>
              </svg>
            </div>
            <span className="text-[12px] font-bold text-[var(--fg)]">Woninganalyse</span>
          </div>
          <span className="text-[10px] font-semibold px-2 py-0.5 bg-[var(--brand-light)] text-[var(--brand)] rounded-full">Live</span>
        </div>

        <div className="px-5 pt-3 pb-2">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-[var(--fg-subtle)] mb-0.5">Adres</div>
          <div className="text-[13px] font-semibold text-[var(--fg)]">Herengracht 100, Amsterdam</div>
        </div>

        <div className="px-5 py-3 bg-[var(--brand-light)]">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-[var(--brand)] mb-1">Geschatte marktwaarde</div>
          <div className="flex items-end justify-between">
            <span className="text-[32px] font-extrabold text-[var(--brand)] leading-none" style={{ fontFamily: 'var(--font-dm-sans)', letterSpacing: '-1px' }}>
              € 450.000
            </span>
            <div className="flex items-center gap-1 text-[var(--success)] text-[11px] font-semibold">
              <TrendingUp size={12} aria-hidden="true" />
              +3.2%
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-0 px-5 py-3">
          {[
            { label: 'Oppervlak', value: '95 m²' },
            { label: 'Bouwjaar', value: '1935' },
            { label: 'Label', value: 'C' },
          ].map((stat, i) => (
            <div key={stat.label} className={['text-center py-1', i > 0 ? 'border-l border-[var(--border)]' : ''].join(' ')}>
              <div className="text-[9px] font-semibold uppercase tracking-wider text-[var(--fg-subtle)] mb-0.5">{stat.label}</div>
              <div className="text-[13px] font-bold text-[var(--fg)]">{stat.value}</div>
            </div>
          ))}
        </div>

        <div className="px-5 pb-2">
          <div className="flex justify-between text-[10px] text-[var(--fg-subtle)] mb-1">
            <span>Marktpositie</span>
            <span className="font-semibold text-[var(--brand)]">78 / 100</span>
          </div>
          <div className="h-1.5 bg-[var(--bg-muted)] rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: '78%' }}
              transition={{ delay: 1.2, duration: 1.2, ease: 'easeOut' }}
              className="h-full rounded-full bg-gradient-to-r from-[var(--brand)] to-[#6B8FFF]"
            />
          </div>
        </div>

        <div className="px-5 pb-4 pt-2">
          <div className="text-[10px] text-[var(--fg-subtle)] text-center">
            Gratis rapport beschikbaar na aanvraag
          </div>
        </div>
      </motion.div>
    </div>
  )
}

export default function Hero() {
  const { open } = useDemoModal()
  return (
    <section
      className="relative min-h-[100svh] flex items-center overflow-hidden bg-[#070A16]"
      aria-labelledby="hero-heading"
    >
      {/* Background photo */}
      <Image
        src="/hero-bg.png"
        alt=""
        fill
        priority
        quality={90}
        className="object-cover object-center"
        sizes="100vw"
        aria-hidden="true"
      />

      {/* Overlay — aerial photo is bright; heavier overall, strong left for text legibility */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(105deg, rgba(8,10,20,0.88) 0%, rgba(8,10,20,0.75) 40%, rgba(8,10,20,0.50) 65%, rgba(8,10,20,0.35) 100%)',
        }}
        aria-hidden="true"
      />

      {/* Brand blue glow — bottom left */}
      <div
        className="absolute bottom-0 left-0 w-[500px] h-72 pointer-events-none"
        style={{ background: 'radial-gradient(ellipse at bottom left, rgba(27,79,255,0.18) 0%, transparent 70%)' }}
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-16 sm:pt-28 sm:pb-20 lg:py-32">
        <div className="flex flex-col lg:flex-row items-start lg:items-center gap-10 lg:gap-16">

          {/* Left — headline */}
          <div className="flex-1 max-w-[580px]">
            <motion.h1
              id="hero-heading"
              className="text-display-1 text-white mb-6"
              style={{ textShadow: '0 2px 20px rgba(0,0,0,0.4)' }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1, ease: 'easeOut' }}
            >
              AI die werkt
              <br />
              voor de moderne
              <br />
              <span style={{ color: 'var(--brand-light)', display: 'inline-block' }}>
                makelaar
              </span>
            </motion.h1>

            <motion.p
              className="text-[17px] text-white/70 leading-relaxed mb-9 max-w-[480px]"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2, ease: 'easeOut' }}
            >
              Wij zijn het AI-bureau voor de Nederlandse makelaardij. We bedenken, bouwen en implementeren AI die past bij uw kantoor — van leadgeneratie tot Funda-teksten en 24/7 objectvragen. De oplossingen hieronder bouwden we al.
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row gap-3 mb-6"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3, ease: 'easeOut' }}
            >
              <button
                onClick={open}
                className="inline-flex items-center justify-center gap-2 px-7 py-3 bg-[var(--brand)] text-white font-bold text-[15px] rounded-[6px] hover:bg-[var(--brand-dark)] transition-colors shadow-lg shadow-[rgba(27,79,255,0.35)] cursor-pointer"
              >
                Gesprek inplannen
              </button>
            </motion.div>

            <motion.div
              className="flex flex-wrap gap-x-5 gap-y-1.5 text-[12px] text-white/45"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <span>Live met 10+ makelaars</span>
              <span className="hidden sm:inline" aria-hidden="true">·</span>
              <span>500+ analyses uitgevoerd</span>
            </motion.div>
          </div>

          {/* Right — full card on desktop only */}
          <motion.div
            className="shrink-0 w-full lg:max-w-[340px]"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.4, ease: 'easeOut' }}
          >
            <div className="hidden lg:block">
              <DesktopAnalysisCard />
            </div>
          </motion.div>

        </div>
      </div>

      {/* Bottom fade into page */}
      <div
        className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
        style={{ background: 'linear-gradient(to top, var(--bg) 0%, transparent 100%)' }}
        aria-hidden="true"
      />
    </section>
  )
}
