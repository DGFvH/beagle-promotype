'use client'

import { useRef } from 'react'
import { useInView } from 'motion/react'
import { motion } from 'motion/react'
import { Landmark, BarChart3, Home, TrendingUp, Layers, Database } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'

const DATA_SOURCES = [
  {
    name: 'Kadaster',
    description: 'BAG, WOZ en transactiedata voor nauwkeurige woningwaarderingen.',
    icon: Landmark,
  },
  {
    name: 'CBS',
    description: 'Statistieken en buurtontwikkeling van het Centraal Bureau voor de Statistiek.',
    icon: BarChart3,
  },
  {
    name: 'Funda',
    description: 'Actueel aanbod en vraagprijzen als referentie voor de lokale markt.',
    icon: Home,
  },
  {
    name: 'NVM',
    description: 'Markttrends en transactiecijfers uit de NVM-data.',
    icon: TrendingUp,
  },
  {
    name: 'FunderMaps',
    description: 'Funderings- en bodemrisico’s per pand voor scherpere inschattingen.',
    icon: Layers,
  },
  {
    name: 'Uw CRM',
    description: 'Koppeling met uw eigen CRM, zodat leads en objectdata samenkomen.',
    icon: Database,
  },
]

export default function SocialProof() {
  const ref = useRef<HTMLDivElement>(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section
      className="py-20 px-4 sm:px-6 bg-[var(--bg-muted)]"
      aria-labelledby="data-sources-heading"
    >
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <Badge variant="muted" className="mb-4">Databronnen</Badge>
          <h2 id="data-sources-heading" className="text-display-2 text-[var(--fg)] mb-4">
            Gebouwd op betrouwbare data
          </h2>
          <p className="text-[17px] text-[var(--fg-muted)] max-w-[520px] mx-auto">
            We combineren officiële registers, actuele marktdata en een koppeling met uw eigen CRM voor nauwkeurige, bruikbare resultaten.
          </p>
        </div>

        <div
          ref={ref}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6"
        >
          {DATA_SOURCES.map((source, i) => {
            const Icon = source.icon
            return (
              <motion.div
                key={source.name}
                initial={{ opacity: 0, y: 24 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: i * 0.08, ease: 'easeOut' }}
                className="bg-[var(--bg-surface)] border border-[var(--border)] rounded-xl p-6 hover:border-[var(--border-hover)] transition-all hover:-translate-y-1 group"
              >
                <div className="mb-4 w-12 h-12 rounded-lg bg-[var(--brand-light)] flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Icon size={22} className="text-[var(--brand)]" aria-hidden="true" />
                </div>
                <h3 className="text-heading-3 text-[var(--fg)] mb-2">{source.name}</h3>
                <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed">
                  {source.description}
                </p>
              </motion.div>
            )
          })}
        </div>

        {/* Trust badges */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-3">
          {[
            'Voor NVM & VBO makelaars',
            'Officiële registers',
            'Veilig & betrouwbaar',
          ].map((badge) => (
            <span key={badge} className="text-[13px] font-medium text-[var(--fg-subtle)]">
              ✓ {badge}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
