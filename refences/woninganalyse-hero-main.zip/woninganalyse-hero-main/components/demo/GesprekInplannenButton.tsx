'use client'

import { Button } from '@/components/ui/Button'
import { useDemoModal } from '@/components/demo/DemoModalProvider'

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'outline'
type ButtonSize = 'sm' | 'md' | 'lg'

interface GesprekInplannenButtonProps {
  variant?: ButtonVariant
  size?: ButtonSize
  className?: string
  arrow?: boolean
  children?: React.ReactNode
}

/**
 * Client trigger that opens the global demo modal. Wraps the shared `Button`
 * (which renders a real <button> when no `href` is passed), so it can be dropped
 * into server-component pages where an inline onClick isn't allowed.
 */
export function GesprekInplannenButton({
  variant = 'primary',
  size = 'md',
  className,
  arrow,
  children = 'Gesprek inplannen',
}: GesprekInplannenButtonProps) {
  const { open } = useDemoModal()
  return (
    <Button variant={variant} size={size} className={className} arrow={arrow} onClick={open}>
      {children}
    </Button>
  )
}
