'use client'

import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { X } from 'lucide-react'
import DemoForm from '@/app/demo/DemoForm'

interface DemoModalContextValue {
  open: () => void
  close: () => void
  isOpen: boolean
}

const DemoModalContext = createContext<DemoModalContextValue | null>(null)

export function useDemoModal() {
  const ctx = useContext(DemoModalContext)
  if (!ctx) {
    throw new Error('useDemoModal must be used within a DemoModalProvider')
  }
  return ctx
}

export default function DemoModalProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false)
  const panelRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<HTMLElement | null>(null)

  const open = useCallback(() => setIsOpen(true), [])
  const close = useCallback(() => setIsOpen(false), [])

  // Lock body scroll, close on Escape, and manage focus while open
  // (scroll-lock mirrors Navbar's pattern).
  useEffect(() => {
    if (!isOpen) return

    // Remember the element that had focus so we can restore it on close.
    triggerRef.current = document.activeElement as HTMLElement | null
    panelRef.current?.focus()

    document.body.style.overflow = 'hidden'

    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') setIsOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)

    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKeyDown)
      triggerRef.current?.focus()
    }
  }, [isOpen])

  return (
    <DemoModalContext.Provider value={{ open, close, isOpen }}>
      {children}

      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="demo-modal-heading"
          >
            {/* Backdrop */}
            <div
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={close}
              aria-hidden="true"
            />

            {/* Panel */}
            <motion.div
              ref={panelRef}
              tabIndex={-1}
              className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[var(--bg-surface)] border border-[var(--border)] rounded-2xl shadow-2xl p-7 sm:p-9 focus:outline-none"
              initial={{ opacity: 0, y: 24, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.98 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
            >
              <button
                onClick={close}
                aria-label="Sluit venster"
                className="absolute top-4 right-4 p-2 rounded-lg text-[var(--fg-subtle)] hover:text-[var(--fg)] hover:bg-[var(--bg-muted)] transition-colors"
              >
                <X size={18} aria-hidden="true" />
              </button>

              <div className="mb-6 pr-8">
                <h2 id="demo-modal-heading" className="text-heading-3 text-[var(--fg)] mb-2">
                  Gesprek inplannen
                </h2>
                <p className="text-[15px] text-[var(--fg-muted)] leading-relaxed">
                  Laat uw gegevens achter; we nemen telefonisch contact op om een vrijblijvend
                  gesprek in te plannen over wat AI voor uw kantoor kan betekenen.
                </p>
              </div>

              <DemoForm submitLabel="Gesprek inplannen →" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </DemoModalContext.Provider>
  )
}
