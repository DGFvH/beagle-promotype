'use client'

import { useState, useEffect } from 'react'
import { X } from 'lucide-react'
import { hasConsent, grantConsent, CONSENT_EVENT } from '@/lib/consent'

export default function CookieBanner() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    if (!hasConsent()) setVisible(true)
  }, [])

  function accept() {
    grantConsent()
    // Notify consent-gated scripts (e.g. GoogleAnalytics) so they can
    // start tracking the rest of this session, not just future page loads.
    window.dispatchEvent(new Event(CONSENT_EVENT))
    setVisible(false)
  }

  if (!visible) return null

  return (
    <div
      role="dialog"
      aria-label="Cookie-melding"
      aria-live="polite"
      className="fixed bottom-0 left-0 right-0 z-[60] p-4"
    >
      <div
        className="max-w-4xl mx-auto flex flex-col sm:flex-row items-start sm:items-center gap-4 rounded-xl border border-[var(--border)] bg-[var(--bg-surface)] p-5 shadow-lg"
      >
        <div className="flex-1 text-sm text-[var(--fg-muted)] leading-relaxed">
          <span className="font-semibold text-[var(--fg)]">Cookies & Privacy — </span>
          Woninganalyse gebruikt functionele en analytische cookies om de website te verbeteren. Uw gegevens worden nooit verkocht.{' '}
          <a
            href="/privacybeleid"
            className="text-[var(--brand)] underline underline-offset-2 hover:text-[var(--brand-dark)]"
          >
            Lees ons privacybeleid
          </a>
          .
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={accept}
            className="px-4 py-2 bg-[var(--brand)] text-white text-sm font-semibold rounded-[6px] hover:bg-[var(--brand-dark)] transition-colors focus-visible:outline-[var(--brand)]"
          >
            Akkoord
          </button>
          <button
            onClick={accept}
            aria-label="Sluit cookiemelding"
            className="p-1.5 rounded-md text-[var(--fg-subtle)] hover:text-[var(--fg)] hover:bg-[var(--bg-muted)] transition-colors"
          >
            <X size={16} aria-hidden="true" />
          </button>
        </div>
      </div>
    </div>
  )
}
