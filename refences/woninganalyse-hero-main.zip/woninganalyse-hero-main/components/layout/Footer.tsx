'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Linkedin } from 'lucide-react'
import { useDemoModal } from '@/components/demo/DemoModalProvider'

const footerLinks = {
  tools: [
    { label: 'Waardescan', href: '/tools/waardescan' },
    { label: 'Huistekst', href: '/tools/huistekst' },
    { label: 'Sfeerimpressie', href: '/tools/sfeerimpressie' },
    { label: 'Object Assistent', href: '/tools/object-assistent' },
  ],
  bedrijf: [
    { label: 'Voor Makelaars', href: '/voor-makelaars' },
    { label: 'Over ons', href: '/over-ons' },
    { label: 'Blog', href: '/blog' },
    { label: 'Contact', href: '/contact' },
  ],
  juridisch: [
    { label: 'Privacybeleid', href: '/privacybeleid' },
    { label: 'Gebruiksvoorwaarden', href: '/gebruiksvoorwaarden' },
  ],
}

export default function Footer() {
  const { open } = useDemoModal()
  return (
    <footer role="contentinfo" className="border-t border-[var(--border)] bg-[var(--bg-surface)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand column */}
          <div className="lg:col-span-1">
            <Link
              href="/"
              className="inline-flex items-center mb-4"
              aria-label="Woninganalyse homepage"
            >
              <Image
                src="/logo-color.png"
                alt="Woninganalyse"
                width={180}
                height={36}
                className="h-7 w-auto"
              />
            </Link>
            <p className="text-[14px] text-[var(--fg-muted)] leading-relaxed mb-5">
              Slimme AI-tools voor moderne makelaars. Snel, betrouwbaar en ontwikkeld voor de dagelijkse praktijk.
            </p>
            <div className="flex gap-3">
              <a
                href="https://www.linkedin.com/company/tinybasenl"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Woninganalyse op LinkedIn"
                className="p-2 rounded-md border border-[var(--border)] text-[var(--fg-muted)] hover:text-[var(--brand)] hover:border-[var(--brand)] transition-colors"
              >
                <Linkedin size={15} aria-hidden="true" />
              </a>
            </div>
            <address className="not-italic mt-5 text-[12px] text-[var(--fg-subtle)] leading-relaxed">
              <strong className="font-semibold text-[var(--fg-muted)]">Woninganalyse (onderdeel van TinyBase B.V.)</strong>
              <br />
              <a
                href="mailto:info@woninganalyse.nl"
                className="hover:text-[var(--fg)] transition-colors"
              >
                info@woninganalyse.nl
              </a>
            </address>
          </div>

          {/* Oplossingen */}
          <div>
            <h3 className="text-[12px] font-semibold uppercase tracking-wider text-[var(--fg-subtle)] mb-4">
              Oplossingen
            </h3>
            <ul className="space-y-2.5">
              {footerLinks.tools.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-[14px] text-[var(--fg-muted)] hover:text-[var(--fg)] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Bedrijf */}
          <div>
            <h3 className="text-[12px] font-semibold uppercase tracking-wider text-[var(--fg-subtle)] mb-4">
              Bedrijf
            </h3>
            <ul className="space-y-2.5">
              {footerLinks.bedrijf.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-[14px] text-[var(--fg-muted)] hover:text-[var(--fg)] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
              <li>
                <button
                  onClick={open}
                  className="text-[14px] text-[var(--fg-muted)] hover:text-[var(--fg)] transition-colors cursor-pointer"
                >
                  Gesprek inplannen
                </button>
              </li>
            </ul>
          </div>

          {/* Juridisch */}
          <div>
            <h3 className="text-[12px] font-semibold uppercase tracking-wider text-[var(--fg-subtle)] mb-4">
              Juridisch
            </h3>
            <ul className="space-y-2.5">
              {footerLinks.juridisch.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-[14px] text-[var(--fg-muted)] hover:text-[var(--fg)] transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-6 border-t border-[var(--border)] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[12px] text-[var(--fg-subtle)]">
            © {new Date().getFullYear()} Woninganalyse · KVK: i.o.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1">
            <span className="text-[12px] text-[var(--fg-subtle)]">Kadaster-data</span>
            <span className="text-[var(--border)] hidden sm:inline" aria-hidden="true">·</span>
            <span className="text-[12px] text-[var(--fg-subtle)]">Veilig &amp; betrouwbaar</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
