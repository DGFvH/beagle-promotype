'use client'

import { useState, useEffect } from 'react'
import { usePathname } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import { Menu, X, ChevronDown } from 'lucide-react'
import { useDemoModal } from '@/components/demo/DemoModalProvider'

const navLinks = [
  {
    label: 'Oplossingen',
    href: '#tools',
    children: [
      { label: 'Waardescan', href: '/tools/waardescan', desc: 'Indicatie voor kopers, leads voor u' },
      { label: 'Object Assistent', href: '/tools/object-assistent', desc: '24/7 vragen over het object' },
      { label: 'Huistekst', href: '/tools/huistekst', desc: 'Verkoopteksten in seconden, o.a. Funda' },
      { label: 'Sfeerimpressie', href: '/tools/sfeerimpressie', desc: 'Redesign-impressie van pand en foto’s' },
    ],
  },
  { label: 'Voor Makelaars', href: '/voor-makelaars' },
  { label: 'Blog', href: '/blog' },
]

export default function Navbar() {
  const pathname = usePathname()
  const isHome = pathname === '/'
  const { open: openDemoModal } = useDemoModal()

  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [toolsOpen, setToolsOpen] = useState(false)

  // On non-home pages: always show the solid bar (isHome=false → showSolid=true from the start)
  const showSolid = scrolled || !isHome

  useEffect(() => {
    function onScroll() {
      setScrolled(window.scrollY > 60)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    if (mobileOpen) document.body.style.overflow = 'hidden'
    else document.body.style.overflow = ''
    return () => { document.body.style.overflow = '' }
  }, [mobileOpen])

  return (
    <>
      <header
        role="banner"
        className={[
          'fixed top-0 left-0 right-0 z-[60] transition-all duration-200',
          showSolid
            ? 'bg-[rgba(246,247,251,0.92)] backdrop-blur-[12px] border-b border-[var(--border)] shadow-sm'
            : 'bg-transparent',
        ].join(' ')}
      >
        <nav
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between"
          aria-label="Hoofdnavigatie"
        >
        {/* Logo — white when over hero, color when scrolled */}
        <Link
          href="/"
          className="flex items-center shrink-0 focus-visible:outline-[var(--brand)]"
          aria-label="Woninganalyse — terug naar homepage"
        >
          <Image
            src={showSolid ? '/logo-color.png' : '/logo-white.png'}
            alt="Woninganalyse"
            width={200}
            height={40}
            className="h-9 w-auto transition-opacity duration-200"
          />
        </Link>

        {/* Desktop nav */}
        <div className="hidden lg:flex items-center gap-0.5">
          {/* Tools dropdown */}
          <div className="relative">
            <button
              onClick={() => setToolsOpen(!toolsOpen)}
              onBlur={() => setTimeout(() => setToolsOpen(false), 150)}
              className={[
                'flex items-center gap-1 px-3 py-2 text-[14px] font-medium rounded-lg transition-colors',
                showSolid
                  ? 'text-[var(--fg-muted)] hover:text-[var(--fg)] hover:bg-[var(--bg-muted)]'
                  : 'text-white/80 hover:text-white hover:bg-white/10',
              ].join(' ')}
            >
              Oplossingen
              <ChevronDown
                size={13}
                className={['transition-transform duration-150', toolsOpen ? 'rotate-180' : ''].join(' ')}
                aria-hidden="true"
              />
            </button>
            {toolsOpen && (
              <div className="absolute top-full left-0 mt-2 w-64 bg-[var(--bg-surface)] border border-[var(--border)] rounded-xl shadow-xl p-2">
                {navLinks[0].children!.map((child) => (
                  <Link
                    key={child.href}
                    href={child.href}
                    className="flex flex-col px-3 py-2.5 rounded-lg hover:bg-[var(--bg-muted)] transition-colors group"
                    onClick={() => setToolsOpen(false)}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[13px] font-semibold text-[var(--fg)] group-hover:text-[var(--brand)] transition-colors">
                        {child.label}
                      </span>
                    </div>
                    <span className="text-[12px] text-[var(--fg-subtle)]">{child.desc}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {navLinks.slice(1).map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={[
                'px-3 py-2 text-[14px] font-medium rounded-lg transition-colors',
                showSolid
                  ? 'text-[var(--fg-muted)] hover:text-[var(--fg)] hover:bg-[var(--bg-muted)]'
                  : 'text-white/80 hover:text-white hover:bg-white/10',
              ].join(' ')}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Desktop CTAs */}
        <div className="hidden lg:flex items-center gap-3">
          <a
            href="https://platform.woninganalyse.nl/login"
            target="_blank"
            rel="noopener noreferrer"
            className={[
              'text-[14px] font-medium transition-colors px-2',
              showSolid ? 'text-[var(--fg-muted)] hover:text-[var(--fg)]' : 'text-white/70 hover:text-white',
            ].join(' ')}
          >
            Inloggen
          </a>
          <button
            onClick={openDemoModal}
            className={[
              'inline-flex items-center justify-center font-semibold rounded-[6px] transition-all duration-150 px-4 py-2 text-sm cursor-pointer',
              showSolid
                ? 'bg-transparent text-[var(--brand)] border border-[var(--brand)] hover:bg-[var(--brand-light)]'
                : 'bg-[var(--brand)] text-white border border-[var(--brand)] hover:bg-[var(--brand-dark)]',
            ].join(' ')}
          >
            Gesprek inplannen
          </button>
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className={[
            'lg:hidden relative z-10 p-2 rounded-md transition-colors',
            showSolid
              ? 'text-[var(--fg-muted)] hover:text-[var(--fg)] hover:bg-[var(--bg-muted)]'
              : 'text-white/80 hover:text-white hover:bg-white/10',
          ].join(' ')}
          aria-label={mobileOpen ? 'Sluit menu' : 'Open menu'}
          aria-expanded={mobileOpen}
          aria-controls="mobile-menu"
        >
          {mobileOpen ? <X size={22} aria-hidden="true" /> : <Menu size={22} aria-hidden="true" />}
        </button>
        </nav>
      </header>

      {/* Mobile menu */}
      {mobileOpen && (
        <div
          id="mobile-menu"
          className="lg:hidden fixed left-0 right-0 top-16 bottom-0 z-[70] bg-[var(--bg)] border-t border-[var(--border)] overflow-y-auto"
        >
          <div className="px-4 py-6 space-y-1">
            <div className="text-[11px] font-bold uppercase tracking-wider text-[var(--fg-subtle)] px-3 mb-2">
              Oplossingen
            </div>
            {navLinks[0].children!.map((child) => (
              <Link
                key={child.href}
                href={child.href}
                onClick={() => setMobileOpen(false)}
                className="flex items-center justify-between px-3 py-3 rounded-lg hover:bg-[var(--bg-muted)] transition-colors"
              >
                <div>
                  <div className="text-[15px] font-semibold text-[var(--fg)]">{child.label}</div>
                  <div className="text-[12px] text-[var(--fg-subtle)]">{child.desc}</div>
                </div>
              </Link>
            ))}

            <div className="h-px bg-[var(--border)] my-3" />

            {navLinks.slice(1).map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="block px-3 py-3 text-[15px] font-medium text-[var(--fg)] rounded-lg hover:bg-[var(--bg-muted)] transition-colors"
              >
                {link.label}
              </Link>
            ))}

            <div className="h-px bg-[var(--border)] my-3" />

            <div className="space-y-3 px-1">
              <button
                onClick={() => { setMobileOpen(false); openDemoModal() }}
                className="w-full justify-center inline-flex items-center font-semibold rounded-[6px] transition-all duration-150 px-5 py-2.5 text-[15px] bg-[var(--brand)] text-white border border-[var(--brand)] hover:bg-[var(--brand-dark)] cursor-pointer"
              >
                Gesprek inplannen
              </button>
              <a
                href="https://platform.woninganalyse.nl/login"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-center text-[15px] text-[var(--fg-muted)] hover:text-[var(--fg)] transition-colors py-2"
              >
                Inloggen →
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
