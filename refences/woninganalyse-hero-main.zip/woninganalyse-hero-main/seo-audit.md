# SEO Audit — `woninganalyse.nl` (marketing repo)

**Phase 1 deliverable.** Read-only inventory; no code changes were made.

**Scope.** All public routes under `app/`. Constraints from `CLAUDE-CODE-SEO-PROMPT.md` §2 are respected.

**Stack note.** Next.js `16.2.0`, React 19, Tailwind 4. Per `AGENTS.md` this is not the Next.js you may know — `app/opengraph-image.tsx`, `app/icon.tsx`, `app/apple-icon.tsx` are file-convention image generators (route-bound), and `metadataBase` is set globally in `app/layout.tsx`.

---

## 1. Current metadata coverage

`metadataBase` is `https://woninganalyse.nl` (bare domain, no `www`) — set in `app/layout.tsx:22`. Root `<title>` template is `%s | Woninganalyse`. Default OG `siteName` is `Woninganalyse`, locale `nl_NL`, type `website`. `twitter.card = summary_large_image` is set globally; `twitter.site` is **not** set (good — see §6 of `SEO-CONTEXT.md`).

| Route | `<title>` | description | canonical | OG image | JSON-LD emitted |
|---|---|---|---|---|---|
| `/` | `Woninganalyse — Slimme tools voor makelaars` | "Waardescan voor leads, Huistekst voor Funda, sfeerimpressie van uw foto's en Object Assistent voor 24/7 objectvragen…" | `https://woninganalyse.nl` | dynamic via `app/opengraph-image.tsx` | `Organization`, `SoftwareApplication`, `FAQPage` (rendered from `components/sections/FAQ.tsx`) |
| `/voor-makelaars` | `Woninganalyse voor Makelaars — Meer uit uw werkdag halen` | "Hoe Woninganalyse makelaars helpt meer leads te genereren…" | `https://woninganalyse.nl/voor-makelaars` | dynamic (root) | — none — |
| `/tools/waardescan` | `Waardescan — Leadgeneratie via woningwaarde` | "Bied bezoekers een gratis woningwaardering aan…" | `https://woninganalyse.nl/tools/waardescan` | dynamic (root) | `SoftwareApplication` with embedded `Offer` |
| `/tools/huistekst` | `Huistekst — AI woningbeschrijvingen in seconden` | "Genereer professionele woningbeschrijvingen met AI…" | `https://woninganalyse.nl/tools/huistekst` | dynamic (root) | `SoftwareApplication` with embedded `Offer` |
| `/tools/sfeerimpressie` | `Sfeerimpressie — Laat zien hoe het kan worden \| Woninganalyse` | "Binnenkort: upload een foto van een ouder pand…" | `https://woninganalyse.nl/tools/sfeerimpressie` | dynamic (root) | `SoftwareApplication` with embedded `Offer` |
| `/tools/object-assistent` | `Object Assistent — AI beantwoordt 24/7 objectvragen \| Woninganalyse` | "Upload een brochure; bezoekers stellen vragen…" | `https://woninganalyse.nl/tools/object-assistent` | dynamic (root) | `SoftwareApplication` with embedded `Offer` |
| `/blog` | `Blog — Inzichten voor makelaars \| Woninganalyse` | "Artikelen over woningwaardering, AI-tools voor makelaars…" | `https://woninganalyse.nl/blog` | dynamic (root) | — none — |
| `/blog/[slug]` (4 posts) | `<post.title> \| Woninganalyse Blog` | post.description | `https://woninganalyse.nl/blog/<slug>` | dynamic (root) | `BlogPosting` (no `image`, `wordCount`, `articleSection`, `keywords`) |
| `/over-ons` | `Over Woninganalyse` | "Woninganalyse ontwikkelt AI-tools voor makelaars…" | `https://woninganalyse.nl/over-ons` | dynamic (root) | — none — |
| `/contact` | `Contact — Woninganalyse` | "Neem contact op met Woninganalyse…" | `https://woninganalyse.nl/contact` | dynamic (root) | `ContactPage` with nested `Organization` |
| `/privacybeleid` | `Privacybeleid` | "Privacybeleid van Woninganalyse…" | `https://woninganalyse.nl/privacybeleid` | dynamic (root) | — none — |
| `/gebruiksvoorwaarden` | `Gebruiksvoorwaarden` | "Gebruiksvoorwaarden van Woninganalyse…" | `https://woninganalyse.nl/gebruiksvoorwaarden` | dynamic (root) | — none — |
| `/not-found` (404) | inherits `Woninganalyse — Slimme tools voor makelaars` | inherits root | — | dynamic (root) | — none — |

### Naming consistency vs. `SEO-CONTEXT.md`

- Platform calls the chatbot **Woningchat**; marketing calls it **Object Assistent**. Per the prompt, marketing's naming is the correct one. Verified: every surface in this repo (Navbar `components/layout/Navbar.tsx:16`, Footer `components/layout/Footer.tsx:10`, homepage FAQ `components/sections/FAQ.tsx:29`, ToolsShowcase `components/sections/ToolsShowcase.tsx:42`, blog post `lib/blog-data.ts:148–151`) consistently says **Object Assistent**. No bleed-through of "Woningchat".
- `SEO-CONTEXT.md` §1 lists **5** tools (Waardescan, Huistekst, Sfeerimpressie, Woningchat, **Lead Management**). Marketing surfaces only 4 product pages — Lead Management is treated as a feature embedded in the other tools (the lead-email mockup on `/tools/waardescan` and the dashboard mention) rather than a separate page. This is a deliberate choice; flagging in case a `/tools/lead-management` page is wanted later.
- Trust-anchor coverage on the home/social-proof block (`components/sections/SocialProof.tsx`) lists **Kadaster · CBS · Marktdata** (3) — `SEO-CONTEXT.md` §4 lists **Kadaster · CBS · WOZ · BAG · AVG-conform · NVM/VBO** (6). NVM/VBO appears as a separate badge on the same component (line 93). WOZ, BAG, AVG-conform are not surfaced on `/`. The Waardescan page (`app/tools/waardescan/page.tsx:188–191`) mentions Kadaster, CBS, WOZ-referenties.

### Other metadata findings

- `lib/metadata.ts` defines a `buildMetadata` helper that references a static OG image at `/og-image.png`. The helper is **not imported anywhere** (dead code). It would also reference a non-existent file (see §7).
- `app/page.tsx:29` `Organization.logo` points to `https://woninganalyse.nl/og-image.png` — that file does not exist in `public/`. Replace with the actual logo asset (`/logo-color.png`) or with the dynamic OG endpoint. **Likely 404 in JSON-LD validators.**
- `app/page.tsx` Organization JSON-LD lacks `@id` (needed in Phase 3e to allow `Service`/`SoftwareApplication` to reference it).
- All canonical URLs use the bare domain (`https://woninganalyse.nl`). `SEO-CONTEXT.md` §2 says the platform repo treats `www.woninganalyse.nl` as canonical (commit 41fc77a). The prompt's Hard Constraint #4 already flags this — **needs confirmation of what Vercel/DNS actually serves before any change**.
- `vercel.json` only sets iframe-embedding headers for `/chat/*`. No SEO-affecting headers (no X-Robots-Tag, no Link rel=canonical).
- `next.config.ts` redirects `/avg → /privacybeleid` (good) and `/integraties → /contact` (will need to be removed when Phase 4b ships the real `/integraties` page).
- `next.config.ts` rewrites (server-side proxy, transparent to crawlers): `/m/:path*`, `/preview/:path*`, `/assets/:path*`, `/~api/:path*`, `/~flock.js`, `/woningchat-favicon.svg`, `/favicon.png` are all forwarded to `platform.woninganalyse.nl`. **SEO risk + decision (resolved 2026-04-27):** `/m/{slug}` is now the canonical URL on marketing per Open Question 3 below — the rewrite stays, and the canonical signal lands via platform's HTML (see `HANDOFF.md` §2). For the rest: only `/preview/` is added to the marketing-side disallow list. `/assets/`, `/~api/`, `/~flock.js` are rendering dependencies (Googlebot's headless Chromium needs them to render `/m/` pages and read the canonical) — leave allowed. `/chat/` indexability is platform's call via per-page `noindex`, documented in `HANDOFF.md`.

---

## 2. Structured data gaps

Recommendation source: `SEO-CONTEXT.md` §5 + acceptance criteria in `CLAUDE-CODE-SEO-PROMPT.md` §5.

| Page | Has now | Missing (per prompt's "Acceptance criteria") | Notes |
|---|---|---|---|
| `/` | `Organization`, `SoftwareApplication`, `FAQPage` | `WebSite` (with optional `SearchAction`); Organization needs `@id` for cross-references in Phase 3 | **Correction to prompt's Phase 1 hint:** Prompt §4-Phase-1 says "missing: FAQPage on homepage FAQ component". This is **already present** at `components/sections/FAQ.tsx:42–53`. |
| `/voor-makelaars` | — | `BreadcrumbList`, optionally `Service` (B2B service page) | |
| `/tools/waardescan` | `SoftwareApplication` (+ embedded `Offer`) | `Service`, `BreadcrumbList`, `FAQPage` (page has 5 inline FAQs but no schema) | |
| `/tools/huistekst` | `SoftwareApplication` (+ embedded `Offer`) | `Service`, `BreadcrumbList`, `FAQPage` (5 inline FAQs) | |
| `/tools/sfeerimpressie` | `SoftwareApplication` (+ embedded `Offer`) | `Service`, `BreadcrumbList`, `FAQPage` (2 inline FAQs) | "Binnenkort" status — keep schema but page may want a `releaseDate`. |
| `/tools/object-assistent` | `SoftwareApplication` (+ embedded `Offer`) | `Service`, `BreadcrumbList`, `FAQPage` (5 inline FAQs in `FAQAccordion`) | |
| `/blog` | — | `BreadcrumbList`, optionally `Blog`/`CollectionPage` | |
| `/blog/[slug]` | `BlogPosting` (basic) | `BreadcrumbList`; enrichment per Phase 3f: `image`, `wordCount`, `articleSection` (= `category`), `keywords` (from `relatedTool`/`category`). `author` is currently `Organization` only — fine. | |
| `/over-ons` | — | `BreadcrumbList`, `AboutPage` | |
| `/contact` | `ContactPage` (with nested `Organization`) | `BreadcrumbList`. Organization here is a near-duplicate of homepage's — should reference homepage's `@id` once that's added (Phase 3e). | |
| `/privacybeleid`, `/gebruiksvoorwaarden` | — | `BreadcrumbList` (low priority) | |

### Decisions / clarifications captured during Phase 3 (shipped 2026-04-27)

- **`Product` + `Offer` per tool:** `SEO-CONTEXT.md` §5 recommends them, but `SoftwareApplication.offers` (already present) is the more correct schema for SaaS. Phase 3d intentionally **did not add a separate `Product` block**. Reasoning is captured as a comment in `lib/jsonld.ts`.
- **`Service` per tool:** added alongside `SoftwareApplication` via the `buildService` helper, with per-tool `serviceType` ("Leadgeneratie voor makelaars" / "Verkooptekstgeneratie" / "Vastgoedvisualisatie" / "AI-objectassistentie") and `provider: { @id: 'https://www.woninganalyse.nl/#organization' }` pointing at the homepage Organization. `areaServed: "NL"`.
- **`Organization` `@id` + fixed `logo`:** `app/page.tsx` Organization now carries `@id: 'https://www.woninganalyse.nl/#organization'` so other schemas reference it cleanly. `logo` flipped from the non-existent `/og-image.png` to `/logo-color.png` (real file in `public/`). The shared `ORGANIZATION_ID` constant lives in `lib/jsonld.ts`.
- **`BreadcrumbList` everywhere:** added on every non-home route (4 tools, /blog, /blog/[slug], /voor-makelaars, /over-ons, /contact, /privacybeleid, /gebruiksvoorwaarden). "Tools" item links to `https://www.woninganalyse.nl/#tools` (the homepage anchor) since there is no `/tools` index page.
- **`BlogPosting` enrichment:** the inline JSON-LD in `app/blog/[slug]/page.tsx` was replaced with `buildBlogPosting(...)`. New fields: `image` (the per-post `opengraph-image` URL), `wordCount` (computed at build time via the new `getPostWordCount` helper in `lib/blog-data.ts`), `articleSection` (= `category`), `keywords` (= `category` + `relatedTool`). `author` and `publisher` now both reference the Organization by `@id` instead of duplicating the entity inline.
- **No `aggregateRating` anywhere** — confirmed absent. Hard Constraint #2 already protected against this.

### Live verification (Phase 3, 2026-04-27)
- `next build` succeeds; all 27 routes prerendered, no errors.
- `curl https://www.woninganalyse.nl/...` (against local `next start`) on home, /tools/waardescan, /blog/woningwaarde-berekenen-2025 confirms each page emits the expected JSON-LD blocks. Sample output captured in this PR's commit message.

---

## 3. Sitemap accuracy

`app/sitemap.ts` defines 11 static entries + dynamic blog entries (4 posts → 4 URLs).

| URL in sitemap | Source file exists? | Priority | `lastModified` | Notes |
|---|---|---|---|---|
| `/` | ✓ `app/page.tsx` | 1.0 | `now` | Per prompt 2b target ✓ |
| `/voor-makelaars` | ✓ `app/voor-makelaars/page.tsx` | 0.9 | `now` | Per prompt 2b target ✓ |
| `/tools/waardescan` | ✓ `app/tools/waardescan/page.tsx` | 0.9 | `now` | Per prompt 2b target ✓ |
| `/tools/huistekst` | ✓ `app/tools/huistekst/page.tsx` | 0.8 | `now` | Per prompt 2b target (0.7–0.9) ✓ |
| `/tools/sfeerimpressie` | ✓ `app/tools/sfeerimpressie/page.tsx` | 0.7 | `now` | Per prompt 2b target ✓. "Binnenkort" page — consider 0.6. |
| `/tools/object-assistent` | ✓ `app/tools/object-assistent/page.tsx` | 0.7 | `now` | Per prompt 2b target ✓ |
| `/blog` | ✓ `app/blog/page.tsx` | 0.8 | `now` | Per prompt 2b target ✓ |
| `/over-ons` | ✓ `app/over-ons/page.tsx` | 0.4 | `now` | |
| `/contact` | ✓ `app/contact/page.tsx` | 0.5 | `now` | |
| `/privacybeleid` | ✓ `app/privacybeleid/page.tsx` | 0.2 | `now` | Per prompt 2b target ✓ |
| `/gebruiksvoorwaarden` | ✓ `app/gebruiksvoorwaarden/page.tsx` | 0.2 | `now` | Per prompt 2b target ✓ |
| `/blog/woningwaarde-berekenen-2025` | ✓ data in `lib/blog-data.ts` | 0.7 | `now` | Per prompt 2b target ✓; Phase 2b wants `lastModified` from `post.date` |
| `/blog/ai-tools-voor-makelaars` | ✓ | 0.7 | `now` | Same |
| `/blog/woningbeschrijving-schrijven-tips` | ✓ | 0.7 | `now` | Same |
| `/blog/woz-waarde-vs-marktwaarde` | ✓ | 0.7 | `now` | Same |

**No 404s.** Every URL maps to a real route file.

**Other findings:**
- ~~`lastModified: now` for blog posts is incorrect — Phase 2b will fix to `post.date`.~~ **Fixed in Phase 2b 2026-04-27** — `app/sitemap.ts` now imports `blogPosts` directly and emits `lastModified: new Date(post.date)` per post.
- The platform-proxied paths (`/m/*`, `/preview/*`, `/chat/*`, `/assets/*`, `/~api/*`) are **not** in the sitemap — good. But because `next.config.ts` rewrites them silently, a crawler that discovers them through a backlink will index them under the marketing domain. They need an explicit `Disallow` in `robots.ts` (Phase 2a) or `noindex` HTTP header.
- No `/demo` entry yet — expected (Phase 4a will add it).
- No `/integraties` entry yet — currently 301-redirected to `/contact` via `next.config.ts:47` (Phase 4b will remove the redirect and ship the real page).
- Missing routes that Phase 4 may add: `/demo`, `/integraties`, `/kennisbank`. Plan for sitemap updates accordingly.

---

## 4. Internal-link inventory

### Blog → tool pages

| Blog post | Tool page linked | Anchor / mechanism |
|---|---|---|
| `woningwaarde-berekenen-2025` | `/tools/waardescan` | `relatedTool` callout block at end of post (`relatedToolCta` = "Bekijk Waardescan") via `app/blog/[slug]/page.tsx:138–151` |
| `ai-tools-voor-makelaars` | `/tools/huistekst` | same mechanism, anchor "Probeer Huistekst gratis" |
| `woningbeschrijving-schrijven-tips` | `/tools/huistekst` | same, anchor "Bekijk Huistekst" |
| `woz-waarde-vs-marktwaarde` | `/tools/waardescan` | same, anchor "Vraag een gratis Waardescan aan" |

In-body links from blog posts to tool pages or to other blog posts: **none**. Body content is plain text (`ContentBlock` types: `paragraph`, `heading2`, `heading3`, `list`, `callout`) — no `link` block type, so cross-references inside post body are not currently expressible.

### Tool pages → blog posts

| Tool page | Blog posts linked |
|---|---|
| `/tools/waardescan` | none |
| `/tools/huistekst` | none |
| `/tools/sfeerimpressie` | none |
| `/tools/object-assistent` | none |

### Other internal-link surfaces

- Navbar (`components/layout/Navbar.tsx`): `/tools/waardescan`, `/tools/object-assistent`, `/tools/huistekst`, `/tools/sfeerimpressie`, `/voor-makelaars`, `/blog` — present on every page.
- Footer (`components/layout/Footer.tsx`): same 4 tools, `/over-ons`, `/blog`, `/contact`, `/privacybeleid`, `/gebruiksvoorwaarden`.
- `/voor-makelaars` body (`app/voor-makelaars/page.tsx:128–134`) links to all 3 active tools via "Meer over <Tool>" anchors.
- Homepage `ToolsShowcase` (`components/sections/ToolsShowcase.tsx:35–71`) links to all 4 tool pages with descriptive anchors ("Bekijk Waardescan", etc.).
- `/not-found` links to `/` and `/tools/waardescan`.

**Phase 5a target:** every blog post should also link to ≥1 other relevant blog post; every tool page should host a "Verwante artikelen" block linking to 2–3 posts. Currently this is **0 links** in either direction. The blog `ContentBlock` type would need a new variant (e.g., `link` or rich text in `paragraph`) to support inline blog→blog links cleanly.

---

## 5. Cross-domain link inventory

Every link from this repo to `platform.woninganalyse.nl/*` (`Grep` of `tsx`/`ts` excluding `node_modules`):

| File:line | Target | Visible anchor / context | Verdict |
|---|---|---|---|
| `components/sections/Hero.tsx:240` | `/register` | "Probeer gratis" | OK — descriptive enough; Phase 5c may upgrade to "Probeer gratis met de Waardescan" |
| `components/sections/CTABanner.tsx:36` | `/register` | "Start gratis" | OK |
| `components/layout/Navbar.tsx:145` | bare `https://platform.woninganalyse.nl` (desktop) | "Inloggen" | **WEAK** — should be `/login` with anchor "Inloggen op uw dashboard" |
| `components/layout/Navbar.tsx:226` | bare `https://platform.woninganalyse.nl` (mobile) | "Inloggen →" | **WEAK** — same as above |
| `app/over-ons/page.tsx:70` | `/register` | "Start gratis" | OK |
| `app/voor-makelaars/page.tsx:75` | `/register` | "Gratis proberen" | OK |
| `app/tools/huistekst/page.tsx:60` | `/register` | "Probeer gratis" | OK |
| `app/tools/waardescan/page.tsx:57` | `/register` | "Start gratis" | OK; Phase 5c could upgrade to "Start gratis met de Waardescan" |
| `app/tools/object-assistent/page.tsx:118` | `/register` | "Start gratis" | OK |
| `app/tools/object-assistent/page.tsx:211` | `/register` | "Start gratis" (CTA at page bottom) | OK |

### Required-but-missing cross-domain links

The prompt requires `/register`, `/login`, `/demo` to be linkable.

- **`/register`** ✓ — 8 distinct CTAs across the site.
- **`/login`** ✗ — never linked directly. Navbar's "Inloggen" goes to bare `platform.woninganalyse.nl` (the platform's home). Should target `/login` with descriptive anchor.
- **`/demo`** ✓ (since Phase 4a, 2026-04-27) — `https://www.woninganalyse.nl/demo` shipped as a **sales-led demo intake page** (the live platform demo is not yet built; the user explicitly opted to skip building it). Form-driven, uses existing `sendContactForm` server action with an `intent: 'demo'` field. All five "Demo aanvragen" buttons (Navbar desktop + mobile, three tool pages — waardescan, huistekst, object-assistent) retargeted from `/contact` to `/demo`. The voor-makelaars `#demo-form` anchor stays unchanged (in-page form is intentional). Sfeerimpressie's waitlist form also stays unchanged (different intent — pre-launch sign-up). When the live demo on platform exists, the page can later add a "try the live tool" CTA without restructuring.

### Anchor-text quality

No "Klik hier" or "registreer" generic anchors present. The two Navbar "Inloggen" links to the platform root are the only weak spots. Fixable in Phase 5c.

### Link attributes

- `Hero.tsx`, `CTABanner.tsx`, Navbar links: use raw `<a>` with `target="_blank" rel="noopener noreferrer"`.
- Tool/page-level CTAs go through `Button` with `external` prop which (per import pattern) likely sets the same. Worth verifying in Phase 2 that all platform links use `rel="noopener"` consistently.

---

## 6. GA4 + cookie-consent state

**At audit time, GA4 did not fire.** No `G-DX6JXP0VKM`, `gtag`, `GoogleAnalytics`, or `next/script` reference existed in the repo. The Leadsy tag (`r2.leadsy.ai`) was also absent.

This contradicted the prompt's Hard Constraint #6 ("Don't break existing GA4") — **there was no existing GA4 to break** in this repo. Per `SEO-CONTEXT.md` §6 the GA4 tag was meant to live in the **platform** repo (`platform.woninganalyse.nl`'s `index.html`); user later confirmed that **Leadsy is not actually installed on the platform either** — both `SEO-CONTEXT.md` §6 #6 and `CLAUDE-CODE-SEO-PROMPT.md` Hard Constraint #6 are stale on this point.

**Phase 6c verified clean 2026-04-27** — grep across `**/*.{tsx,ts,jsx,js,html,mjs}` returns zero `<script async ...>` patterns. The only `next/script` usage is in `components/analytics/GoogleAnalytics.tsx` and both `<Script>` instances correctly use `strategy="afterInteractive"`. All other inline `<script type="application/ld+json">` blocks are JSON-LD (no strategy applies).

**Phase 2c shipped 2026-04-27 — GA4 install (Leadsy deferred):**
- New client component `components/analytics/GoogleAnalytics.tsx` loads gtag with `<Script strategy="afterInteractive">` only after consent.
- Consent gating is "instant on accept" (Decision 1: Option A): `CookieBanner.tsx` now dispatches a `cookie-consent-accepted` window event on Akkoord click; the GA4 component listens and starts tracking immediately for the rest of the session. Returning visitors who already accepted are picked up via `localStorage` on mount.
- Cross-domain linker configured for `woninganalyse.nl`, `www.woninganalyse.nl`, and `platform.woninganalyse.nl` so the `_ga` cookie carries across the brand. Platform-side change documented in `HANDOFF.md` §8.
- Leadsy / B2B visitor identification deferred entirely — see §9 "Deferred items" below.

**Cookie banner state:**

- `components/layout/CookieBanner.tsx` shows a one-button "Akkoord" banner that writes `localStorage['cookie-consent'] = 'accepted'`.
- It is implicit-consent style: there is no "Weigeren" / "Decline" button, and clicking the X-close behaves the same as Akkoord. Both buttons call the same `accept()` handler (lines 51 & 58).
- No granular categories (functional vs analytical vs marketing), and no event/observable is exposed for downstream code to subscribe to consent state. Phase 2c will need either:
  - Read `localStorage` directly when GA4 boots, **or**
  - Refactor the banner to fire a `'consent-accepted'` window event (preferable for SSR/CSR boundary safety).
- Dutch text mentions "functionele en analytische cookies" — fine for a single-bucket consent flow, but if marketing ever adds Leadsy/ad pixels, the banner copy will need updating.
- AVG/GDPR niceties absent: no link to revoke consent, no "Voorkeuren beheren" page. Acceptable for a v1 but worth noting.

**Linker config:** not configured (no GA4 to configure on yet).

**Cross-domain attribution risk:** until Phase 2c lands, every visit that lands on the marketing site and clicks through to `platform.woninganalyse.nl/register` shows up in the platform's GA4 as either "direct" or "(other)" — funnel analysis is impossible.

---

## 7. OG image audit

**Single shared OG image** for every page. Source: `app/opengraph-image.tsx` — Next.js's file-convention dynamic OG generator. It produces a 1200×630 image with a brand-blue gradient, a "W" badge, "Woninganalyse" wordmark, and the strapline "Slimme tools voor makelaars: leads, teksten en meer". Because the file lives at the app root and no per-route `opengraph-image.tsx` exists, **every single route gets the same image**.

| Page | OG image | Unique? |
|---|---|---|
| `/` | `app/opengraph-image.tsx` (root) | shared |
| `/voor-makelaars` | same | shared |
| `/tools/waardescan` | same | shared |
| `/tools/huistekst` | same | shared |
| `/tools/sfeerimpressie` | same | shared |
| `/tools/object-assistent` | same | shared |
| `/blog`, `/blog/[slug]` × 4 | same | shared |
| `/over-ons`, `/contact`, legal | same | shared |

**~~Phase 2e is required.~~ Phase 2e shipped 2026-04-27 — Option C (per-route `opengraph-image.tsx` via Next 16 file convention, no new dependency).** New: `lib/og.tsx` shared template (`buildOGImage` helper with brand/accent palette variants), plus per-route OG image generators at `app/tools/{waardescan,huistekst,sfeerimpressie,object-assistent}/opengraph-image.tsx` and a dynamic `app/blog/[slug]/opengraph-image.tsx` that pulls the post title and category from `lib/blog-data`. The existing root `app/opengraph-image.tsx` remains the fallback for `/voor-makelaars`, `/over-ons`, `/contact`, `/blog` (list page), and the legal pages — keeping these on the brand/tagline OG card was deliberate (low-share-volume routes).

**Other OG findings:**
- `lib/metadata.ts:4` defines `OG_IMAGE = '${BASE_URL}/og-image.png'` — referencing a static file that **does not exist** in `public/`. Helper isn't called anywhere, so no live impact, but the dead code is misleading and should be removed or rewritten in Phase 2.
- `app/page.tsx:29` `Organization.logo: 'https://woninganalyse.nl/og-image.png'` — same missing file. **This will return 404 in Schema validators and Google Rich Results.** Fix in Phase 2/3 (point at `/logo-color.png` or `/opengraph-image`).
- `public/og-image.svg` exists but is unreferenced. Probably leftover; safe to delete in Phase 2.
- Per-page `openGraph.url` fields are all bare-domain (consistent with `metadataBase`) — no `www.` mismatch in the codebase.
- `twitter.images` is not set per-page (root `twitter.card = summary_large_image` will pull from OG image automatically — fine for Next 16).

---

## 8. Lighthouse / Core Web Vitals notes

I have not run a local Lighthouse pass (would require `next dev` / `next build && next start` plus a headless Chrome run, both out of scope for read-only Phase 1). Visible perf risks from static analysis:

**LCP risks**
- `public/hero-bg.png` is 167 KB and rendered with `priority` + `quality={90}` at full-bleed in `components/sections/Hero.tsx:174`. This is the homepage LCP candidate. Should convert to `.webp` (or `.avif` with `.webp` fallback) — Phase 6a. Likely savings >40%.
- Logo files (`logo-color.png` 22 KB, `logo-white.png` 19 KB) — both PNG, both unoptimized. Less critical (rendered small in Navbar) but Phase 6a should sweep them.

**CLS risks**
- Navbar swaps logo image source on scroll (`Navbar.tsx:71`: `showSolid ? '/logo-color.png' : '/logo-white.png'`). Both images are 200×40 with `next/image` so dimensions are reserved — should not cause CLS. Worth a Lighthouse confirmation.
- Hero card animations (`framer-motion` y/x transforms) animate transform, not layout — no CLS impact.

**FCP / TBT risks**
- DM Sans loads 6 weights (`300,400,500,600,700,800`) in `app/layout.tsx:9`. Weight 300 **is** used in `components/sections/Testimonials.tsx:77` (`font-[300]`) — but `Testimonials` is **not imported anywhere** in the live route tree (verified via grep). It's dead code. So weight 300 is unused on production routes. Phase 6b can drop it once `Testimonials.tsx` is confirmed dead and removed. Same applies to `StatsBalk.tsx` — defined but not imported.
- No third-party scripts currently → no script blocking. (Will change in Phase 2c when GA4 lands.)
- `motion/react` (Framer Motion) is used heavily on the homepage Hero, ToolsShowcase, SocialProof, CTABanner. Every one of those is a `'use client'` component — full client-side hydration on the home route. The trade-off is established; not changing visuals.

**Indexability**
- No `next/image` `remotePatterns` in `next.config.ts` (no external images used currently — fine).
- No `compress: true` set explicitly — default in Next is `true`. OK.
- No `images.formats` override — Next 16 defaults to `image/webp`. Phase 6d may also enable `image/avif`.

**Accessibility (SEO-adjacent)** — full audit pass shipped in Phase 2f (2026-04-27)
- Skip-to-content link present (`app/layout.tsx:48`).
- **H1 count: clean.** Every route has exactly one `<h1>`. Homepage's lives in `Hero.tsx` (rendered as `motion.h1` for the entry animation; semantically still an h1). Verified by grep across `app/**/page.tsx` and section components.
- **Heading hierarchy: two minor non-blocking issues, flagged not fixed.** Fixing requires a visual change which Phase 2f forbids.
  - `components/sections/ToolsShowcase.tsx`: each tool block's heading is `<h2>` and sits as a sibling of the section heading (also `<h2>`). Could be `<h3>` for tighter nesting under the section h2. Visual size is identical (both use `text-display-2`); changing would alter the heading-outline a screen reader announces but not the rendered look.
  - `app/tools/huistekst/page.tsx` and `app/tools/object-assistent/page.tsx`: the "Features" sections render `<h3>` cards without an enclosing `<h2>` heading. Cards read as continuation of the previous section's h2. Minor — could be addressed by adding a hidden section heading or restructuring.
- **`aria-hidden` sweep:** 8 missed icons fixed in Phase 2f — `CookieBanner` X-button, Navbar dropdown chevron + mobile menu toggle (X/Menu), Footer LinkedIn + Twitter icons, ContactForm success checkmark, HuistekstMockup copy/check icons. All these icons sit inside elements with their own accessible name (button `aria-label` or anchor `aria-label`), so adding `aria-hidden` keeps screen readers from double-announcing.
- All inline `<svg>` elements (12 in total, mostly in mockup components) already had `aria-hidden="true"`. No changes needed there.
- Forms have `<label htmlFor>` pairs and `autoComplete` hints (e.g., `app/contact/ContactForm.tsx:67–80`).

**Crawl-quality risks**
- `next.config.ts` rewrites `/m/*`, `/preview/*`, `/chat/*` etc. into `platform.woninganalyse.nl` transparently. The crawl-quality risk is real but the response is **not** a blanket disallow — see Open Question 3 (resolved). Phase 2a adds `/preview/` to the disallow list. `/m/` is intentionally allowed (marketing is the canonical for those URLs). `/chat/` is platform's `noindex` responsibility. The remaining rewrites are render-time dependencies and stay allowed.

---

## 9. Open questions (block Phase 2)

1. **Canonical host: bare or `www`?** ~~Hard Constraint #4 says `https://woninganalyse.nl` (bare) is canonical and the codebase agrees…~~ **Resolved 2026-04-27:** user confirmed that typing `woninganalyse.nl` in the browser redirects to `www.woninganalyse.nl`, so **`www.` is the live canonical**. The codebase had been emitting bare-domain canonicals everywhere — every page, the sitemap, and `metadataBase`. Fixed in the same session: `https://woninganalyse.nl` → `https://www.woninganalyse.nl` across 16 files (`app/layout.tsx`, `app/page.tsx`, `app/sitemap.ts`, `app/robots.ts`, `app/blog/page.tsx`, `app/blog/[slug]/page.tsx`, `app/contact/page.tsx`, `app/over-ons/page.tsx`, `app/voor-makelaars/page.tsx`, `app/privacybeleid/page.tsx`, `app/gebruiksvoorwaarden/page.tsx`, all four `app/tools/*/page.tsx`, and the dead helper `lib/metadata.ts`). `platform.woninganalyse.nl` cross-domain links untouched. Type-check clean. `SEO-CONTEXT.md` §2 was correct on this point; Hard Constraint #4 in the prompt was stale.
2. **`hoeveelismijnhuiswaard.net` legacy domain status** (`SEO-CONTEXT.md` §10 Q1). **Resolved 2026-04-27:** verified live (HTTP 200, brand "WoningWaarde", title "Wat is mijn huis waard? Slimme AI woning analyse", self-canonical). User confirmed it is a **deliberately separate B2C brand** — not legacy, not to be sunset. Therefore this marketing repo (`woninganalyse.nl`) targets **B2B only** going forward. Implications: (a) **drop the two B2C blog posts** from Phase 4c proposals ("WOZ-waarde vs marktwaarde", "Wat is mijn huis waard in 2026?") to avoid cross-brand keyword cannibalization — keep the four B2B ones; (b) existing B2C-leaning posts (`/blog/woz-waarde-vs-marktwaarde`, `/blog/woningwaarde-berekenen-2025`) cannot be edited per prompt §8, so they stay as-is — flag them in `HANDOFF.md` Phase 7 as a known cross-brand overlap; (c) Phase 4c content should focus exclusively on B2B keywords from `SEO-CONTEXT.md` §3 (NVM/VBO tools, leadgeneratie, white-label woningwaarde, AI tools voor makelaars, etc.).
3. **`/m/:slug` canonical strategy** (`SEO-CONTEXT.md` §10 Q2). **Resolved 2026-04-27, with strategic reversal:** user prefers **marketing as canonical** for `/m/{slug}` (i.e., `https://www.woninganalyse.nl/m/{slug}`), opposite of `SEO-CONTEXT.md` §2's recommendation. Brand authority should live on the consumer-facing brand domain, not on the technical subdomain. Implications: (a) **Phase 2a `robots.ts` adds `/preview/` only** (alongside the existing `/api/`); `/m/` stays allowed (canonical reversal needs Google to crawl), `/assets/`, `/~api/`, `/~flock.js` stay allowed (render-time deps for the `/m/` HTML), `/chat/` is platform's `noindex` responsibility (documented in `HANDOFF.md`); (b) marketing's sitemap will eventually include `/m/{slug}` URLs (needs a public slug feed from platform — flagged in `HANDOFF.md`); (c) **platform-side change required** — platform's per-page `<link rel="canonical">` and `og:url` for `/m/{slug}` must point at `https://www.woninganalyse.nl/m/{slug}`, not at platform itself. Captured in `HANDOFF.md` §2. Hard Constraint #3 ("don't introduce duplicate content with platform's `/m/:slug`") still holds — the canonical reversal is what *prevents* duplicate-content treatment, by telling Google the marketing URL is the single source. While we wait for platform-side changes the duplicate state persists; the flag in `HANDOFF.md` is the action.
4. **Lead Management as a 5th tool page?** `SEO-CONTEXT.md` §1 lists 5 products; marketing surfaces 4. Adding `/tools/lead-management` would close that gap and capture searches like "leadbeheer voor makelaars" / "CRM makelaar". Out of Phase 1 scope — flagging for Phase 4 prioritisation.
5. **Twitter handle (Footer)** — Hard Constraint and Phase 2g both say "Remove `twitter:site` from `app/layout.tsx`". `twitter:site` is **already absent** (only `twitter.card` is set). However, `components/layout/Footer.tsx:57` links to `https://twitter.com/DTverweij` (a personal handle, not a brand handle). Should this stay, be replaced with a Woninganalyse brand handle once one exists, or be removed? Visual change so deferring to Phase 5d / your call.
6. **B2B blog cadence and authorship signals** (`SEO-CONTEXT.md` §10 Q5). The blog exists with 4 posts and the data structure supports more. Phase 4c will propose 4 B2B + 2 B2C titles per the prompt. Confirm whether you want author bylines surfaced (currently `BlogPosting.author = { @type: Organization, name: 'Woninganalyse' }`). If a real human author should be credited, we need an `Author` `Person` schema and a real name. Default: keep it as Organization-only for now.
7. **Trust-anchor coverage** — `SEO-CONTEXT.md` §4 lists six anchors (Kadaster · CBS · WOZ · BAG · AVG-conform · NVM/VBO). Marketing surfaces three of those on `/` (Kadaster, CBS, NVM/VBO). Should Phase 5e add WOZ, BAG, AVG-conform inline mentions on `/voor-makelaars` and `/tools/waardescan`? Per Hard Constraint #1 the homepage cannot change visually, so these would be added on non-home pages only.
8. **`aggregateRating` on marketing** (`SEO-CONTEXT.md` §10 Q3) — not present here, Hard Constraint #2 protects this. No action; flagging for Phase 7 `HANDOFF.md`.
9. **Per-route SSR / prerender for platform `/m/:slug`** (`SEO-CONTEXT.md` §10 Q4) — entirely a platform-repo concern. Will reference in Phase 7 only.
10. **`next/script` strategy choice** for GA4 (Phase 2c). Prompt says `afterInteractive`. Confirmed and shipped.

---

## 10. Phase 6e — Lighthouse audit

**Local baseline shipped 2026-04-28.** Production re-run is still required post-deploy (runbook below); local scores typically run 5–10 points lower than the live CDN-served site.

### Methodology

Audit ran against `next build && next start` on `localhost:3000` from the tip of `claude/access-seo-prompts-wzt6W`. Chrome 147 (`@puppeteer/browsers install chrome`), Lighthouse 13.1.0, headless mode, default mobile emulation profile, default Slow 4G throttling. Five URLs scored across all four categories. Score targets per the original prompt: Performance ≥ 90, SEO = 100, Accessibility ≥ 95, Best Practices ≥ 95.

### Local baseline scores

| Page | Perf | A11y | BP | SEO | LCP | TBT | CLS |
|---|---:|---:|---:|---:|---:|---:|---:|
| `/` | 91 | 96 | 100 | 100 | 3.35s | 136ms | 0.000 |
| `/voor-makelaars` | 97 | 97 | 100 | 100 | 2.47s | 90ms | 0.000 |
| `/tools/waardescan` | 96 | 96 | 100 | 100 | 2.76s | 48ms | 0.000 |
| `/blog` | 98 | 96 | 100 | 100 | 2.22s | 78ms | 0.000 |
| `/blog/leads-genereren-woningwaarde-tool` | 97 | 96 | 100 | 100 | 2.65s | 62ms | 0.000 |

**All five routes meet all four targets locally.** Headroom is comfortable on every route except home Performance (91 vs ≥90 target — 1-point margin). CLS is 0.000 across the board, which validates the Phase 6a image-dimension reservations and the Navbar logo-swap analysis in §8. No third-party scripts fired (GA4 is consent-gated and the run did not interact with the cookie banner).

### Diagnostics

**Home Performance is the closest call.** LCP 3.35s is the dominant signal. The Lighthouse `largest-contentful-paint-element` audit returned no element snippet (typical when the LCP candidate is composited via a CSS background or animated in via Framer Motion before paint settles), so the LCP timing reflects Hero entrance choreography rather than a single oversized asset. The hero-bg.png → WebP+AVIF migration shipped in Phase 6d has already done the obvious image win; further headroom would require deferring or simplifying the `motion/react` Hero entrance, which is a visual change the prompt forbids on `/`. Production CDN caching alone is expected to clear the 90 threshold by 5+ points.

**Top opportunities (non-blocking, all routes):**
- `unused-javascript`: 48–98 KiB across pages, ~150–300ms savings. Mostly Framer Motion + Radix Accordion bundles loaded eagerly because of `'use client'` boundaries on `Hero`, `ToolsShowcase`, `SocialProof`, `CTABanner`. Code-splitting these would help but requires touching the visual choreography — out of current scope.
- `server-response-time`: 7–14ms on every route. This is localhost noise — production behind Vercel's edge will be lower or equivalent.

**Accessibility is 96–97 everywhere, not 100.** Two findings, both real and fixable, neither breaches the ≥95 target:

1. **`color-contrast` on `--fg-subtle` token.** Defined as `#8B8FA3` at `app/globals.css:26`. Lighthouse reports contrast 2.83 vs `#eff1f7` card backgrounds and 3.20 vs `#ffffff` — both below the WCAG AA 4.5:1 threshold for body-size text. Hits every page where tertiary text appears (timestamps, micro-labels, small captions, blog meta lines). Fix: darken the token to ~`#6E7287` or darker — that lifts contrast to ≥4.5:1 on both background variants. One-line CSS change, high a11y leverage. Visual change is small (slightly darker grey on caption text) but non-zero, so flagging rather than shipping in this branch.
2. **`label-content-name-mismatch` on blog "Lees verder" links.** `app/blog/page.tsx` and the related-posts widget render anchor tags like `<a aria-label="Lees: <post title>">Lees verder →</a>`. WCAG SC 2.5.3 requires the visible text to be a substring of the accessible name — "Lees verder" is not contained in "Lees: <title>". Two clean fixes: (a) drop the `aria-label` entirely (the surrounding card already names the post via the heading), or (b) prefix the aria-label with the visible text: `aria-label="Lees verder: <title>"`. Option (b) preserves the per-link descriptive announcement for screen-reader users navigating by link list.

**Best Practices = 100** on every page — no console errors, no deprecated APIs, no insecure requests. **SEO = 100** confirms the canonical-host fix, JSON-LD coverage, robots/sitemap, and metadata polish all landed correctly.

### Production runbook (to execute post-deploy)

```bash
# 1. Install Chrome (one-time, host machine)
npx --yes puppeteer browsers install chrome
export CHROME_PATH="$(find ~/.cache/puppeteer/chrome -name chrome -type f | head -1)"

# 2. Audit each URL against the deployed www.woninganalyse.nl
mkdir -p lighthouse-prod
for path in "/" "/voor-makelaars" "/tools/waardescan" "/blog" "/blog/leads-genereren-woningwaarde-tool"; do
  name=$(echo "$path" | tr / - | sed 's/^-//;s/-$//;s/^$/home/')
  npx --yes lighthouse "https://www.woninganalyse.nl${path}" \
    --chrome-flags="--headless --no-sandbox --disable-gpu --disable-dev-shm-usage" \
    --output=json --output=html \
    --output-path="lighthouse-prod/${name}" \
    --only-categories=performance,accessibility,best-practices,seo \
    --quiet
done
```

Paste the resulting score table into a "Production scores" sub-section under this one. If any route misses a target, cross-check against the diagnostic list above — the local baseline already covers the likely culprits, so a prod miss usually points at a deploy-time regression (CDN miss, font-preload race, GA4 firing earlier than expected) rather than a code issue.

### Remediation candidates

- **Token darken (visual)** — `--fg-subtle` `#8B8FA3` → ~`#6E7287` in `app/globals.css:26`. Lifts a11y from 96 → 100 on every page. **Deferred to the end-of-project visual pass as item V1** (see "Visual changes deferred" section below).
- **`aria-label` fix (non-visual)** — **Shipped 2026-04-28 (Phase 6f).** Three offenders fixed in `app/blog/page.tsx` (featured card + grid card "Lees meer" links) and `components/blog/RelatedArticles.tsx` (related-posts "Lees meer" links). Featured card uses option (a) — drop the `aria-label` so the accessible name comes from the visible card content (badge + h2 + description + meta + "Lees artikel" CTA), which is what a sighted reader actually parses. The two small "Lees meer" links use option (b) — `aria-label="Lees meer: <title>"` so the visible "Lees meer" text is contained in the accessible name (WCAG SC 2.5.3). See verification sub-section below.

### Phase 6f local verification (2026-04-28)

Re-ran the same Lighthouse harness from the Methodology section above against the post-fix build. `label-content-name-mismatch` now PASSES on all three previously-failing pages; the rule was n/a on `/` and `/voor-makelaars` and remains so. Category scores:

| Page | Perf | A11y | BP | SEO | label-mismatch | color-contrast |
|---|---:|---:|---:|---:|:-:|:-:|
| `/` | 93 | 96 | 100 | 100 | n/a | FAIL (10) |
| `/voor-makelaars` | 97 | 97 | 100 | 100 | n/a | FAIL (11) |
| `/tools/waardescan` | 97 | 96 | 100 | 100 | **PASS** | FAIL (19) |
| `/blog` | 99 | 96 | 100 | 100 | **PASS** | FAIL (24) |
| `/blog/leads-genereren-woningwaarde-tool` | 97 | 96 | 100 | 100 | **PASS** | FAIL (11) |

All four targets still met on every route. A11y category score did not move because `color-contrast` (deferred as V1 in the visual pass) is the remaining ceiling — fixing it lifts every page to A11y 100. Performance numbers shifted ±2 points on `/` and `/blog` between runs, which is within the normal local-Lighthouse noise band; the trend on every route is at-or-above the prior baseline. CLS and BP unchanged.

---

## Remaining work (open after this branch)

- **Phase 6e production re-run.** Local baseline is in §10 above. The post-deploy production run against `https://www.woninganalyse.nl` has not happened yet — the runbook in §10 is the exact sequence; results paste under §10 as a "Production scores" sub-section.

- **Phase 7 round-out.** `HANDOFF.md` ships an initial cut covering the canonical reversal for `/m/{slug}`, the `hoeveelismijnhuiswaard.net` cleanup, GA4 linker config, sitemap responsibility split, and the platform-side §6 issues from `SEO-CONTEXT.md`. To make it a fully formal Phase 7 deliverable per the prompt: (a) propose an explicit `https://www.woninganalyse.nl/sitemap-index.xml` referencing both the marketing and platform sitemaps with pros/cons, (b) map 1:1 to `SEO-CONTEXT.md` §10's open questions with our chosen direction per question, (c) lock down a single canonical OG image URL agreement (currently both repos generate OG dynamically — fine, but should be documented).

- **Open items from `seo-audit.md` §9 not yet answered.** Twitter handle ownership (currently no `twitter:site` metadata; Footer points at `@DTverweij` personal handle). Lead Management as a possible 5th tool surface (`SEO-CONTEXT.md` §1 lists it; marketing currently treats it as a feature embedded in other tools). Whether to revisit Phase 4d `/kennisbank` before the 12-post / 3-per-category threshold.

- **Phase 4c follow-up content.** Four B2B blog posts shipped. Categories with 1 post (Leadgeneratie, Makelaarsbranche, Copywriting) thin out the auto-related-posts algorithm — adding 1–2 more posts per thin category would tighten the topical-cluster effect.

- **Visual changes pass — see "Visual changes deferred" section below.** All visual changes flagged across the project are batched into a single end-of-project review/pass so they can be evaluated together rather than sprinkled across SEO branches.

---

## Visual changes — pass status

V1, V2, V3, V4, V5, V8, V9 shipped on the `claude/seo-visual` branch (2026-04-28). V6 and V7 killed — moved to "Deferred items (intentional non-scope)" below; not shipping a whole new tool page or topical-hub during an SEO project. **A11y now 100 on every audited route** — the visual pass is complete.

| # | Change | File / location | Visual delta | Why shipped | Status |
|---|---|---|---|---|---|
| V1 | Darken `--fg-subtle` token: `#8B8FA3` → `#65697E` | `app/globals.css:26` | Caption / meta / micro-label text becomes a noticeably darker grey across every page (hero stats, tool mockups, blog meta, footer micro-copy). 85 usages of the token across the codebase | Lifts WCAG contrast 2.83/3.20 → ≥4.80:1 against all three light backgrounds (`#FFFFFF`, `#EFF1F7` muted, `#F6F7FB` page). `#65697E` is the lightest shade that hits 4.5:1 on the worst-case `#EFF1F7` background — minimum-delta choice | **Shipped** |
| V2 | Footer Twitter handle | `components/layout/Footer.tsx:57` (removed) | The `@DTverweij` personal Twitter link is gone from the footer social row; only the LinkedIn icon remains. `Twitter` import dropped from `lucide-react`. No `twitter:site` metadata existed elsewhere — clean removal | Personal handle on a brand site is a credibility signal mismatch. No brand Twitter exists today; rather than fabricate one or wait, removed entirely. Re-add only if/when a brand handle is created | **Shipped** |
| V3 | Trust-anchor coverage on `/voor-makelaars` and `/tools/waardescan` | `app/voor-makelaars/page.tsx` (already had all 6 from earlier phase), `app/tools/waardescan/page.tsx` (added) | Single new `<p>` line in the waardescan hero: *"Gebouwd op Kadaster · CBS · WOZ · BAG · AVG-conform · NVM/VBO"* matching the pattern on `/voor-makelaars:101` | Tightens trust signals on the two highest-intent commercial routes (cannot go on home — Hard Constraint #1). BAG was previously only mentioned inline in the Kadaster card description; promoting to the trust line makes it a first-class anchor | **Shipped** |
| V4 | ToolsShowcase per-tool heading `h2` → `h3` | `components/sections/ToolsShowcase.tsx:103` | **Zero pixels** — both tags rendered with `text-display-2` so size/weight/spacing unchanged. Screen readers now announce the four tools as `h3` siblings under the section's `h2` instead of as four sibling `h2` elements competing with the section heading | Cleaner heading outline for screen-reader users; minor SEO win (clearer document outline) | **Shipped** |
| V5 | sr-only `<h2>` headings on huistekst / object-assistent Features sections | `app/tools/huistekst/page.tsx`, `app/tools/object-assistent/page.tsx` | **Zero pixels** — `sr-only` Tailwind utility hides them visually but exposes them to assistive tech | Both Features `<section>` elements declared `aria-labelledby="…-features"` but had **no element matching that id** — a real a11y bug. Fix adds the missing `<h2>` so screen readers can name the section | **Shipped** |
| V8 | Accent-orange labels: `text-[var(--accent)]` / `text-orange-500` → `text-orange-700` on `bg-orange-50` surfaces | `components/ui/Badge.tsx:9` (accent variant), `app/tools/sfeerimpressie/page.tsx:116` ("Binnenkort" pill), `components/layout/Navbar.tsx:114,199` ("Binnenkort" pills in dropdown + mobile menu) | Four small accent-coloured pills shift from bright `#FF6B35` text to a darker burnt-orange `#c2410c`. Visible on `/tools/object-assistent`, `/tools/sfeerimpressie`, the Navbar Sfeerimpressie dropdown entry, and the mobile menu | Lifts contrast on these pills from 2.67 → 4.88:1. Did **not** touch the global `--accent` token (still `#FF6B35`) — only the text colour inside the small badge / pill surfaces, scoped per the user's "changing the accent in the badge is fine" guidance | **Shipped** |
| V9 | White text on accent CTA buttons | `app/tools/sfeerimpressie/page.tsx:145,237` (two waitlist submit buttons), `components/sections/ToolsShowcase.tsx:118` (homepage accent CTA branch — Object Assistent block) | Three CTA-button surfaces shift from `bg-[var(--accent)]` (`#FF6B35`) to `bg-orange-700` (`#c2410c`); hover from `--accent-dark`/`#d97706` to `bg-orange-800` (`#9a3412`). White text contrast lifts from 2.83:1 → 5.18:1 (resting) and 7.31:1 (hover). The global `--accent` token is unchanged — fix is per-button override per option (c). Decorative mockup surfaces (chat bubbles, illustration squares) untouched (not flagged by Lighthouse and not interactive) | **Shipped** |

### Verification (visual pass, 2026-04-28)

Local Lighthouse re-run from §10 Methodology harness against the post-pass build. Eight routes audited (the five originally-required plus the three additional pages touched by V5 and V8).

| Page | Perf | A11y | BP | SEO | color-contrast |
|---|---:|---:|---:|---:|:-:|
| `/` | 93 | **100** | 100 | 100 | PASS |
| `/voor-makelaars` | 97 | **100** | 100 | 100 | PASS |
| `/tools/waardescan` | 97 | **100** | 100 | 100 | PASS |
| `/blog` | 100 | **100** | 100 | 100 | PASS |
| `/blog/leads-genereren-woningwaarde-tool` | 100 | **100** | 100 | 100 | PASS |
| `/tools/huistekst` | 96 | **100** | 100 | 100 | PASS |
| `/tools/object-assistent` | 97 | **100** | 100 | 100 | PASS |
| `/tools/sfeerimpressie` | 98 | **100** | 100 | 100 | PASS |

Home Performance ran 81 on the multi-page sweep but re-ran 92/94/93 in three back-to-back single-page audits — confirmed local CPU-contention noise rather than a regression. CLS is 0 across every page; V4's tag rename and V5's sr-only insertions caused no layout shift, as expected.

---

## Deferred items (intentional non-scope, future consideration)

- **B2B visitor identification (Leadsy / RB2B / Leadfeeder / Albacross / Dealfront / Clearbit Reveal).** Decision 2026-04-27: not installed in this SEO project. Original prompt and `SEO-CONTEXT.md` both treated Leadsy as already running on the platform; user confirmed neither repo actually has it. Adopting any visitor-ID vendor inside an SEO-tightening project would muddle two independent decisions (technical SEO vs. sales tooling). Land GA4 cleanly first; revisit if the marketing site shows enough B2B traffic to justify the spend or to make a free tier (RB2B's ~100 identifications/mo) worth the integration. The `GoogleAnalytics.tsx` component carries an inline note pointing here so the next dev who wonders "why isn't there a visitor-ID tag?" lands on this entry.

- **Phase 4d / V7 — `/kennisbank` topical-hub index page.** Decision 2026-04-27 (revisited and confirmed 2026-04-28 during the visual pass): **skipped for this SEO project, full stop.** The prompt's 4d gated this on "8+ blog posts"; with the four Phase-4c posts shipped we have exactly 8, but spread across 5 categories where three categories carry only 1 post each. A hub page is most effective when each category has 3+ posts so the page itself has real depth. Right now it would largely duplicate `/blog` with extra structure — modest SEO upside vs. real maintenance cost and a cannibalisation risk where Google might pick the wrong page as canonical for the cluster. **Adding a topical-hub page during an SEO-tightening project is also out of scope** — new pages belong in their own initiative once the content depth justifies them.

- **V6 — `/tools/lead-management` 5th tool page.** Decision 2026-04-28: **skipped for this SEO project, full stop.** `SEO-CONTEXT.md` §1 lists 5 products and marketing currently surfaces 4 — Lead Management is treated as a feature embedded in the other tools (lead-email mockup on `/tools/waardescan`, dashboard mention) rather than a separate page. Building out a full tool page would require copy, design, screenshot/mockup, JSON-LD `SoftwareApplication`, OG image, sitemap entry, navigation entry — an entirely new product surface. **That work does not belong in an SEO project**, which is about tightening signals on existing surfaces, not adding new ones. Revisit only if/when product decides to position Lead Management as a standalone product.

- **Phase 4b — `/integraties` page.** Decision 2026-04-27: **skipped entirely**. The original prompt's 4b assumed Funda / Realworks / Kolibri integrations existed and just needed a landing page. User confirmed there are **no current integrations** beyond the script-tag widget that runs on any HTML/JS-capable site, and there's no commitment to building specific CRM/Funda integrations. Shipping a page that lists "Realworks integratie" / "Kolibri koppeling" as a feature would mislead visitors and risk a credibility hit when sales has to backtrack. The existing FAQ wording on the homepage and `/tools/waardescan` ("Widgets en technische koppelingen zijn in veel gevallen mogelijk — neem contact op voor maatwerk") already handles the question honestly. The `/integraties → /contact` 301 redirect in `next.config.ts:47` stays in place so any existing backlink lands somewhere useful. Revisit only if/when actual integrations ship.

---

## Phase 1 summary

### What changed
- `seo-audit.md` (new): this audit, no code touched.

### What I did NOT change (and why)
- Every file under `app/`, `components/`, `lib/`, `public/`, `next.config.ts`, `app/sitemap.ts`, `app/robots.ts`. Phase 1 is read-only per the prompt's "Stop after Phase 1. Do not edit code yet."

### Verification
- File reads: `app/layout.tsx`, `app/page.tsx`, `app/sitemap.ts`, `app/robots.ts`, all four `app/tools/*/page.tsx`, both `app/blog/*` files, all six `components/sections/*` and three `components/layout/*` referenced, `lib/blog-data.ts`, `lib/metadata.ts`, `next.config.ts`, `vercel.json`, `app/opengraph-image.tsx`, `app/icon.tsx`, `app/apple-icon.tsx`, `app/globals.css`, `package.json`, `app/actions/contact.ts`, `app/contact/ContactForm.tsx`, `app/over-ons/page.tsx`, `app/voor-makelaars/page.tsx`, `app/privacybeleid/page.tsx`, `app/gebruiksvoorwaarden/page.tsx`, `app/not-found.tsx`, `public/og-image.svg`, plus directory listings and grep sweeps for cross-domain links, GA4 references, OG image references, Twitter references, font weight usage.
- No build / Lighthouse run yet (deferred to Phase 6e).

### Open questions for you
- See §9. Q1 (canonical host bare vs `www`) and Q3 (disallow `/m/`, `/preview/`, `/chat/` in `robots.ts`) are blocking for Phase 2a/2d.

### Proposed next phase
- **Phase 2 — Foundational technical SEO.** Touches `app/robots.ts`, `app/sitemap.ts`, GA4 wiring (new `<Script>` component + consent gating), `metadataBase` confirmation, OG-image strategy choice, `twitter.site` (already absent — confirm and document), and an a11y/landmark verification pass. Largest single surface is Phase 2c (GA4 + linker + Leadsy + consent).
