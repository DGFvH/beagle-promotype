# Hand-off — platform-repo changes required by the marketing-repo SEO project

**Audience:** maintainer of the `platform.woninganalyse.nl` repo (the React/Vite app).
**Source repo:** `woninganalyse.nl` marketing site (Next.js 16). See `seo-audit.md` and `CLAUDE-CODE-SEO-PROMPT.md` in that repo for the full SEO project context.
**Status:** Living document. This first version captures the two decisions made during Phase 1 of the SEO project. The full Phase 7 hand-off (per the marketing prompt) will extend it.

---

## 1. Strategic context

Three properties share the brand space:

| Domain | Role |
|---|---|
| `www.woninganalyse.nl` | Marketing / B2B explainer (Next.js, separate repo) |
| `platform.woninganalyse.nl` | The actual app (this repo) |
| `hoeveelismijnhuiswaard.net` | Separate B2C brand "WoningWaarde" — out of scope for both repos |

Two strategic decisions taken during the marketing-repo SEO project that this repo needs to act on:

1. **`www.woninganalyse.nl/m/{slug}` is canonical, not `platform.woninganalyse.nl/m/{slug}`.** Reverses the recommendation in `SEO-CONTEXT.md` §2. Reasoning: brand authority should live on the consumer-facing brand domain (`www.woninganalyse.nl`), not on the technical/platform subdomain. The platform serves the HTML via a rewrite from marketing, so the content is identical at both URLs — we want Google to credit marketing.
2. **All `hoeveelismijnhuiswaard.net` canonical/OG/sitemap references on this repo are stale and must be removed.** That domain is a separate B2C brand; this repo should not signal that platform content lives there.

---

## 2. CRITICAL — reverse the `/m/{slug}` canonical

### What needs to change

Wherever this repo emits the per-page `<link rel="canonical">` and OG metadata for `/m/{slug}` pages — likely in `src/pages/MakelaarPage.tsx` (`SEO-CONTEXT.md` §8 cites the `<Helmet>` block at lines 111–117) — the canonical and `og:url` must point at the **marketing** URL, not at platform itself:

```html
<!-- WAS -->
<link rel="canonical" href="https://platform.woninganalyse.nl/m/janssen-makelaars" />
<meta property="og:url"   content="https://platform.woninganalyse.nl/m/janssen-makelaars" />

<!-- SHOULD BE -->
<link rel="canonical" href="https://www.woninganalyse.nl/m/janssen-makelaars" />
<meta property="og:url"   content="https://www.woninganalyse.nl/m/janssen-makelaars" />
```

The slug is the same on both domains (because of the marketing-side rewrite); just swap the host.

### Why this works

The marketing repo (`next.config.ts`) rewrites `woninganalyse.nl/m/:path*` to `platform.woninganalyse.nl/m/:path*` — a server-side proxy, transparent to crawlers. So both URLs serve the **same HTML**. Whatever canonical tag this repo emits is what Google sees at **both** URLs. Pointing it at marketing tells Google "regardless of which URL you crawled, treat marketing's URL as the source." Google de-dupes the platform URL.

### Don't do

- Don't add `noindex` to `/m/{slug}` pages — Google must be allowed to crawl them so it can read the canonical.
- Don't keep platform's `/m/{slug}` in this repo's sitemap (see §3 below).
- Don't change the slug structure or the URL shape — marketing's rewrite assumes `/m/:path*` maps 1:1.

### Verification once shipped

- `curl https://platform.woninganalyse.nl/m/{any-slug}` → response HTML contains `<link rel="canonical" href="https://www.woninganalyse.nl/m/{any-slug}" />`.
- Schema.org / Google Rich Results Test on `https://www.woninganalyse.nl/m/{any-slug}` → no canonical-mismatch warning.
- 4–6 weeks after rollout, Search Console "URL Inspection" on a sample marketing `/m/...` URL should report it as the canonical, with the platform URL marked as a duplicate.

---

## 3. CRITICAL — remove all `hoeveelismijnhuiswaard.net` references

Per `SEO-CONTEXT.md` §6 #1, this repo's `index.html` (and `public/robots.txt`, `public/sitemap.xml`, `public/og-image.png` reference) still treats `hoeveelismijnhuiswaard.net` as the canonical host. That is wrong — that domain is a separate live B2C brand that must not absorb authority from this repo's pages.

### Replace, file by file

| Location | Current | Change to |
|---|---|---|
| `index.html` `<link rel="canonical" href="...">` (page-level fallback) | `https://hoeveelismijnhuiswaard.net/` | `https://platform.woninganalyse.nl/` (the homepage of the app), or remove if every route uses per-page Helmet canonicals |
| `index.html` `<meta property="og:url">` | same legacy | per-route, but never the legacy host |
| `index.html` `<meta property="og:image">` | absolute URL on legacy host | absolute URL on **`https://www.woninganalyse.nl/...`** (one canonical OG image hosted by marketing — see §4 below for which file) |
| `index.html` `<meta name="twitter:url">` / `twitter:image` | legacy | same as above |
| `public/robots.txt` `Sitemap:` directive | `https://hoeveelismijnhuiswaard.net/sitemap.xml` | `https://platform.woninganalyse.nl/sitemap.xml` |
| `public/sitemap.xml` `<loc>` entries | legacy host | `https://platform.woninganalyse.nl/...` (and trim non-existent routes — see §3.1 below) |
| Any inline JSON-LD `@id`, `url`, `mainEntity.url`, `provider.url`, `publisher.url`, `image` fields | legacy | `https://platform.woninganalyse.nl/...` |

After the sweep, `grep -rn "hoeveelismijnhuiswaard" .` in this repo should return zero matches.

### 3.1 — Trim the platform sitemap

Per `SEO-CONTEXT.md` §6 #2, `public/sitemap.xml` lists `/woningwaarde`, `/sfeerimpressie`, `/huistekst` — those routes don't exist in `src/App.tsx`. Remove them. The platform sitemap should list **only** real platform routes:

```
/                       (the React shell — low priority)
/login
/register
/demo
/m/{slug}               ← REMOVE: see §4 below
```

The `/m/{slug}` URLs do **not** belong in this repo's sitemap going forward (marketing claims them).

---

## 3.2 — `/integraties` does not exist on either repo

The marketing-side `/integraties` page was scoped in the SEO project's Phase 4b but **deliberately not shipped** — the platform has no specific Funda/Realworks/Kolibri integrations today, only the generic script-tag widget. Therefore: the platform sitemap and any internal references should also **not** mention `/integraties`. If a future "integrations exist now" decision is taken, both repos coordinate again. The marketing-side `/integraties → /contact` 301 redirect stays in place to catch any old backlinks.

---

## 4. Sitemap responsibility split

Once §2 lands, sitemaps should reflect who-canonicals-what:

| URL | Lives on (canonical) | Listed in sitemap of |
|---|---|---|
| `www.woninganalyse.nl/...` (homepage, tools, blog, voor-makelaars, etc.) | marketing | marketing |
| `www.woninganalyse.nl/m/{slug}` | marketing (canonical via this repo's HTML, per §2) | **marketing** (eventually — see below) |
| `platform.woninganalyse.nl/login`, `/register`, `/demo` | platform | platform |
| `platform.woninganalyse.nl/dashboard/*`, `/admin/*`, `/onboarding`, `/verify-email`, `/reset-password`, `/forgot-password` | platform | **none** (should be `noindex` + disallowed in `robots.txt`) |
| `platform.woninganalyse.nl/chat/{...}` | platform | **none** (likely `noindex`, deep-linked only) |
| `platform.woninganalyse.nl/preview/{...}` | platform | **none** (`noindex`, internal previews) |

### What this repo needs to do

- **Remove `/m/{slug}` URLs** from `public/sitemap.xml` (or the dynamic sitemap endpoint, if you have one). Marketing will own them.
- **Provide a public feed of active `/m/{slug}` slugs** so marketing can include them in its sitemap. Recommended:
  - JSON endpoint: `GET https://platform.woninganalyse.nl/~api/public/makelaar-slugs.json` returning `[{ "slug": "janssen-makelaars", "lastModified": "2026-04-12T08:00:00Z" }, ...]`.
  - Filter: only include agents with `hasWaardecheckAccess === true` (per `SEO-CONTEXT.md` §8 / `MakelaarPage.tsx:72`).
  - Cacheable (5–15 min).
  - Marketing fetches at build time (Next.js ISR) to populate its sitemap.
- **Keep `/m/` allowed in `public/robots.txt`.** Google must be able to crawl platform's `/m/{slug}` HTML to read the canonical → it will then drop the platform URL from the index in favour of marketing's. Disallowing here would prevent Google from seeing the canonical signal.

---

## 5. `robots.txt` for this repo (recommended state)

```
User-agent: *

Disallow: /dashboard/
Disallow: /admin/
Disallow: /onboarding
Disallow: /verify-email
Disallow: /reset-password
Disallow: /forgot-password
Disallow: /preview/
Disallow: /chat/         ← if you want chat noindex (recommended); skip if you want chat indexable

Allow: /
Allow: /login
Allow: /register
Allow: /demo
Allow: /m/

Sitemap: https://platform.woninganalyse.nl/sitemap.xml
```

Replace any `hoeveelismijnhuiswaard.net` references in the existing file (per §3).

For `/dashboard/*` and `/admin/*` it's also worth setting an `X-Robots-Tag: noindex, nofollow` HTTP header on the auth-gated routes — defence-in-depth.

---

## 6. `/demo` cross-link

Marketing will eventually ship a `/demo` **explainer** page at `https://www.woninganalyse.nl/demo` (B2B explainer copy, not the live tool). The interactive demo stays at `https://platform.woninganalyse.nl/demo`. Two pages, two distinct purposes.

What this repo needs to do:

- `https://platform.woninganalyse.nl/demo` should **self-canonical to itself** — it is the live tool, not a duplicate. Set:
  ```html
  <link rel="canonical" href="https://platform.woninganalyse.nl/demo" />
  ```
- Keep `/demo` allowed in `robots.txt` and in the platform sitemap.
- From the demo page, link back to `https://www.woninganalyse.nl/demo` with descriptive anchor text ("Lees meer over de demo voor makelaars" or similar) so users who hit the live tool can find the explainer.

(Marketing's `/demo` will canonical to itself and link out to `platform.woninganalyse.nl/demo` with a descriptive anchor.)

---

## 7. Other §6 cleanups (lower priority, not blocking)

These are flagged in `SEO-CONTEXT.md` §6. Schedule with whatever cadence; they aren't blocking marketing's Phase 2.

1. **`aggregateRating` schema in `index.html`** — currently `4.8 / 25000`, unsubstantiated. Google can issue a manual action for this. **Remove unless real, on-page reviews back it up.** The marketing repo has explicitly forbidden this schema on its side (Hard Constraint #2 in the marketing prompt) — keep this repo aligned.
2. **Twitter handle `@woningwaarde`** in OG meta — confirm ownership. If not owned, remove `twitter:site` from `index.html`. The marketing repo has already left `twitter.site` empty pending confirmation; do the same here.
3. **No `Organization` JSON-LD** on this repo. Add a single `Organization` block with:
   ```json
   {
     "@context": "https://schema.org",
     "@type": "Organization",
     "@id": "https://www.woninganalyse.nl/#organization",
     "name": "Woninganalyse",
     "url": "https://www.woninganalyse.nl",
     "logo": "https://www.woninganalyse.nl/logo-color.png",
     "sameAs": ["https://www.linkedin.com/company/tinybasenl"]
   }
   ```
   Note the `@id` matches what the marketing repo's homepage will use — both repos can reference the same Organization entity once that lands.
4. **Shared OG image.** Decide one canonical URL for the brand OG image. Recommended: marketing hosts it at `https://www.woninganalyse.nl/opengraph-image` (the dynamic Next.js generator). This repo references the **absolute URL** of that image, never a local copy. Avoids the legacy-host reference and avoids drift between repos.

---

## 8. Cross-domain GA4 linker + shared cookie consent

Marketing has installed GA4 (`G-FBNJCP71XS`) — this is the brand's GA4 property; this repo must use the same ID. GA fires only after the visitor accepts cookies, and consent is **shared across both subdomains via a parent-domain cookie** so a visitor who consents on either surface is not re-prompted on the other.

### 8.1 GA4 install

Use measurement ID `G-FBNJCP71XS`, loaded with the equivalent of `<Script strategy="afterInteractive">` (i.e. after the page is interactive — do not block render). The init must include the `linker` config so the `_ga` cookie spans both subdomains:

```js
gtag('config', 'G-FBNJCP71XS', {
  linker: { domains: ['woninganalyse.nl', 'www.woninganalyse.nl', 'platform.woninganalyse.nl'] }
});
```

(Both `woninganalyse.nl` and `www.woninganalyse.nl` are listed because the marketing canonical is `www.`; visitors arriving via the bare-domain redirect should still keep the `_ga` cookie.)

### 8.2 Shared consent cookie (contract)

Both repos read and write the same cookie. Treat this as a contract — cookie name, value, and scope must match exactly:

| Field | Value |
|---|---|
| **Name** | `cookie-consent` |
| **Accepted value** | `accepted` |
| **Domain** | `.woninganalyse.nl` (parent-domain scope — readable by both subdomains) |
| **Path** | `/` |
| **Max-Age** | `31536000` (1 year) |
| **SameSite** | `Lax` |
| **Secure** | yes (HTTPS-only in prod) |

Header equivalent the platform must emit on accept:

```
Set-Cookie: cookie-consent=accepted; Domain=.woninganalyse.nl; Path=/; Max-Age=31536000; SameSite=Lax; Secure
```

(In dev / on `localhost`, omit `Domain` and `Secure` — the brand-domain attribute is rejected on non-matching hosts.)

### 8.3 Behaviour both repos must implement

1. **On page load**, read the `cookie-consent` cookie. If value is `accepted`, do **not** show the banner and do fire GA4.
2. **On banner accept**, write the cookie with the attributes above, then fire GA4 immediately for the rest of the session (don't wait for the next page load).
3. **The banner UI still exists on both surfaces** — a visitor landing directly on platform without going through marketing first has no consent yet, so the platform must be capable of prompting them. The shared cookie just means "second prompt suppressed" once one side has been accepted.
4. **In-session signal (optional but matched on marketing):** marketing dispatches a `cookie-consent-accepted` `window` event when the banner is accepted, so consent-gated scripts on the same page can start firing without a reload. If the platform also wants in-session activation, dispatch the same event name.

Marketing's reference implementation lives at `lib/consent.ts` (read/write helpers), `components/layout/CookieBanner.tsx` (banner), and `components/analytics/GoogleAnalytics.tsx` (consent-gated GA4) in the marketing repo — useful as a working spec to mirror.

---

## 9. Legacy domain (`hoeveelismijnhuiswaard.net`)

Confirmed live and intentional — runs as a separate B2C brand "WoningWaarde". **Out of scope for both this repo and the marketing repo.** Mentioned only because §3 above requires removing every reference to it from this repo's metadata.

If WoningWaarde later changes ownership / strategy, that's a separate project.

---

## 10. Summary of what this repo should do

| # | Change | File(s) | Severity |
|---|---|---|---|
| 1 | Per-page canonical for `/m/{slug}` → `https://www.woninganalyse.nl/m/{slug}` | `src/pages/MakelaarPage.tsx` (Helmet block) | **Critical** |
| 2 | Per-page `og:url`, `twitter:url` for `/m/{slug}` → marketing | same | **Critical** |
| 3 | `/demo` self-canonical to itself | route emitting demo metadata | High |
| 4 | Remove every `hoeveelismijnhuiswaard.net` reference | `index.html`, `public/robots.txt`, `public/sitemap.xml`, any JSON-LD | **Critical** |
| 5 | Remove `/m/{slug}` URLs from this repo's sitemap | `public/sitemap.xml` (or generator) | High |
| 6 | Trim non-existent routes from sitemap (`/woningwaarde`, `/sfeerimpressie`, `/huistekst`) | `public/sitemap.xml` | High |
| 7 | Replace OG image absolute URL with `https://www.woninganalyse.nl/opengraph-image` | `index.html` | High |
| 8 | Provide public JSON endpoint of active `/m/` slugs for marketing's sitemap | `~api/public/makelaar-slugs.json` (new) | Medium |
| 9 | `robots.txt` per §5 above | `public/robots.txt` | High |
| 10 | Add GA4 `linker` config for cross-domain attribution (coordinate with marketing rollout) | wherever GA4 inits | Medium |
| 11 | Remove unsubstantiated `aggregateRating` from `index.html` | `index.html` | High (manual-action risk) |
| 12 | Remove unverified `twitter:site` (`@woningwaarde`) from `index.html` | `index.html` | Medium |
| 13 | Add `Organization` JSON-LD with shared `@id` | `index.html` | Medium |

---

## 11. Open questions back to this repo's maintainer

1. Does `~api/public/makelaar-slugs.json` (or equivalent) exist already, or does it need to be built? If new, what's the rollout timeline — marketing's sitemap can ship with a manual list as a stop-gap.
2. Does the `<Helmet>` in `MakelaarPage.tsx:111–117` already conditionally set `og:image` per agent (using their logo or a generated card), or does it fall through to the global one in `index.html`? If per-agent, no change needed there beyond the host fix in §3.
3. Is `/chat/{agentSlug}/{objectSlug}` worth indexing for "{adres} te koop bij {makelaar}" queries, or keep `noindex`? Marketing has no opinion — defer to platform.
4. Any auth-gated routes beyond the ones listed in §5 that need disallowing?
