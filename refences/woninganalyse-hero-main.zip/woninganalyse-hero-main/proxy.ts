import type { NextRequest } from 'next/server'

const PLATFORM_ORIGIN = 'https://platform.woninganalyse.nl'
const PLATFORM_HOST = 'platform.woninganalyse.nl'

// Hop-by-hop headers must not be forwarded by a proxy
const HOP_BY_HOP = new Set([
  'connection',
  'keep-alive',
  'proxy-authenticate',
  'proxy-authorization',
  'te',
  'trailers',
  'transfer-encoding',
  'upgrade',
])

/**
 * Proxy /chat/* requests to the platform, fixing response headers so the
 * page can be embedded in a cross-origin iframe by the widget.
 */
export async function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl

  const requestHeaders = new Headers(request.headers)
  requestHeaders.set('host', PLATFORM_HOST)
  requestHeaders.delete('x-middleware-subrequest')

  const upstreamResponse = await fetch(
    `${PLATFORM_ORIGIN}${pathname}${search}`,
    {
      method: request.method,
      headers: requestHeaders,
      body:
        request.method !== 'GET' && request.method !== 'HEAD'
          ? request.body
          : undefined,
      redirect: 'manual',
    }
  )

  const responseHeaders = new Headers()

  // Copy upstream headers, skipping hop-by-hop and headers that are invalid
  // after the fetch API has already auto-decompressed the response body.
  for (const [key, value] of upstreamResponse.headers) {
    const lower = key.toLowerCase()
    if (HOP_BY_HOP.has(lower)) continue
    // fetch() decompresses automatically; forwarding this causes double-decompression
    if (lower === 'content-encoding') continue
    // content-length reflects compressed size; wrong after decompression
    if (lower === 'content-length') continue
    // Set-Cookie is handled separately below to avoid multi-value corruption
    if (lower === 'set-cookie') continue
    responseHeaders.set(key, value)
  }

  // Rewrite Location header so redirects (e.g. trailing-slash) stay on our domain
  const location = responseHeaders.get('location')
  if (location?.startsWith(PLATFORM_ORIGIN)) {
    responseHeaders.set('location', location.slice(PLATFORM_ORIGIN.length) || '/')
  }

  // Explicitly allow cross-origin iframe embedding.
  // ALLOWALL is the de-facto permissive value; modern browsers rely on the
  // CSP frame-ancestors directive below instead.
  responseHeaders.set('x-frame-options', 'ALLOWALL')

  // Remove frame-ancestors restrictions from the upstream CSP (if any),
  // then add frame-ancestors https: http: file: to permit embedding from any origin.
  const csp = responseHeaders.get('content-security-policy')
  const cspBase = csp
    ? csp
        .split(';')
        .map((d) => d.trim())
        .filter((d) => !d.toLowerCase().startsWith('frame-ancestors'))
        .join('; ')
    : ''
  responseHeaders.set(
    'content-security-policy',
    cspBase ? `${cspBase}; frame-ancestors https: http: file:` : 'frame-ancestors https: http: file:'
  )

  // Rewrite Set-Cookie headers for cross-origin iframe compatibility:
  //   - Remove Domain=platform.woninganalyse.nl (must match our host)
  //   - Set SameSite=None so cookies are sent inside a third-party iframe
  //   - Ensure Secure is present (required by browsers for SameSite=None)
  for (const cookie of upstreamResponse.headers.getSetCookie()) {
    responseHeaders.append('set-cookie', rewriteSetCookie(cookie))
  }

  return new Response(upstreamResponse.body, {
    status: upstreamResponse.status,
    statusText: upstreamResponse.statusText,
    headers: responseHeaders,
  })
}

function rewriteSetCookie(cookie: string): string {
  let result = cookie.replace(/;\s*Domain=[^;]*/gi, '')

  if (/SameSite=/i.test(result)) {
    result = result.replace(/SameSite=\w+/gi, 'SameSite=None')
  } else {
    result += '; SameSite=None'
  }

  if (!/;\s*Secure\b/i.test(result)) {
    result += '; Secure'
  }

  return result
}

export const config = {
  matcher: '/chat/:path*',
}
