

# Two Quick Fixes: Logo Spacing + Testimonial Alignment

## 1. Reduce logo letter spacing
The "BLOOM" logo currently uses `tracking-[0.15em]` which is too spread out. Reduce to `tracking-[0.05em]` for a tighter, more impactful look.

**Files:** `src/components/Navbar.tsx` (line 19), `src/components/Footer.tsx`

## 2. Align testimonial cards so names are at the same height
The two quote cards have different text lengths, pushing the photo+name sections to different vertical positions. Fix by making each card a flex column with the blockquote growing to fill space, pushing the author info to the bottom consistently.

**File:** `src/components/SocialProofSection.tsx`
- Add `flex flex-col` to each card container
- Add `flex-1` to the blockquote so it stretches
- This pins the photo+name row to the bottom of each card at the same height

---

| File | Change |
|------|--------|
| `src/components/Navbar.tsx` | `tracking-[0.15em]` to `tracking-[0.05em]` |
| `src/components/Footer.tsx` | `tracking-[0.15em]` to `tracking-[0.05em]` |
| `src/components/SocialProofSection.tsx` | Add flex column layout to cards for equal-height alignment |

