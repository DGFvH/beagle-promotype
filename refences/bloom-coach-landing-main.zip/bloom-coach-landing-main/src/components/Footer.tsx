import bloomIcon from "@/assets/bloom-icon.png";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="border-t border-border bg-card pt-12 pb-8">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Column 1: Logo + tagline */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <img src={bloomIcon} alt="Bloom" className="h-6 w-6" />
              <span className="font-logo text-xl font-extrabold tracking-[0.05em] text-foreground">BLOOM</span>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              De alles-in-één tool voor coaches die hun praktijk willen laten groeien.
            </p>
          </div>

          {/* Column 2: Product */}
          <div>
            <h4 className="mb-4 text-sm font-semibold text-foreground">Product</h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li><Link to="/agenda" className="hover:text-foreground transition-colors">Agenda</Link></li>
              <li><Link to="/clienten" className="hover:text-foreground transition-colors">Cliënten</Link></li>
              <li><Link to="/financien" className="hover:text-foreground transition-colors">Financiën</Link></li>
              <li><Link to="/prijzen" className="hover:text-foreground transition-colors">Prijzen</Link></li>
            </ul>
          </div>

          {/* Column 3: Ondersteuning */}
          <div>
            <h4 className="mb-4 text-sm font-semibold text-foreground">Ondersteuning</h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li><Link to="/contact" className="hover:text-foreground transition-colors">Contact</Link></li>
              <li><Link to="/#faq" className="hover:text-foreground transition-colors">FAQ</Link></li>
              <li><Link to="/privacy" className="hover:text-foreground transition-colors">Privacy</Link></li>
              <li><Link to="/voorwaarden" className="hover:text-foreground transition-colors">Voorwaarden</Link></li>
            </ul>
          </div>

          {/* Column 4: Volg ons */}
          <div>
            <h4 className="mb-4 text-sm font-semibold text-foreground">Volg ons</h4>
            <ul className="space-y-2.5 text-sm text-muted-foreground">
              <li><a href="#" className="hover:text-foreground transition-colors">LinkedIn</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Instagram</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors">Twitter</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-10 border-t border-border pt-6 text-center text-sm text-muted-foreground">
          © 2026 Bloom. Gemaakt in Nederland. 🇳🇱
        </div>
      </div>
    </footer>
  );
};

export default Footer;
