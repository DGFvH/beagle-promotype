import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, CalendarDays, FileText, Users } from "lucide-react";
import heroImage from "@/assets/hero-coaching.webp";

/* ── Mobile-friendly simplified dashboard ── */
const MobileDashboard = () => (
  <div className="flex flex-col gap-3 md:hidden">
    {/* Calendar card */}
    <div className="rounded-2xl border border-white/15 bg-white/15 p-4 shadow-lg backdrop-blur-xl">
      <div className="mb-2 flex items-center gap-2">
        <CalendarDays className="h-5 w-5 text-primary-light" />
        <span className="text-sm font-bold text-white">Agenda</span>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-xs text-white/60">
        {["Ma","Di","Wo","Do","Vr","Za","Zo"].map(d => (
          <span key={d} className="font-medium">{d}</span>
        ))}
        {Array.from({ length: 7 }, (_, i) => (
          <span
            key={i}
            className={`rounded-md py-0.5 ${
              i === 2
                ? "bg-primary-light text-white font-bold"
                : i === 4
                ? "bg-accent/30 text-accent font-medium"
                : "text-white/70"
            }`}
          >
            {i + 10}
          </span>
        ))}
      </div>
    </div>

    {/* Clients + Invoice row */}
    <div className="grid grid-cols-2 gap-3">
      <div className="rounded-2xl border border-white/15 bg-white/15 p-3 shadow-lg backdrop-blur-xl">
        <div className="mb-2 flex items-center gap-2">
          <Users className="h-4 w-4 text-primary-light" />
          <span className="text-xs font-bold text-white">Cliënten</span>
        </div>
        <div className="space-y-1.5">
          {["Lisa", "Mark", "Sophie"].map((name, i) => (
            <div key={name} className="flex items-center gap-1.5">
              <div className={`h-1.5 w-1.5 rounded-full ${i === 0 ? "bg-primary-light" : i === 1 ? "bg-accent" : "bg-primary-light"}`} />
              <span className="text-[10px] text-white/70">{name}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="rounded-2xl border border-white/15 bg-white/15 p-3 shadow-lg backdrop-blur-xl">
        <div className="mb-2 flex items-center gap-2">
          <FileText className="h-4 w-4 text-primary-light" />
          <span className="text-xs font-bold text-white">Factuur</span>
        </div>
        <div className="space-y-1">
          <div className="h-1.5 w-16 rounded bg-white/20" />
          <div className="h-1.5 w-10 rounded bg-white/20" />
          <div className="mt-2 flex items-center justify-between">
            <span className="text-[10px] font-bold text-white">€ 120</span>
            <span className="rounded-full bg-primary-light/20 px-1.5 py-0.5 text-[8px] font-semibold text-primary-light">Betaald</span>
          </div>
        </div>
      </div>
    </div>
  </div>
);

/* ── Desktop floating dashboard ── */
const FloatingDashboard = () => (
  <div className="relative hidden h-[400px] w-full max-w-lg mx-auto md:block">
    {/* Invoice card */}
    <div className="absolute bottom-8 left-2 w-48 rotate-[-2deg] rounded-2xl border border-white/15 bg-white/15 p-4 shadow-[0_25px_70px_-15px_rgba(0,0,0,0.4)] backdrop-blur-xl">
      <div className="mb-2 flex items-center gap-2">
        <FileText className="h-4 w-4 text-primary-light" />
        <span className="text-xs font-semibold text-white">Factuur #1042</span>
      </div>
      <div className="space-y-1.5">
        <div className="h-2 w-24 rounded bg-white/20" />
        <div className="h-2 w-16 rounded bg-white/20" />
        <div className="mt-3 flex items-center justify-between">
          <span className="text-xs font-bold text-white">€ 120,00</span>
          <span className="rounded-full bg-primary-light/20 px-2 py-0.5 text-[10px] font-semibold text-primary-light">Betaald</span>
        </div>
      </div>
    </div>

    {/* Main calendar card */}
    <div className="absolute left-2 top-0 w-60 rounded-2xl border border-white/15 bg-white/15 p-5 shadow-[0_25px_70px_-15px_rgba(0,0,0,0.4)] backdrop-blur-xl">
      <div className="mb-3 flex items-center gap-2">
        <CalendarDays className="h-5 w-5 text-primary-light" />
        <span className="text-sm font-bold text-white">Februari 2026</span>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-[10px] text-white/60">
        {["Ma","Di","Wo","Do","Vr","Za","Zo"].map(d => (
          <span key={d} className="font-medium">{d}</span>
        ))}
        {Array.from({ length: 28 }, (_, i) => (
          <span
            key={i}
            className={`rounded-md py-0.5 ${
              i === 12
                ? "bg-primary-light text-white font-bold"
                : i === 17 || i === 20
                ? "bg-accent/30 text-accent font-medium"
                : "text-white/70"
            }`}
          >
            {i + 1}
          </span>
        ))}
      </div>
    </div>

    {/* Client list card */}
    <div className="absolute right-2 top-14 w-52 rounded-2xl border border-white/15 bg-white/15 p-4 shadow-[0_25px_70px_-15px_rgba(0,0,0,0.4)] backdrop-blur-xl">
      <div className="mb-3 flex items-center gap-2">
        <Users className="h-4 w-4 text-primary-light" />
        <span className="text-xs font-bold text-white">Cliënten</span>
      </div>
      <div className="space-y-2.5">
        {[
          { name: "Lisa de Vries", status: "bg-primary-light" },
          { name: "Mark Jansen", status: "bg-accent" },
          { name: "Sophie Bakker", status: "bg-primary-light" },
          { name: "Tom van Dijk", status: "bg-white/30" },
        ].map((c) => (
          <div key={c.name} className="flex items-center gap-2">
            <div className={`h-2 w-2 rounded-full ${c.status}`} />
            <div className="h-2.5 flex-1 rounded bg-white/20" />
            <span className="text-[10px] text-white/70">{c.name.split(" ")[0]}</span>
          </div>
        ))}
      </div>
    </div>
  </div>
);


const HeroSection = () => {
  return (
    <section
      id="hero"
      className="relative overflow-hidden font-hero"
      style={{
        backgroundImage: `url(${heroImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/75 to-black/60" />

      <div className="relative mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-2 md:items-center md:py-24 lg:px-8">
        <div className="space-y-5">
          <h1 className="font-hero text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-4xl md:text-5xl lg:text-[3.25rem]">
            Focus op je cliënten,{" "}
            <span className="text-primary-light">wij doen de rest.</span>
          </h1>
          <p className="max-w-lg text-base leading-relaxed text-white/80 sm:text-lg">
            Bloom automatiseert je agenda, facturatie en cliëntadministratie
            — zodat jij je volledig kunt richten op wat ertoe doet.
          </p>

          <div className="space-y-3">
            <Button size="lg" className="w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90 text-base px-8 py-6 rounded-xl shadow-lg shadow-primary/20 sm:w-auto">
              Probeer 30 dagen gratis
              <ArrowRight className="h-5 w-5" />
            </Button>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap items-center gap-4 pt-2 text-sm text-white/70">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-primary-light" />
              Geen creditcard nodig
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-primary-light" />
              Annuleer wanneer je wilt
            </span>
          </div>
        </div>

        <FloatingDashboard />
      </div>

    </section>
  );
};

export default HeroSection;
