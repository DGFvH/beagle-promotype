import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "Kan ik mijn bestaande agenda koppelen?",
    a: "Ja, Bloom synchroniseert naadloos twee kanten op met zowel Google Calendar als Outlook.",
  },
  {
    q: "Zit ik direct ergens aan vast?",
    a: "Nee. Je start altijd met een gratis proefperiode van 30 dagen. Daarna is je abonnement gewoon maandelijks opzegbaar.",
  },
  {
    q: "Is mijn data veilig bij Bloom?",
    a: "Ja. Jouw data en die van je cliënten wordt versleuteld opgeslagen op beveiligde servers. We nemen betrouwbare data-opslag serieus.",
  },
  {
    q: "Hoe betalen mijn cliënten?",
    a: "Via een directe integratie met Stripe kun je eenvoudig iDEAL of creditcard betaallinks meesturen met je automatische facturen.",
  },
];

const FaqSection = () => (
  <section className="border-t border-primary-foreground/10 bg-primary py-16 sm:py-28">
    <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
      <div className="mb-10 text-center sm:mb-14">
        <h2 className="font-heading text-2xl font-bold text-primary-foreground sm:text-3xl md:text-4xl">
          Veelgestelde vragen
        </h2>
        <p className="mt-3 text-base text-primary-foreground/70">
          Alles wat je moet weten over Bloom.
        </p>
      </div>

      <Accordion type="single" collapsible className="w-full">
        {faqs.map((faq, i) => (
          <AccordionItem key={i} value={`item-${i}`} className="border-primary-foreground/20">
            <AccordionTrigger className="text-left text-base font-semibold text-primary-foreground py-5 [&>svg]:text-primary-foreground">
              {faq.q}
            </AccordionTrigger>
            <AccordionContent className="text-primary-foreground/80 leading-relaxed">
              {faq.a}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  </section>
);

export default FaqSection;
