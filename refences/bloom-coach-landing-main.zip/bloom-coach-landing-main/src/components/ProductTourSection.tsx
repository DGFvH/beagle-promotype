import { CheckCircle2, CalendarDays, Users, Search, Receipt, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

/* ── Mockups ── */

const AgendaMockup = () => (
  <div className="relative">
    <div className="rounded-3xl border border-border/40 bg-white/70 p-5 shadow-[0_8px_40px_-8px_rgba(0,0,0,0.08)] backdrop-blur-xl dark:bg-card/70">
      <div className="mb-4 flex items-center gap-2">
        <CalendarDays className="h-5 w-5 text-primary" />
        <span className="text-sm font-bold text-foreground">Week 9 — Februari 2026</span>
      </div>
      <div className="grid grid-cols-5 gap-1 text-center text-[10px] font-medium text-muted-foreground mb-2">
        {["Ma 24","Di 25","Wo 26","Do 27","Vr 28"].map(d => <span key={d}>{d}</span>)}
      </div>
      {["09:00","10:00","11:00","14:00","15:00"].map(t => (
        <div key={t} className="grid grid-cols-5 gap-1 mb-1">
          {[0,1,2,3,4].map(col => (
            <div key={col} className={`h-6 rounded-md border border-border/30 ${
              (t === "10:00" && col === 1) ? "bg-primary/15 border-primary/30" :
              (t === "14:00" && col === 3) ? "bg-accent/15 border-accent/30" :
              "bg-secondary/30"
            }`} />
          ))}
        </div>
      ))}
    </div>
    <div className="absolute -bottom-4 -right-4 w-52 rounded-3xl border border-border/40 bg-white/80 p-4 shadow-[0_8px_40px_-8px_rgba(0,0,0,0.08)] backdrop-blur-xl dark:bg-card/80">
      <p className="text-xs font-bold text-foreground mb-2">Nieuwe afspraak</p>
      <div className="space-y-2">
        <div className="h-7 rounded-lg bg-secondary/60 px-2 flex items-center">
          <span className="text-[10px] text-muted-foreground">Di 25 feb — 10:00</span>
        </div>
        <div className="h-7 rounded-lg bg-secondary/60 px-2 flex items-center">
          <span className="text-[10px] text-muted-foreground">Lisa de Vries</span>
        </div>
        <div className="h-7 rounded-lg bg-primary text-primary-foreground flex items-center justify-center">
          <span className="text-[10px] font-semibold">Bevestigen</span>
        </div>
      </div>
    </div>
  </div>
);

const ClientMockup = () => (
  <div className="rounded-3xl border border-border/40 bg-white/70 p-5 shadow-[0_8px_40px_-8px_rgba(0,0,0,0.08)] backdrop-blur-xl dark:bg-card/70">
    <div className="mb-4 flex items-center gap-2 rounded-lg bg-secondary/60 px-3 py-2">
      <Search className="h-4 w-4 text-muted-foreground" />
      <span className="text-xs text-muted-foreground">Zoek cliënt...</span>
    </div>
    <div className="grid grid-cols-[1fr_auto_auto] gap-3 mb-2 px-1 text-[10px] font-semibold text-muted-foreground">
      <span>Naam</span><span>Status</span><span>Traject</span>
    </div>
    {[
      { name: "Lisa de Vries", status: "Gepland", color: "bg-blue-100 text-blue-700" },
      { name: "Mark Jansen", status: "Uitgenodigd", color: "bg-amber-100 text-amber-700" },
      { name: "Sophie Bakker", status: "Actie nodig", color: "bg-red-100 text-red-700" },
      { name: "Tom van Dijk", status: "Gepland", color: "bg-blue-100 text-blue-700" },
      { name: "Anna Visser", status: "Uitgenodigd", color: "bg-amber-100 text-amber-700" },
    ].map(c => (
      <div key={c.name} className="grid grid-cols-[1fr_auto_auto] gap-3 items-center rounded-lg px-1 py-2.5 border-b border-border/30 last:border-0">
        <div className="flex items-center gap-2">
          <div className="h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center">
            <Users className="h-3 w-3 text-primary" />
          </div>
          <span className="text-xs font-medium text-foreground">{c.name}</span>
        </div>
        <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${c.color}`}>{c.status}</span>
        <div className="h-2 w-12 rounded bg-muted" />
      </div>
    ))}
  </div>
);

const FinanceMockup = () => (
  <div className="rounded-3xl border border-border/40 bg-white/70 p-5 shadow-[0_8px_40px_-8px_rgba(0,0,0,0.08)] backdrop-blur-xl dark:bg-card/70">
    <div className="grid grid-cols-3 gap-3 mb-5">
      {[
        { label: "Omzet", value: "€ 4.320", sub: "deze maand" },
        { label: "Openstaand", value: "€ 540", sub: "3 facturen" },
        { label: "Betaald", value: "€ 3.780", sub: "12 facturen" },
      ].map(s => (
        <div key={s.label} className="rounded-xl bg-secondary/60 p-3 text-center">
          <p className="text-xs text-muted-foreground">{s.label}</p>
          <p className="text-base font-bold text-foreground">{s.value}</p>
          <p className="text-[10px] text-muted-foreground">{s.sub}</p>
        </div>
      ))}
    </div>
    <div className="flex items-center gap-2 mb-3">
      <Receipt className="h-4 w-4 text-primary" />
      <span className="text-xs font-bold text-foreground">Recente facturen</span>
    </div>
    {[
      { id: "#1042", client: "Lisa de Vries", amount: "€ 120,00", badge: "Betaald", color: "bg-primary/15 text-primary" },
      { id: "#1041", client: "Mark Jansen", amount: "€ 95,00", badge: "Verzonden", color: "bg-amber-100 text-amber-700" },
      { id: "#1040", client: "Sophie Bakker", amount: "€ 180,00", badge: "Betaald", color: "bg-primary/15 text-primary" },
      { id: "#1039", client: "Tom van Dijk", amount: "€ 145,00", badge: "Verzonden", color: "bg-amber-100 text-amber-700" },
    ].map(inv => (
      <div key={inv.id} className="flex items-center justify-between py-2.5 border-b border-border/30 last:border-0">
        <div className="flex items-center gap-3">
          <span className="text-[10px] font-mono text-muted-foreground">{inv.id}</span>
          <span className="text-xs text-foreground">{inv.client}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs font-semibold text-foreground">{inv.amount}</span>
          <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${inv.color}`}>{inv.badge}</span>
        </div>
      </div>
    ))}
  </div>
);

/* ── Data ── */

const blocks = [
  {
    step: "01",
    bg: "bg-[#F5F3EE]",
    headline: "Nooit meer heen en weer mailen.",
    paragraph: "Deel je persoonlijke boekingslink en laat cliënten zelf het beste moment kiezen.",
    bullets: [
      "Sync met Google & Outlook Calendar",
      "Automatische bevestigingen & herinneringen",
      "Gepersonaliseerde boekingspagina",
    ],
    mockup: <AgendaMockup />,
    link: "/agenda",
  },
  {
    step: "02",
    bg: "bg-[#F0F4F1] border-y border-border/30",
    headline: "Al je cliënten overzichtelijk op één plek.",
    paragraph: "Contactgegevens, sessiegeschiedenis en factuurstatus — alles bij de hand zonder losse spreadsheets.",
    bullets: [
      "Overzicht van geplande en afgeronde sessies",
      "Contactgegevens altijd bij de hand",
      "Gekoppeld aan agenda en facturatie",
    ],
    mockup: <ClientMockup />,
    fullWidth: true,
    link: "/clienten",
  },
  {
    step: "03",
    bg: "bg-[#F5F3EE]",
    headline: "Factureren op de automatische piloot.",
    paragraph: "Rond je sessie af en de factuur gaat vanzelf. Jij hoeft niks te doen.",
    bullets: [
      "PDF-facturen in jouw huisstijl",
      "iDEAL & creditcard betaallinks",
      "Automatische betalingsherinneringen",
    ],
    mockup: <FinanceMockup />,
    link: "/financien",
  },
];

/* ── Shared block content ── */

const BlockContent = ({ block }: { block: typeof blocks[0] }) => (
  <div>
    <h2 className="mb-3 font-heading text-3xl font-bold leading-tight text-foreground sm:text-4xl md:text-5xl">
      {block.headline}
    </h2>
    <p className="mb-6 text-base text-muted-foreground sm:text-lg">
      {block.paragraph}
    </p>
    <ul className="space-y-3 mb-8">
      {block.bullets.map(b => (
        <li key={b} className="flex items-start gap-2.5">
          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-[#5B9E8F]" />
          <span className="text-sm font-medium text-foreground/90">{b}</span>
        </li>
      ))}
    </ul>
    <div className="space-y-2">
      <Button asChild className="w-full gap-2 px-6 py-5 text-base rounded-xl shadow-lg shadow-primary/15 hover:-translate-y-0.5 hover:shadow-xl transition-all duration-200 sm:w-auto">
        <Link to={block.link}>
          Probeer het uit
          <ArrowRight className="h-4 w-4" />
        </Link>
      </Button>
      <p className="text-xs text-muted-foreground">
        Interactieve demo — geen account nodig
      </p>
    </div>
  </div>
);

/* ── Component ── */

const ProductTourSection = () => (
  <section id="product-tour">
    {blocks.map((block, i) => (
      <div key={i} className={`py-20 sm:py-32 ${block.bg}`}>
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          {block.fullWidth ? (
            <div className="space-y-12">
              <div className="max-w-2xl text-left sm:mx-auto sm:text-center">
                <BlockContent block={block} />
              </div>
              <div className="mx-auto max-w-4xl">
                {block.mockup}
              </div>
            </div>
          ) : (
            <div className="grid items-center gap-12 md:grid-cols-2">
              <div>
                <BlockContent block={block} />
              </div>
              <div>
                {block.mockup}
              </div>
            </div>
          )}
        </div>
      </div>
    ))}
  </section>
);

export default ProductTourSection;
