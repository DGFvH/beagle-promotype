import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Info, RotateCcw, Plus, Search, Users } from "lucide-react";

interface Client {
  id: number;
  name: string;
  email: string;
  status: "Uitgenodigd" | "Gepland" | "Actie nodig";
}

const STATUS_CYCLE: Client["status"][] = ["Uitgenodigd", "Gepland", "Actie nodig"];
const STATUS_COLORS: Record<Client["status"], string> = {
  "Uitgenodigd": "bg-amber-100 text-amber-700",
  "Gepland": "bg-blue-100 text-blue-700",
  "Actie nodig": "bg-red-100 text-red-700",
};

const INITIAL_CLIENTS: Client[] = [
  { id: 1, name: "Lisa de Vries", email: "lisa@voorbeeld.nl", status: "Gepland" },
  { id: 2, name: "Mark Jansen", email: "mark@voorbeeld.nl", status: "Uitgenodigd" },
  { id: 3, name: "Sophie Bakker", email: "sophie@voorbeeld.nl", status: "Actie nodig" },
  { id: 4, name: "Tom van Dijk", email: "tom@voorbeeld.nl", status: "Gepland" },
  { id: 5, name: "Anna Visser", email: "anna@voorbeeld.nl", status: "Uitgenodigd" },
];

const ClientenDemo = () => {
  const [clients, setClients] = useState<Client[]>(INITIAL_CLIENTS);
  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");

  const filtered = clients.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  const toggleStatus = (id: number) => {
    setClients(prev => prev.map(c => {
      if (c.id !== id) return c;
      const idx = STATUS_CYCLE.indexOf(c.status);
      return { ...c, status: STATUS_CYCLE[(idx + 1) % STATUS_CYCLE.length] };
    }));
  };

  const addClient = () => {
    if (!newName) return;
    setClients(prev => [...prev, {
      id: Date.now(),
      name: newName,
      email: newEmail,
      status: "Uitgenodigd",
    }]);
    setModalOpen(false);
    setNewName("");
    setNewEmail("");
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-[0_20px_60px_-12px_rgba(0,0,0,0.08)]">
      <div className="mb-6 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2 rounded-lg bg-primary/5 px-3 py-2">
          <Info className="h-4 w-4 text-primary" />
          <span className="text-sm text-muted-foreground">Klik op een status-badge om deze te wijzigen</span>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setClients(INITIAL_CLIENTS)} className="gap-1.5">
          <RotateCcw className="h-3.5 w-3.5" />
          Reset
        </Button>
      </div>

      <div className="mb-4 flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Zoek cliënt..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button onClick={() => setModalOpen(true)} className="gap-1.5">
          <Plus className="h-4 w-4" />
          Nieuwe cliënt
        </Button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border text-left text-xs font-semibold text-muted-foreground">
              <th className="pb-3 pl-2">Naam</th>
              <th className="pb-3">E-mail</th>
              <th className="pb-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(c => (
              <tr key={c.id} className="border-b border-border/30 last:border-0">
                <td className="py-3 pl-2">
                  <div className="flex items-center gap-2">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Users className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="text-sm font-medium text-foreground">{c.name}</span>
                  </div>
                </td>
                <td className="py-3 text-sm text-muted-foreground">{c.email}</td>
                <td className="py-3">
                  <button
                    onClick={() => toggleStatus(c.id)}
                    className={`rounded-full px-3 py-1 text-xs font-semibold transition-colors ${STATUS_COLORS[c.status]}`}
                  >
                    {c.status}
                  </button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={3} className="py-8 text-center text-sm text-muted-foreground">
                  Geen cliënten gevonden
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Nieuwe cliënt toevoegen</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input placeholder="Naam" value={newName} onChange={e => setNewName(e.target.value)} />
            <Input placeholder="E-mailadres" type="email" value={newEmail} onChange={e => setNewEmail(e.target.value)} />
            <Button onClick={addClient} className="w-full" disabled={!newName}>
              Toevoegen
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ClientenDemo;
