import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Info, RotateCcw, Plus, Receipt, TrendingUp, Clock, CheckCircle2 } from "lucide-react";

interface Invoice {
  id: string;
  client: string;
  amount: number;
  description: string;
  status: "open" | "betaald";
}

const INITIAL_INVOICES: Invoice[] = [
  { id: "#1042", client: "Lisa de Vries", amount: 120, description: "Coachsessie — februari", status: "betaald" },
  { id: "#1041", client: "Mark Jansen", amount: 95, description: "Intake gesprek", status: "open" },
  { id: "#1040", client: "Sophie Bakker", amount: 180, description: "Traject evaluatie", status: "betaald" },
  { id: "#1039", client: "Tom van Dijk", amount: 145, description: "Coachsessie x2", status: "open" },
];

const FinancienDemo = () => {
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [modalOpen, setModalOpen] = useState(false);
  const [newClient, setNewClient] = useState("");
  const [newAmount, setNewAmount] = useState("");
  const [newDesc, setNewDesc] = useState("");

  const stats = useMemo(() => {
    const total = invoices.reduce((s, i) => s + i.amount, 0);
    const paid = invoices.filter(i => i.status === "betaald").reduce((s, i) => s + i.amount, 0);
    const open = total - paid;
    return { total, paid, open, paidCount: invoices.filter(i => i.status === "betaald").length, openCount: invoices.filter(i => i.status === "open").length };
  }, [invoices]);

  const markPaid = (id: string) => {
    setInvoices(prev => prev.map(i => i.id === id ? { ...i, status: "betaald" as const } : i));
  };

  const addInvoice = () => {
    if (!newClient || !newAmount) return;
    const num = invoices.length + 1039;
    setInvoices(prev => [...prev, {
      id: `#${num}`,
      client: newClient,
      amount: parseFloat(newAmount),
      description: newDesc || "Coachsessie",
      status: "open",
    }]);
    setModalOpen(false);
    setNewClient("");
    setNewAmount("");
    setNewDesc("");
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-[0_20px_60px_-12px_rgba(0,0,0,0.08)]">
      <div className="mb-6 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2 rounded-lg bg-primary/5 px-3 py-2">
          <Info className="h-4 w-4 text-primary" />
          <span className="text-sm text-muted-foreground">Maak facturen aan en markeer ze als betaald</span>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setInvoices(INITIAL_INVOICES)} className="gap-1.5">
          <RotateCcw className="h-3.5 w-3.5" />
          Reset
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="rounded-xl bg-secondary/40 p-4 text-center">
          <TrendingUp className="mx-auto mb-1 h-5 w-5 text-primary" />
          <p className="text-xs text-muted-foreground">Omzet</p>
          <p className="text-xl font-bold text-foreground">€ {stats.total.toLocaleString("nl-NL")}</p>
        </div>
        <div className="rounded-xl bg-secondary/40 p-4 text-center">
          <Clock className="mx-auto mb-1 h-5 w-5 text-amber-600" />
          <p className="text-xs text-muted-foreground">Openstaand</p>
          <p className="text-xl font-bold text-foreground">€ {stats.open.toLocaleString("nl-NL")}</p>
          <p className="text-[10px] text-muted-foreground">{stats.openCount} facturen</p>
        </div>
        <div className="rounded-xl bg-secondary/40 p-4 text-center">
          <CheckCircle2 className="mx-auto mb-1 h-5 w-5 text-primary" />
          <p className="text-xs text-muted-foreground">Betaald</p>
          <p className="text-xl font-bold text-foreground">€ {stats.paid.toLocaleString("nl-NL")}</p>
          <p className="text-[10px] text-muted-foreground">{stats.paidCount} facturen</p>
        </div>
      </div>

      {/* Bar chart */}
      <div className="mb-6 flex items-end gap-1 h-16">
        {invoices.map(inv => (
          <div
            key={inv.id}
            className={`flex-1 rounded-t-md transition-all ${inv.status === "betaald" ? "bg-primary/30" : "bg-amber-300/50"}`}
            style={{ height: `${(inv.amount / 200) * 100}%` }}
            title={`${inv.client}: € ${inv.amount}`}
          />
        ))}
      </div>

      {/* Invoice list */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Receipt className="h-4 w-4 text-primary" />
          <span className="text-sm font-bold text-foreground">Facturen</span>
        </div>
        <Button size="sm" onClick={() => setModalOpen(true)} className="gap-1.5">
          <Plus className="h-3.5 w-3.5" />
          Nieuwe factuur
        </Button>
      </div>

      <div className="space-y-1">
        {invoices.map(inv => (
          <div key={inv.id} className="flex items-center justify-between rounded-lg px-3 py-3 border border-border/30">
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono text-muted-foreground">{inv.id}</span>
              <div>
                <p className="text-sm font-medium text-foreground">{inv.client}</p>
                <p className="text-xs text-muted-foreground">{inv.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm font-semibold text-foreground">€ {inv.amount.toFixed(2).replace(".", ",")}</span>
              {inv.status === "betaald" ? (
                <span className="rounded-full bg-primary/15 px-3 py-1 text-xs font-semibold text-primary">Betaald</span>
              ) : (
                <button
                  onClick={() => markPaid(inv.id)}
                  className="rounded-full bg-amber-100 px-3 py-1 text-xs font-semibold text-amber-700 hover:bg-primary/15 hover:text-primary transition-colors"
                >
                  Markeer als betaald
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Nieuwe factuur</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input placeholder="Cliëntnaam" value={newClient} onChange={e => setNewClient(e.target.value)} />
            <Input placeholder="Bedrag (€)" type="number" value={newAmount} onChange={e => setNewAmount(e.target.value)} />
            <Input placeholder="Omschrijving" value={newDesc} onChange={e => setNewDesc(e.target.value)} />
            <Button onClick={addInvoice} className="w-full" disabled={!newClient || !newAmount}>
              Factuur aanmaken
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default FinancienDemo;
