import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Info, RotateCcw } from "lucide-react";

interface Session {
  day: number;
  hour: number;
  client: string;
  type: string;
  color: string;
}

const DAYS = ["Ma", "Di", "Wo", "Do", "Vr"];
const HOURS = [9, 10, 11, 12, 13, 14, 15, 16, 17];
const TYPES = [
  { value: "intake", label: "Intake gesprek", color: "bg-primary/20 border-primary/40 text-primary" },
  { value: "sessie", label: "Coachsessie", color: "bg-accent/20 border-accent/40 text-accent-foreground" },
  { value: "evaluatie", label: "Evaluatie", color: "bg-blue-100 border-blue-300 text-blue-700" },
];

const INITIAL_SESSIONS: Session[] = [
  { day: 1, hour: 10, client: "Lisa de Vries", type: "sessie", color: "bg-accent/20 border-accent/40 text-accent-foreground" },
  { day: 3, hour: 14, client: "Mark Jansen", type: "intake", color: "bg-primary/20 border-primary/40 text-primary" },
  { day: 4, hour: 11, client: "Sophie Bakker", type: "evaluatie", color: "bg-blue-100 border-blue-300 text-blue-700" },
];

const AgendaDemo = () => {
  const [sessions, setSessions] = useState<Session[]>(INITIAL_SESSIONS);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<{ day: number; hour: number } | null>(null);
  const [clientName, setClientName] = useState("");
  const [sessionType, setSessionType] = useState("");

  const getSession = (day: number, hour: number) =>
    sessions.find(s => s.day === day && s.hour === hour);

  const handleSlotClick = (day: number, hour: number) => {
    if (getSession(day, hour)) return;
    setSelectedSlot({ day, hour });
    setClientName("");
    setSessionType("");
    setModalOpen(true);
  };

  const handleConfirm = () => {
    if (!selectedSlot || !clientName || !sessionType) return;
    const typeInfo = TYPES.find(t => t.value === sessionType);
    setSessions(prev => [...prev, {
      day: selectedSlot.day,
      hour: selectedSlot.hour,
      client: clientName,
      type: sessionType,
      color: typeInfo?.color || "bg-primary/20 border-primary/40 text-primary",
    }]);
    setModalOpen(false);
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-[0_20px_60px_-12px_rgba(0,0,0,0.08)]">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2 rounded-lg bg-primary/5 px-3 py-2">
          <Info className="h-4 w-4 text-primary" />
          <span className="text-sm text-muted-foreground">Dit is een interactieve demo — klik op een leeg tijdslot om te boeken!</span>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setSessions(INITIAL_SESSIONS)} className="gap-1.5">
          <RotateCcw className="h-3.5 w-3.5" />
          Reset
        </Button>
      </div>

      <div className="overflow-x-auto">
        <div className="min-w-[600px]">
          {/* Header */}
          <div className="grid grid-cols-[60px_repeat(5,1fr)] gap-1 mb-2">
            <div />
            {DAYS.map((d, i) => (
              <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">
                {d} {24 + i}
              </div>
            ))}
          </div>

          {/* Time grid */}
          {HOURS.map(hour => (
            <div key={hour} className="grid grid-cols-[60px_repeat(5,1fr)] gap-1 mb-1">
              <div className="flex items-center justify-end pr-2 text-[11px] text-muted-foreground">
                {hour}:00
              </div>
              {DAYS.map((_, dayIdx) => {
                const session = getSession(dayIdx, hour);
                return (
                  <button
                    key={dayIdx}
                    onClick={() => handleSlotClick(dayIdx, hour)}
                    className={`h-10 rounded-lg border text-[11px] font-medium transition-colors ${
                      session
                        ? `${session.color} border cursor-default`
                        : "border-border/40 bg-secondary/20 hover:bg-primary/5 hover:border-primary/30 cursor-pointer"
                    }`}
                  >
                    {session ? session.client : ""}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Nieuwe afspraak</DialogTitle>
          </DialogHeader>
          {selectedSlot && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                {DAYS[selectedSlot.day]} {24 + selectedSlot.day} feb — {selectedSlot.hour}:00
              </p>
              <Input
                placeholder="Cliëntnaam"
                value={clientName}
                onChange={e => setClientName(e.target.value)}
              />
              <Select value={sessionType} onValueChange={setSessionType}>
                <SelectTrigger>
                  <SelectValue placeholder="Type sessie" />
                </SelectTrigger>
                <SelectContent>
                  {TYPES.map(t => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button onClick={handleConfirm} className="w-full" disabled={!clientName || !sessionType}>
                Bevestigen
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AgendaDemo;
