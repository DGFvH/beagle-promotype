import { useState } from "react";
import { LayoutDashboard, Receipt, ShieldCheck, CalendarDays, Building, FileCheck, Lock, CheckCircle2 } from "lucide-react";

const tabs = [
  { id: "dashboard", label: "Altijd overzicht", subtitle: "Dashboard", icon: LayoutDashboard },
  { id: "invoicing", label: "Automatische Facturatie", subtitle: "Financiën", icon: Receipt },
  { id: "security", label: "Veilig & Vertrouwd", subtitle: "Data & Privacy", icon: ShieldCheck },
] as const;

type TabId = (typeof tabs)[number]["id"];

/* ── Mockup panels ── */

const DashboardMockup = () => (
  <div className="relative rounded-2xl border border-white/20 bg-white/70 p-6 shadow-xl backdrop-blur-xl dark:bg-card/70">
    {/* browser dots */}
    <div className="mb-4 flex items-center gap-2">
      <div className="h-2.5 w-2.5 rounded-full bg-destructive/50" />
      <div className="h-2.5 w-2.5 rounded-full bg-accent/50" />
      <div className="h-2.5 w-2.5 rounded-full bg-primary/50" />
    </div>

    {/* stat cards */}
    <div className="mb-4 grid grid-cols-3 gap-3">
      {[
        { label: "Sessies vandaag", value: "3" },
        { label: "Open facturen", value: "5" },
        { label: "Nieuwe cliënten", value: "2" },
      ].map((s) => (
        <div key={s.label} className="rounded-xl bg-secondary/60 p-3 text-center">
          <p className="text-lg font-bold text-foreground">{s.value}</p>
          <p className="text-[10px] text-muted-foreground">{s.label}</p>
        </div>
      ))}
    </div>

    {/* calendar snippet */}
    <div className="mb-3 flex items-center gap-2">
      <CalendarDays className="h-4 w-4 text-primary" />
      <span className="text-xs font-semibold text-foreground">Vandaag</span>
    </div>
    <div className="space-y-2">
      {["09:00 — Lisa de Vries", "11:00 — Mark Jansen", "14:30 — Sophie Bakker"].map((t) => (
        <div key={t} className="flex items-center gap-2 rounded-lg bg-primary/5 px-3 py-2">
          <div className="h-2 w-2 rounded-full bg-primary" />
          <span className="text-xs text-foreground">{t}</span>
        </div>
      ))}
    </div>

    {/* floating badge */}
    <div className="absolute -right-3 -top-3 rounded-full border border-white/20 bg-primary/90 px-3 py-1 text-[10px] font-bold text-primary-foreground shadow-lg">
      3 sessies vandaag
    </div>
  </div>
);

const InvoiceMockup = () => (
  <div className="relative rounded-2xl border border-white/20 bg-white/70 p-6 shadow-xl backdrop-blur-xl dark:bg-card/70">
    <div className="mb-4 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Receipt className="h-5 w-5 text-primary" />
        <span className="text-sm font-bold text-foreground">Factuur #1042</span>
      </div>
      <span className="rounded-full bg-primary/15 px-2.5 py-0.5 text-[10px] font-semibold text-primary">Verzonden</span>
    </div>

    {/* line items */}
    <div className="mb-4 space-y-2 text-xs">
      {[
        { desc: "Coachsessie — 60 min", amount: "€ 95,00" },
        { desc: "Intake gesprek", amount: "€ 75,00" },
        { desc: "Trajectory-rapport", amount: "€ 45,00" },
      ].map((item) => (
        <div key={item.desc} className="flex justify-between border-b border-border/50 pb-1.5">
          <span className="text-muted-foreground">{item.desc}</span>
          <span className="font-medium text-foreground">{item.amount}</span>
        </div>
      ))}
    </div>

    <div className="mb-4 flex justify-between text-sm font-bold text-foreground">
      <span>Totaal</span>
      <span>€ 215,00</span>
    </div>

    <div className="flex items-center gap-3">
      <div className="flex items-center gap-1.5 rounded-lg bg-secondary px-3 py-1.5">
        <span className="text-[10px] font-semibold text-foreground">iDEAL</span>
      </div>
      <div className="flex items-center gap-1.5 rounded-lg bg-secondary px-3 py-1.5">
        <span className="text-[10px] font-semibold text-foreground">Stripe</span>
      </div>
    </div>

    <div className="absolute -right-3 -top-3 rounded-full border border-white/20 bg-accent/90 px-3 py-1 text-[10px] font-bold text-accent-foreground shadow-lg">
      Auto-verzonden
    </div>
  </div>
);

const SecurityMockup = () => (
  <div className="relative rounded-2xl border border-white/20 bg-white/70 p-6 shadow-xl backdrop-blur-xl dark:bg-card/70">
    <div className="mb-5 flex items-center gap-2">
      <Lock className="h-5 w-5 text-primary" />
      <span className="text-sm font-bold text-foreground">Beveiliging & Compliance</span>
    </div>

    <div className="grid grid-cols-2 gap-3">
      {[
        { icon: ShieldCheck, label: "Veilige opslag", sub: "Versleuteld" },
        { icon: Building, label: "KVK", sub: "Geïntegreerd" },
        { icon: FileCheck, label: "BTW-conform", sub: "Automatisch" },
        { icon: Lock, label: "256-bit SSL", sub: "Versleuteld" },
      ].map((item) => (
        <div key={item.label} className="flex items-start gap-2 rounded-xl bg-primary/5 p-3">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          <div>
            <p className="text-xs font-semibold text-foreground">{item.label}</p>
            <p className="text-[10px] text-muted-foreground">{item.sub}</p>
          </div>
        </div>
      ))}
    </div>

    <div className="absolute -right-3 -top-3 flex items-center gap-1 rounded-full border border-white/20 bg-primary/90 px-3 py-1 shadow-lg">
      <ShieldCheck className="h-3 w-3 text-primary-foreground" />
      <span className="text-[10px] font-bold text-primary-foreground">100% veilig</span>
    </div>
  </div>
);

const mockups: Record<TabId, React.FC> = {
  dashboard: DashboardMockup,
  invoicing: InvoiceMockup,
  security: SecurityMockup,
};

const ZigzagSection = () => {
  const [active, setActive] = useState<TabId>("dashboard");
  const ActiveMockup = mockups[active];

  return (
    <section id="zigzag" className="py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <h2 className="mb-12 text-center font-heading text-3xl font-bold text-foreground sm:text-4xl">
          Ontworpen voor de moderne coach.
        </h2>

        <div className="grid items-start gap-8 md:grid-cols-[280px_1fr]">
          {/* Tabs — horizontal pills on mobile, vertical on desktop */}
          <div className="flex gap-2 overflow-x-auto md:flex-col md:gap-1 md:overflow-visible">
            {tabs.map((tab) => {
              const isActive = active === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActive(tab.id)}
                  className={`flex shrink-0 items-center gap-3 rounded-xl px-4 py-3 text-left transition-all duration-200 ${
                    isActive
                      ? "border-l-0 md:border-l-4 border-primary bg-primary/5 shadow-sm"
                      : "hover:bg-secondary/60"
                  }`}
                >
                  <tab.icon className={`h-5 w-5 shrink-0 ${isActive ? "text-primary" : "text-muted-foreground"}`} />
                  <div>
                    <p className={`text-sm font-semibold ${isActive ? "text-foreground" : "text-muted-foreground"}`}>
                      {tab.label}
                    </p>
                    <p className="text-[11px] text-muted-foreground">{tab.subtitle}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Mockup area */}
          <div className="relative min-h-[320px]">
            <div key={active} className="animate-in fade-in duration-300">
              <ActiveMockup />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ZigzagSection;
