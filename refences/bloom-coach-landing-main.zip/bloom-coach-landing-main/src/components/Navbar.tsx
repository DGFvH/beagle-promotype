import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";
import bloomIcon from "@/assets/bloom-icon.png";

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-card/80 backdrop-blur-lg">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <button onClick={() => scrollTo("hero")} className="flex items-center gap-2">
          <img src={bloomIcon} alt="Bloom" className="h-7 w-7" />
          <span className="font-logo text-2xl font-extrabold tracking-[0.05em] text-foreground">BLOOM</span>
          <span className="hidden sm:inline text-muted-foreground/50">|</span>
          <span className="hidden sm:inline font-body text-xs sm:text-sm text-muted-foreground">Makkelijker coachen</span>
        </button>

        <div className="hidden items-center gap-6 md:flex">
          <button onClick={() => scrollTo("features")} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Functionaliteiten</button>
          <button onClick={() => scrollTo("zigzag")} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Voor wie</button>
          <button onClick={() => scrollTo("cta")} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">Prijzen</button>
        </div>

        <div className="hidden items-center gap-3 md:flex">
          <Button variant="ghost" size="sm">Inloggen</Button>
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">Probeer 30 dagen gratis</Button>
        </div>

        <button className="md:hidden text-foreground" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {mobileOpen && (
        <div className="border-t border-border md:hidden bg-card px-4 pb-4 pt-2 space-y-3">
          <button onClick={() => scrollTo("features")} className="block w-full text-left text-sm font-medium text-muted-foreground py-3">Functionaliteiten</button>
          <button onClick={() => scrollTo("zigzag")} className="block w-full text-left text-sm font-medium text-muted-foreground py-3">Voor wie</button>
          <button onClick={() => scrollTo("cta")} className="block w-full text-left text-sm font-medium text-muted-foreground py-3">Prijzen</button>
          <div className="flex gap-2 pt-2">
            <Button variant="ghost" size="sm" className="flex-1">Inloggen</Button>
            <Button size="sm" className="flex-1">Probeer 30 dagen gratis</Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
