import { CalendarDays, Users, Receipt } from "lucide-react";

const pillars = [
  {
    icon: CalendarDays,
    title: "Slimme Agenda & Boekingen",
    text: "Laat cliënten zelf hun sessie boeken op basis van jouw realtime beschikbaarheid. Synchroniseert direct met Google & Outlook agenda's. Inclusief automatische herinneringen.",
    cardClass: "bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20",
    iconBg: "bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground",
  },
  {
    icon: Users,
    title: "Centraal Cliëntbeheer",
    text: "Houd al je cliëntgegevens, sessiegeschiedenis en factuurstatus bij in één overzicht. Geen losse spreadsheets meer.",
    cardClass: "bg-gradient-to-br from-accent/5 to-accent/10 border-accent/20",
    iconBg: "bg-accent/10 text-accent group-hover:bg-accent group-hover:text-accent-foreground",
  },
  {
    icon: Receipt,
    title: "Geautomatiseerde Financiën",
    text: "Facturen worden automatisch aangemaakt en verstuurd na een sessie. Inclusief iDEAL betaallinks via Stripe en automatische betalingsherinneringen.",
    cardClass: "bg-gradient-to-br from-emerald-50 to-emerald-100/50 border-emerald-200/40",
    iconBg: "bg-emerald-100 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white",
  },
];

const PillarsSection = () => {
  return (
    <section id="features" className="bg-secondary/50 py-20">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <h2 className="mb-12 text-center font-heading text-3xl font-bold text-foreground sm:text-4xl">
          Alles wat je nodig hebt, in één platform.
        </h2>

        <div className="grid gap-6 md:grid-cols-3">
          {pillars.map((p) => (
            <div
              key={p.title}
              className={`group flex flex-col rounded-2xl border p-8 shadow-md transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl ${p.cardClass}`}
            >
              <div className={`mb-5 flex h-16 w-16 items-center justify-center rounded-2xl transition-colors ${p.iconBg}`}>
                <p.icon className="h-7 w-7" />
              </div>
              <h3 className="mb-3 font-heading text-xl font-bold text-foreground">{p.title}</h3>
              <p className="leading-relaxed text-muted-foreground">{p.text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PillarsSection;
