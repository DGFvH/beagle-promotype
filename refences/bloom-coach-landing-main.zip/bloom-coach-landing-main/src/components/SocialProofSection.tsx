import { CheckCircle2 } from "lucide-react";
import testimonialEva from "@/assets/testimonial-eva.jpeg";
import testimonialMark from "@/assets/testimonial-mark.jpg";

const logos = ["NOBCO", "ICF", "Noloc", "LVSC", "Beroepsvereniging"];

const testimonials = [
  {
    photo: testimonialEva,
    name: "Eva de Groot",
    title: "Loopbaancoach in Amsterdam",
    quote: "Sinds ik Bloom gebruik, heb ik weer ruimte in mijn week voor wat echt telt.",
  },
  {
    photo: testimonialMark,
    name: "Mark Janssen",
    title: "Business Coach",
    quote: "De automatisering van Bloom voelt niet als een robot, maar als een assistent die mijn cliënten de aandacht geeft die ze verdienen.",
  },
];

const stats = [
  "10+ uur bespaard per week",
  "Betrouwbare data-opslag",
  "Automatische iDEAL-betalingen",
];

const SocialProofSection = () => (
  <section className="bg-[#FDFBF5]">
    {/* Trust Bar */}
    <div className="bg-[#FAF9F6] py-6">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <p className="mb-4 text-center text-xs text-muted-foreground tracking-wide">
          Vertrouwd door coaches aangesloten bij
        </p>
        <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-10">
          {logos.map((l) => (
            <span key={l} className="text-sm font-semibold opacity-30 select-none sm:text-base">
              {l}
            </span>
          ))}
        </div>
      </div>
    </div>

    {/* Testimonial Grid */}
    <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6 sm:py-20 lg:px-8">
      <div className="grid gap-6 sm:grid-cols-2">
        {testimonials.map((t) => (
          <div
            key={t.name}
            className="flex flex-col rounded-2xl bg-white p-6 sm:p-8 shadow-[0_2px_20px_-4px_rgba(0,0,0,0.06)]"
          >
            <blockquote className="mb-6 flex-1 font-heading text-lg italic leading-relaxed text-foreground sm:text-xl">
              "{t.quote}"
            </blockquote>
            <div className="flex items-center gap-3">
              <img
                src={t.photo}
                alt={t.name}
                className="h-12 w-12 rounded-full object-cover"
              />
              <div>
                <p className="text-sm font-semibold text-foreground">{t.name}</p>
                <p className="text-xs text-muted-foreground">{t.title}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Impact Stats */}
      <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-muted-foreground">
        {stats.map((s) => (
          <span key={s} className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-[#5B9E8F]" />
            {s}
          </span>
        ))}
      </div>
    </div>
  </section>
);

export default SocialProofSection;
