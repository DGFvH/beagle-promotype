import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const CtaSection = () => {
  return (
    <section id="cta" className="relative overflow-hidden bg-[hsl(39,30%,94%)] py-14 sm:py-20">
      <div className="relative mx-auto max-w-3xl px-4 text-center sm:px-6">
        <h2 className="font-heading text-2xl font-bold text-foreground sm:text-3xl md:text-4xl">
          Meer tijd voor je cliënten, minder tijd achter je bureau.
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground sm:text-lg">
          Probeer Bloom 30 dagen gratis. Agenda, facturatie en cliëntoverzicht — alles geregeld.
        </p>
        <Button
          size="lg"
          className="mt-8 w-full gap-2 bg-primary text-primary-foreground hover:bg-primary/90 text-base px-10 py-6 rounded-xl shadow-lg sm:w-auto"
        >
          Probeer 30 dagen gratis
          <ArrowRight className="h-5 w-5" />
        </Button>
      </div>
    </section>
  );
};

export default CtaSection;
