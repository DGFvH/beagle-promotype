import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

const PrijzenPage = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <main className="py-20">
      <div className="mx-auto max-w-3xl px-4 text-center">
        <h1 className="font-heading text-3xl font-bold text-foreground sm:text-4xl">Eenvoudige, eerlijke prijzen</h1>
        <p className="mt-4 text-muted-foreground">
          Probeer Bloom 30 dagen gratis. Geen creditcard nodig.
        </p>

        <div className="mx-auto mt-12 max-w-sm rounded-2xl border border-border bg-card p-8 shadow-lg">
          <p className="text-sm font-semibold text-primary">Bloom Pro</p>
          <p className="mt-2 font-heading text-4xl font-bold text-foreground">
            €29<span className="text-lg font-normal text-muted-foreground">/maand</span>
          </p>
          <ul className="mt-6 space-y-3 text-left">
            {[
              "Online boekingspagina",
              "Google & Outlook sync",
              "Automatische facturatie",
              "iDEAL & creditcard betaallinks",
              "Cliëntoverzicht",
              "Automatische herinneringen",
            ].map(f => (
              <li key={f} className="flex items-center gap-2 text-sm text-foreground">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-primary" />
                {f}
              </li>
            ))}
          </ul>
          <Button className="mt-8 w-full rounded-xl py-5 text-base">
            Probeer 30 dagen gratis
          </Button>
        </div>
      </div>
    </main>
    <Footer />
  </div>
);

export default PrijzenPage;
