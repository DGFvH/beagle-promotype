import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const VoorwaardenPage = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <main className="py-20">
      <div className="mx-auto max-w-2xl px-4">
        <h1 className="font-heading text-3xl font-bold text-foreground sm:text-4xl">Algemene Voorwaarden</h1>
        <p className="mt-4 text-muted-foreground">
          De algemene voorwaarden van Bloom worden binnenkort gepubliceerd. Hier vind je straks informatie over gebruiksvoorwaarden, aansprakelijkheid en je rechten als gebruiker.
        </p>
        <p className="mt-4 text-sm text-muted-foreground">
          Vragen? Neem contact op via{" "}
          <a href="mailto:info@bloomcoach.nl" className="text-primary hover:underline">info@bloomcoach.nl</a>.
        </p>
      </div>
    </main>
    <Footer />
  </div>
);

export default VoorwaardenPage;
