import Navbar from "@/components/Navbar";
import CtaSection from "@/components/CtaSection";
import Footer from "@/components/Footer";
import ClientenDemo from "@/components/demos/ClientenDemo";
import { Users, CalendarDays, Receipt, BarChart3 } from "lucide-react";

const ClientenPage = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <main>
      {/* Feature Hero */}
      <section className="bg-primary py-20">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <span className="mb-4 inline-block rounded-full bg-white/15 px-4 py-1.5 text-sm font-bold text-primary-foreground">
            Cliëntbeheer
          </span>
          <h1 className="font-heading text-4xl font-extrabold text-primary-foreground sm:text-5xl">
            Al je cliënten overzichtelijk op één plek.
          </h1>
          <p className="mt-4 text-lg text-primary-foreground/80">
            Contactgegevens, sessiegeschiedenis en factuurstatus — alles bij de hand zonder losse spreadsheets.
          </p>
        </div>
      </section>

      {/* Demo */}
      <section className="py-16">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <ClientenDemo />
        </div>
      </section>

      {/* Details */}
      <section className="bg-[#F7F9F8] py-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-10 text-center font-heading text-3xl font-bold text-foreground">Alles wat je nodig hebt</h2>
          <div className="grid gap-8 sm:grid-cols-2">
            {[
              { icon: Users, title: "Cliëntoverzicht", desc: "Alle contactgegevens en sessiehistorie op één plek." },
              { icon: CalendarDays, title: "Gekoppeld aan je agenda", desc: "Zie direct welke sessies gepland en afgerond zijn." },
              { icon: Receipt, title: "Factuurstatus per cliënt", desc: "Bekijk openstaande en betaalde facturen per cliënt." },
              { icon: BarChart3, title: "Eenvoudig statusoverzicht", desc: "Zie in één oogopslag welke cliënten actief zijn." },
            ].map(f => (
              <div key={f.title} className="flex gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <f.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-heading text-base font-bold text-foreground">{f.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection />
    </main>
    <Footer />
  </div>
);

export default ClientenPage;
