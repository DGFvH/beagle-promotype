import Navbar from "@/components/Navbar";
import CtaSection from "@/components/CtaSection";
import Footer from "@/components/Footer";
import FinancienDemo from "@/components/demos/FinancienDemo";
import { Receipt, CreditCard, Bell, FileText } from "lucide-react";

const FinancienPage = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <main>
      {/* Feature Hero */}
      <section className="bg-primary py-20">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <span className="mb-4 inline-block rounded-full bg-white/15 px-4 py-1.5 text-sm font-bold text-primary-foreground">
            Financiën & Facturatie
          </span>
          <h1 className="font-heading text-4xl font-extrabold text-primary-foreground sm:text-5xl">
            Factureren was nog nooit zo makkelijk.
          </h1>
          <p className="mt-4 text-lg text-primary-foreground/80">
            Rond een sessie af en Bloom genereert én verstuurt automatisch de factuur naar je cliënt.
          </p>
        </div>
      </section>

      {/* Demo */}
      <section className="py-16">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <FinancienDemo />
        </div>
      </section>

      {/* Details */}
      <section className="bg-[#F7F9F8] py-20">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-10 text-center font-heading text-3xl font-bold text-foreground">Alles wat je nodig hebt</h2>
          <div className="grid gap-8 sm:grid-cols-2">
            {[
              { icon: FileText, title: "Automatische PDF's", desc: "Professionele facturen in jouw huisstijl, automatisch gegenereerd." },
              { icon: CreditCard, title: "iDEAL & creditcard", desc: "Betaallinks in elke factuurmail via Stripe-integratie." },
              { icon: Bell, title: "Herinneringen", desc: "Automatische herinneringen voor openstaande facturen." },
              { icon: Receipt, title: "Financieel overzicht", desc: "Realtime inzicht in omzet, openstaande en betaalde facturen." },
            ].map(f => (
              <div key={f.title} className="flex gap-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                  <f.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-heading text-base font-bold text-foreground">{f.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaSection />
    </main>
    <Footer />
  </div>
);

export default FinancienPage;
