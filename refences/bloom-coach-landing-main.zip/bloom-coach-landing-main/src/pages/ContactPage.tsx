import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Mail } from "lucide-react";

const ContactPage = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <main className="py-20">
      <div className="mx-auto max-w-2xl px-4 text-center">
        <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <Mail className="h-7 w-7 text-primary" />
        </div>
        <h1 className="font-heading text-3xl font-bold text-foreground sm:text-4xl">Contact</h1>
        <p className="mt-4 text-muted-foreground">
          Heb je een vraag of wil je meer weten over Bloom? Stuur ons een e-mail en we reageren zo snel mogelijk.
        </p>
        <a
          href="mailto:info@bloomcoach.nl"
          className="mt-6 inline-block rounded-xl bg-primary px-8 py-3 font-semibold text-primary-foreground shadow-lg hover:bg-primary/90 transition-colors"
        >
          info@bloomcoach.nl
        </a>
      </div>
    </main>
    <Footer />
  </div>
);

export default ContactPage;
