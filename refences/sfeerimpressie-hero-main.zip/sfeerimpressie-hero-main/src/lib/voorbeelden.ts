/**
 * The VOOR/NA showcase cases. Each entry maps to a portrait composite image in
 * /public/voorbeelden and is used both in the gallery (/voorbeelden) and on its
 * own page (/voorbeeld-1, -2, -3) for linking in e-mails.
 */
export type Voorbeeld = {
  /** URL slug, e.g. "voorbeeld-1" -> /voorbeeld-1 */
  slug: string;
  /** 1-based position, used in copy ("Voorbeeld 1") */
  num: number;
  title: string;
  /** Short supporting line under the title */
  blurb: string;
  image: string;
  alt: string;
  width: number;
  height: number;
};

export const VOORBEELDEN: Voorbeeld[] = [
  {
    slug: "voorbeeld-1",
    num: 1,
    title: "Appartement met lichte woonkamer",
    blurb:
      "Een leeg appartement krijgt een warme, neutrale inrichting die de ruimte en het lichtinval laat spreken.",
    image: "/voorbeelden/voorbeeld-1.jpg",
    alt: "Voor en na: een leeg appartement met houten vloer, na virtuele styling ingericht met een lichtgrijze hoekbank, planten en een salontafel.",
    width: 1112,
    height: 1672,
  },
  {
    slug: "voorbeeld-2",
    num: 2,
    title: "Woonhuis met open trap",
    blurb:
      "Een kale betonvloer wordt een afgewerkte woonkamer met houten vloer en een rustige groene accentwand.",
    image: "/voorbeelden/voorbeeld-2.jpg",
    alt: "Voor en na: een woonkamer met betonvloer en open trap, na virtuele styling met houten vloer, grijze bank, groene accentwand en wandtelevisie.",
    width: 1112,
    height: 1672,
  },
  {
    slug: "voorbeeld-3",
    num: 3,
    title: "Industriële loft",
    blurb:
      "Een ruwe loft met gele balk en houten wandkast wordt een uitnodigende leefruimte met behoud van het karakter.",
    image: "/voorbeelden/voorbeeld-3.jpg",
    alt: "Voor en na: een industriële loft met gele stalen balk en houten wandkast, na virtuele styling ingericht met een grijze bank, vloerkleed en planten.",
    width: 1112,
    height: 1672,
  },
];

export function getVoorbeeld(slug: string): Voorbeeld | undefined {
  return VOORBEELDEN.find((v) => v.slug === slug);
}
