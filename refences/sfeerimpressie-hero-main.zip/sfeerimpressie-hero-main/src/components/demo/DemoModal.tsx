"use client";

import { useEffect, useId, useRef, useState } from "react";
import { motion, MotionConfig } from "motion/react";
import { useDemoForm } from "./DemoFormProvider";

const RECIPIENT = "hi@tinybase.nl";

type Fields = {
  naam: string;
  makelaardij: string;
  email: string;
  telefoon: string;
  bericht: string;
};

const EMPTY: Fields = {
  naam: "",
  makelaardij: "",
  email: "",
  telefoon: "",
  bericht: "",
};

/**
 * "Demo aanvragen" pop-up. Collects the request details and hands them off to the
 * visitor's mail client, pre-addressed to hi@tinybase.nl (no backend). After
 * submitting it shows a short confirmation state. Rendered once at the app root.
 */
export function DemoModal() {
  const { isOpen, close } = useDemoForm();
  const [fields, setFields] = useState<Fields>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof Fields, string>>>({});
  const [sent, setSent] = useState(false);

  const dialogRef = useRef<HTMLDivElement>(null);
  const firstFieldRef = useRef<HTMLInputElement>(null);
  const titleId = useId();
  const descId = useId();

  // Reset to a clean form whenever the modal is (re)opened.
  useEffect(() => {
    if (isOpen) {
      setFields(EMPTY);
      setErrors({});
      setSent(false);
    }
  }, [isOpen]);

  // Lock page scroll while open. The scroll container is the <html> element
  // (it carries scroll-snap), so locking <body> alone would not stop the page
  // behind the modal from scrolling; lock both.
  useEffect(() => {
    if (!isOpen) return;
    const html = document.documentElement;
    const prevHtml = html.style.overflow;
    const prevBody = document.body.style.overflow;
    html.style.overflow = "hidden";
    document.body.style.overflow = "hidden";
    return () => {
      html.style.overflow = prevHtml;
      document.body.style.overflow = prevBody;
    };
  }, [isOpen]);

  // Move focus into the dialog on open.
  useEffect(() => {
    if (isOpen) {
      const t = setTimeout(() => firstFieldRef.current?.focus(), 60);
      return () => clearTimeout(t);
    }
  }, [isOpen]);

  // Esc to close + a simple focus trap so Tab stays within the dialog.
  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        close();
        return;
      }
      if (e.key !== "Tab") return;
      const root = dialogRef.current;
      if (!root) return;
      const focusable = root.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])',
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [isOpen, close]);

  const setField = (key: keyof Fields) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFields((f) => ({ ...f, [key]: e.target.value }));
    setErrors((prev) => (prev[key] ? { ...prev, [key]: undefined } : prev));
  };

  const validate = (): boolean => {
    const next: Partial<Record<keyof Fields, string>> = {};
    if (!fields.naam.trim()) next.naam = "Vul uw naam in.";
    if (!fields.makelaardij.trim()) next.makelaardij = "Vul uw makelaardij in.";
    if (!fields.email.trim()) {
      next.email = "Vul uw e-mailadres in.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.email.trim())) {
      next.email = "Controleer uw e-mailadres.";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const lines = [
      `Naam: ${fields.naam.trim()}`,
      `Makelaardij: ${fields.makelaardij.trim()}`,
      `E-mail: ${fields.email.trim()}`,
      fields.telefoon.trim() ? `Telefoon: ${fields.telefoon.trim()}` : null,
      "",
      fields.bericht.trim() ? fields.bericht.trim() : "Ik wil graag een demo van Sfeerimpressie aanvragen.",
    ].filter((l): l is string => l !== null);

    const subject = "Demo-aanvraag Sfeerimpressie";
    const href = `mailto:${RECIPIENT}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(lines.join("\n"))}`;
    window.location.href = href;
    setSent(true);
  };

  return (
    <MotionConfig reducedMotion="user">
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-end justify-center p-0 sm:items-center sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.2 }}
        >
            {/* Backdrop */}
            <button
              type="button"
              aria-label="Sluiten"
              onClick={close}
              className="absolute inset-0 cursor-default bg-black/55 backdrop-blur-sm"
            />

            {/* Dialog */}
            <motion.div
              ref={dialogRef}
              role="dialog"
              aria-modal="true"
              aria-labelledby={titleId}
              aria-describedby={descId}
              initial={{ opacity: 0, y: 28, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
              className="relative z-10 max-h-[92svh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-[color:var(--bg-elev)] p-6 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.5)] sm:rounded-3xl sm:p-8"
            >
              <button
                type="button"
                onClick={close}
                aria-label="Sluiten"
                className="absolute right-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full text-[color:var(--muted)] transition hover:bg-[color:var(--surface-soft)] hover:text-[color:var(--fg)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--brand)]"
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              </button>

              {sent ? (
                <div className="py-6 text-center">
                  <div className="mx-auto mb-4 inline-flex h-14 w-14 items-center justify-center rounded-full bg-[color:var(--brand-soft)] text-[color:var(--brand-deep)]">
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                  </div>
                  <h2 id={titleId} className="font-display text-2xl text-[color:var(--fg)]">
                    Bedankt voor uw aanvraag
                  </h2>
                  <p id={descId} className="mx-auto mt-2 max-w-sm text-sm text-[color:var(--muted)]">
                    Uw e-mailprogramma is geopend met de aanvraag. Verstuur de e-mail en we nemen snel contact met u op.
                  </p>
                  <button
                    type="button"
                    onClick={close}
                    className="mt-6 inline-flex items-center justify-center rounded-full bg-[color:var(--brand)] px-6 py-2.5 text-sm font-medium text-[color:var(--on-brand)] transition-colors hover:bg-[color:var(--brand-deep)]"
                  >
                    Sluiten
                  </button>
                </div>
              ) : (
                <>
                  <h2 id={titleId} className="font-display pr-8 text-2xl text-[color:var(--fg)] sm:text-3xl">
                    Demo aanvragen
                  </h2>
                  <p id={descId} className="mt-1.5 text-sm text-[color:var(--muted)]">
                    Laat uw gegevens achter, dan laten we u zien hoe Sfeerimpressie uw bezichtigingen verkoopt.
                  </p>

                  <form onSubmit={onSubmit} noValidate className="mt-6 flex flex-col gap-4">
                    <Field
                      ref={firstFieldRef}
                      label="Naam"
                      name="naam"
                      autoComplete="name"
                      value={fields.naam}
                      onChange={setField("naam")}
                      error={errors.naam}
                      required
                    />
                    <Field
                      label="Makelaardij"
                      name="makelaardij"
                      autoComplete="organization"
                      value={fields.makelaardij}
                      onChange={setField("makelaardij")}
                      error={errors.makelaardij}
                      required
                    />
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field
                        label="E-mailadres"
                        name="email"
                        type="email"
                        autoComplete="email"
                        inputMode="email"
                        value={fields.email}
                        onChange={setField("email")}
                        error={errors.email}
                        required
                      />
                      <Field
                        label="Telefoon"
                        name="telefoon"
                        type="tel"
                        autoComplete="tel"
                        inputMode="tel"
                        optional
                        value={fields.telefoon}
                        onChange={setField("telefoon")}
                      />
                    </div>
                    <TextAreaField
                      label="Bericht"
                      name="bericht"
                      optional
                      value={fields.bericht}
                      onChange={setField("bericht")}
                    />

                    <button
                      type="submit"
                      className="group mt-1 inline-flex items-center justify-center gap-2 rounded-full bg-[color:var(--brand)] px-6 py-3 text-sm font-medium text-[color:var(--on-brand)] transition-colors hover:bg-[color:var(--brand-deep)]"
                    >
                      <span>Aanvraag versturen</span>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-hover:translate-x-0.5" aria-hidden>
                        <path d="M5 12h14" />
                        <path d="m13 5 7 7-7 7" />
                      </svg>
                    </button>
                    <p className="text-center text-xs text-[color:var(--muted)]">
                      Wij gebruiken uw gegevens alleen om contact met u op te nemen.
                    </p>
                  </form>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
    </MotionConfig>
  );
}

type FieldProps = {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  error?: string;
  required?: boolean;
  optional?: boolean;
  type?: string;
  autoComplete?: string;
  inputMode?: React.HTMLAttributes<HTMLInputElement>["inputMode"];
};

function Field({
  ref,
  label,
  name,
  value,
  onChange,
  error,
  required,
  optional,
  type = "text",
  autoComplete,
  inputMode,
}: FieldProps & { ref?: React.Ref<HTMLInputElement> }) {
  const id = `demo-${name}`;
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium text-[color:var(--fg)]">
        {label}
        {optional && <span className="ml-1 font-normal text-[color:var(--muted)]">(optioneel)</span>}
      </label>
      <input
        ref={ref}
        id={id}
        name={name}
        type={type}
        autoComplete={autoComplete}
        inputMode={inputMode}
        value={value}
        onChange={onChange}
        required={required}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${id}-error` : undefined}
        className={[
          "w-full rounded-xl border bg-[color:var(--bg)] px-3.5 py-2.5 text-sm text-[color:var(--fg)] outline-none transition placeholder:text-[color:var(--muted)] focus-visible:ring-2 focus-visible:ring-[color:var(--brand)]/60",
          error ? "border-red-500/70" : "border-[color:var(--hairline)] focus-visible:border-[color:var(--brand)]",
        ].join(" ")}
      />
      {error && (
        <span id={`${id}-error`} className="text-xs text-red-600">
          {error}
        </span>
      )}
    </div>
  );
}

function TextAreaField({
  label,
  name,
  value,
  onChange,
  optional,
}: {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  optional?: boolean;
}) {
  const id = `demo-${name}`;
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium text-[color:var(--fg)]">
        {label}
        {optional && <span className="ml-1 font-normal text-[color:var(--muted)]">(optioneel)</span>}
      </label>
      <textarea
        id={id}
        name={name}
        rows={3}
        value={value}
        onChange={onChange}
        className="w-full resize-none rounded-xl border border-[color:var(--hairline)] bg-[color:var(--bg)] px-3.5 py-2.5 text-sm text-[color:var(--fg)] outline-none transition placeholder:text-[color:var(--muted)] focus-visible:border-[color:var(--brand)] focus-visible:ring-2 focus-visible:ring-[color:var(--brand)]/60"
      />
    </div>
  );
}
