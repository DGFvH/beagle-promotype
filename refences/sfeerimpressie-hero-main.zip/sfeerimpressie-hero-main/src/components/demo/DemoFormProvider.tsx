"use client";

import { createContext, useCallback, useContext, useMemo, useState } from "react";

type DemoFormContextValue = {
  isOpen: boolean;
  open: () => void;
  close: () => void;
};

const DemoFormContext = createContext<DemoFormContextValue | null>(null);

/**
 * Holds the open/close state of the "Demo aanvragen" pop-up so any button on the
 * page (header, hero, sub-pages) can trigger the same modal without prop drilling.
 * Rendered once around the app in the root layout, next to <DemoModal />.
 */
export function DemoFormProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);

  const open = useCallback(() => setIsOpen(true), []);
  const close = useCallback(() => setIsOpen(false), []);

  const value = useMemo(() => ({ isOpen, open, close }), [isOpen, open, close]);

  return <DemoFormContext.Provider value={value}>{children}</DemoFormContext.Provider>;
}

export function useDemoForm() {
  const ctx = useContext(DemoFormContext);
  if (!ctx) {
    throw new Error("useDemoForm must be used within a DemoFormProvider");
  }
  return ctx;
}
