"use client";

import { useDemoForm } from "./DemoFormProvider";

/**
 * A button that opens the shared "Demo aanvragen" pop-up. Styling is passed in by
 * the caller (header, hero, sub-pages) so it can match each context; this only
 * wires the click to the modal.
 */
export function DemoButton({
  className,
  children,
  "aria-label": ariaLabel,
}: {
  className?: string;
  children: React.ReactNode;
  "aria-label"?: string;
}) {
  const { open } = useDemoForm();
  return (
    <button type="button" onClick={open} aria-label={ariaLabel} className={className}>
      {children}
    </button>
  );
}
