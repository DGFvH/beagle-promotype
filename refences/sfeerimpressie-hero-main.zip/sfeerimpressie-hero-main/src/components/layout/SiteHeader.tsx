import Link from "next/link";
import { Logo } from "@/components/brand/Logo";
import { DemoButton } from "@/components/demo/DemoButton";

/**
 * Sticky site header: the wordmark + tagline on the left, a persistent
 * "Demo aanvragen" button on the right. Fixed over the page with a soft
 * cream-to-transparent fade so it stays legible while floating over the hero.
 * The tagline collapses to a single line on small screens so it never crowds
 * the button; it stays visible from `xs` up.
 */
export function SiteHeader() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 bg-gradient-to-b from-[color:var(--bg)]/90 via-[color:var(--bg)]/70 to-transparent backdrop-blur-[3px]">
      <div className="w-full px-5 py-3 sm:px-8 sm:py-4">
        <div className="flex w-full items-center justify-between gap-3">
          <Link
            href="/"
            aria-label="Sfeerimpressie, naar de homepagina"
            className="group flex min-w-0 items-center gap-x-3 rounded-sm transition-opacity hover:opacity-80 focus-visible:opacity-80 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[color:var(--brand)]"
          >
            <Logo />
            <span
              aria-hidden
              className="hidden h-5 w-px shrink-0 bg-[color:var(--hairline)] sm:block"
            />
            <span className="hidden min-w-0 truncate text-sm font-medium text-[color:var(--muted)] sm:block">
              Styling zonder stylist voor jouw makelaardij
            </span>
          </Link>

          <DemoButton
            aria-label="Demo aanvragen"
            className="group inline-flex shrink-0 items-center gap-2 rounded-full bg-[color:var(--brand)] px-5 py-2 text-sm font-medium text-[color:var(--on-brand)] transition-colors duration-200 hover:bg-[color:var(--brand-deep)]"
          >
            <span>Demo aanvragen</span>
            <svg
              width="15"
              height="15"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="hidden transition-transform group-hover:translate-x-0.5 sm:block"
              aria-hidden
            >
              <path d="M5 12h14" />
              <path d="m13 5 7 7-7 7" />
            </svg>
          </DemoButton>
        </div>

        {/* Mobile: the tagline as a second line so it stays visible while
            scrolling, where there is no room for it beside the wordmark. */}
        <p className="mt-1.5 truncate text-xs font-medium text-[color:var(--muted)] sm:hidden">
          Styling zonder stylist voor jouw makelaardij
        </p>
      </div>
    </header>
  );
}
