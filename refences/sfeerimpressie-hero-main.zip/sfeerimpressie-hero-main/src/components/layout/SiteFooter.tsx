import Link from "next/link";
import { Logo } from "@/components/brand/Logo";
import { DemoButton } from "@/components/demo/DemoButton";

const CONTACT_EMAIL = "hi@tinybase.nl";

/**
 * Site-wide footer. Calm paper band that grounds the page: a short, clear
 * description of what Sfeerimpressie does, simple navigation, and a friendly
 * way to get in touch. Service-minded tone, no hard sell.
 */
export function SiteFooter() {
  return (
    <footer className="border-t border-[color:var(--hairline)] bg-[color:var(--bg-elev)] px-6 py-14 sm:px-8">
      <div className="mx-auto grid w-full max-w-[1280px] gap-10 sm:grid-cols-2 lg:grid-cols-4">
        {/* Brand + what we do */}
        <div className="lg:col-span-2 lg:pr-10">
          <Logo />
          <p className="mt-4 max-w-md text-sm leading-relaxed text-[color:var(--muted)]">
            Sfeerimpressie helpt makelaars in een paar minuten laten zien wat een
            leeg of gedateerd pand kan worden — met virtuele, AI-gestuurde
            styling. Zo helpt u kopers de potentie van een woning écht voor zich
            te zien.
          </p>
        </div>

        {/* Navigation */}
        <nav aria-label="Footer-navigatie">
          <h2 className="font-display text-base text-[color:var(--fg)]">
            Op de site
          </h2>
          <ul className="mt-4 flex flex-col gap-2.5 text-sm">
            <li>
              <Link href="/" className="text-[color:var(--muted)] transition hover:text-[color:var(--fg)]">
                Home
              </Link>
            </li>
            <li>
              <Link href="/#features" className="text-[color:var(--muted)] transition hover:text-[color:var(--fg)]">
                Hoe het werkt
              </Link>
            </li>
            <li>
              <Link href="/voorbeelden" className="text-[color:var(--muted)] transition hover:text-[color:var(--fg)]">
                Voorbeelden
              </Link>
            </li>
          </ul>
        </nav>

        {/* Contact */}
        <div>
          <h2 className="font-display text-base text-[color:var(--fg)]">
            Even kennismaken?
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-[color:var(--muted)]">
            We denken graag met u mee. Stel gerust uw vraag of vraag een
            vrijblijvende demo aan.
          </p>
          <a
            href={`mailto:${CONTACT_EMAIL}`}
            className="mt-3 inline-block text-sm font-medium text-[color:var(--brand-deep)] transition hover:text-[color:var(--brand)]"
          >
            {CONTACT_EMAIL}
          </a>
          <div className="mt-4">
            <DemoButton className="inline-flex items-center gap-2 rounded-full bg-[color:var(--brand)] px-5 py-2 text-sm font-medium text-[color:var(--on-brand)] transition-colors hover:bg-[color:var(--brand-deep)]">
              Demo aanvragen
            </DemoButton>
          </div>
        </div>
      </div>

      <div className="mx-auto mt-12 flex w-full max-w-[1280px] flex-col gap-2 border-t border-[color:var(--hairline)] pt-6 text-sm text-[color:var(--muted)] sm:flex-row sm:items-center sm:justify-between">
        <p>&copy; {new Date().getFullYear()} Sfeerimpressie</p>
        <p>Met zorg gemaakt voor makelaars.</p>
      </div>
    </footer>
  );
}
