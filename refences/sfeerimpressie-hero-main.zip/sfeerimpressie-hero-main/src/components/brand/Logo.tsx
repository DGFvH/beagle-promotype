import type { SVGProps } from "react";

/**
 * The couch mark — line-art two-seater on the brand cream.
 * Uses `currentColor`, so it inherits the surrounding text color and works on
 * any background. Drawn on a 24-grid; size via width/height or font-size em.
 */
export function CouchMark({
  title,
  ...props
}: SVGProps<SVGSVGElement> & { title?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      role={title ? "img" : "presentation"}
      aria-hidden={title ? undefined : true}
      {...props}
    >
      {title ? <title>{title}</title> : null}
      <rect x="6" y="4" width="12" height="7" rx="2.4" />
      <path d="M6 8.5H5A3 3 0 0 0 2 11.5V14a2.5 2.5 0 0 0 2.5 2.5h15A2.5 2.5 0 0 0 22 14v-2.5A3 3 0 0 0 19 8.5h-1" />
      <path d="M5.5 13.5h13" />
      <path d="M6 16.5V19" />
      <path d="M18 16.5V19" />
    </svg>
  );
}

/**
 * Full wordmark: couch mark + "sfeerimpressie" in the site's DM Sans.
 * The wordmark is live text (sharp at any size, selectable) rather than a
 * rasterised banner. Pass `markOnly` to render just the icon.
 */
export function Logo({
  className = "",
  markOnly = false,
}: {
  className?: string;
  markOnly?: boolean;
}) {
  return (
    <span
      className={`inline-flex items-center gap-2 text-[color:var(--fg)] ${className}`}
    >
      <CouchMark className="h-[1.15em] w-[1.15em] shrink-0" />
      {!markOnly && (
        <span className="font-display text-[1.4rem] leading-none tracking-[-0.01em] lowercase">
          sfeerimpressie
        </span>
      )}
    </span>
  );
}
