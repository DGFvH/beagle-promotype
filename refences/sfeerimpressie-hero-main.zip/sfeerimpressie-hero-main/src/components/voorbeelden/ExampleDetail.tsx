import Image from "next/image";
import Link from "next/link";
import { DemoButton } from "@/components/demo/DemoButton";
import type { Voorbeeld } from "@/lib/voorbeelden";
import { VOORBEELDEN } from "@/lib/voorbeelden";

/**
 * Standalone presentation of a single VOOR/NA case, used by /voorbeeld-1..3.
 * Self-contained so the page reads well when opened straight from an e-mail link:
 * one large composite, a short intro, a demo CTA and links to the other cases.
 */
export function ExampleDetail({ voorbeeld }: { voorbeeld: Voorbeeld }) {
  const others = VOORBEELDEN.filter((v) => v.slug !== voorbeeld.slug);

  return (
    <main className="mx-auto w-full max-w-3xl px-5 pb-20 pt-24 sm:px-8 sm:pt-28">
      <Link
        href="/voorbeelden"
        className="inline-flex items-center gap-1.5 text-sm font-medium text-[color:var(--muted)] transition hover:text-[color:var(--fg)]"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="m15 18-6-6 6-6" />
        </svg>
        Alle voorbeelden
      </Link>

      <header className="mt-5">
        <p className="font-display text-base italic text-[color:var(--brand-deep)]">
          Voorbeeld {voorbeeld.num}
        </p>
        <h1 className="font-display mt-1.5 text-3xl leading-[1.1] text-[color:var(--fg)] sm:text-4xl">
          {voorbeeld.title}
        </h1>
        <p className="mt-3 max-w-2xl text-base text-[color:var(--muted)] sm:text-lg">
          {voorbeeld.blurb}
        </p>
      </header>

      <figure className="mt-8 overflow-hidden rounded-xl border border-[color:var(--hairline)] bg-[color:var(--bg-elev)]">
        <Image
          src={voorbeeld.image}
          alt={voorbeeld.alt}
          width={voorbeeld.width}
          height={voorbeeld.height}
          priority
          sizes="(max-width: 768px) 100vw, 768px"
          className="h-auto w-full"
        />
      </figure>

      <div className="mt-10 flex flex-col items-start gap-4 rounded-xl border border-[color:var(--hairline)] bg-[color:var(--bg-elev)] p-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="font-display text-lg text-[color:var(--fg)]">
            Dit voor uw eigen pand?
          </p>
          <p className="mt-1 text-sm text-[color:var(--muted)]">
            Vraag een demo aan en zie wat Sfeerimpressie voor uw bezichtigingen doet.
          </p>
        </div>
        <DemoButton className="inline-flex shrink-0 items-center gap-2 rounded-full bg-[color:var(--brand)] px-6 py-2.5 text-sm font-medium text-[color:var(--on-brand)] transition-colors hover:bg-[color:var(--brand-deep)]">
          Demo aanvragen
        </DemoButton>
      </div>

      <nav aria-label="Andere voorbeelden" className="mt-10 flex flex-wrap gap-3">
        {others.map((o) => (
          <Link
            key={o.slug}
            href={`/${o.slug}`}
            className="inline-flex items-center gap-1.5 rounded-full border border-[color:var(--hairline)] px-4 py-2 text-sm font-medium text-[color:var(--fg)] transition hover:bg-[color:var(--surface-soft)]"
          >
            Voorbeeld {o.num}: {o.title}
          </Link>
        ))}
      </nav>
    </main>
  );
}
