"use client";

import { ReactNode } from "react";
import { motion } from "motion/react";
import { useInView } from "./useInView";
import { BeforeAfterSlider } from "@/components/hero/BeforeAfterSlider";
import { FurnitureAnimation } from "@/components/hero/FurnitureAnimation";
import { TransformationPreview } from "@/components/hero/TransformationPreview";

type Feature = {
  id: string;
  number: string;
  eyebrow: string;
  title: ReactNode;
  body: string;
  bullets: string[];
  preview: (active: boolean) => ReactNode;
};

const features: Feature[] = [
  {
    id: "voor-na",
    number: "01",
    eyebrow: "Restyle",
    title: "Toon het verschil in één blik.",
    body:
      "Sleep over de foto en laat kopers in seconden zien hoe een leeg of gedateerd pand er gestyled uitziet, in elke gewenste stijl, van Scandinavisch tot klassiek. Geen stylist, geen wachttijd, klaar vóór uw volgende bezichtiging.",
    bullets: [
      "Originele en gestylede foto naast elkaar in één beeld",
      "Onbeperkt restylen, tot 90% goedkoper dan fysieke styling",
      "Direct te gebruiken in uw brochure of online listing",
    ],
    preview: (active) => <BeforeAfterSlider active={active} />,
  },
  {
    id: "inrichten",
    number: "02",
    eyebrow: "Inrichten",
    title: "Richt elke ruimte in zoals u die wilt presenteren.",
    body:
      "Kies uit honderden meubelstukken en presenteer elke ruimte op zijn best. Schaal, kleur en stijl passen we automatisch aan de woning aan.",
    bullets: [
      "Bibliotheek met banken, tafels, lampen en planten",
      "Eén klik, volledig ingerichte ruimte in onder de 30 seconden",
      "Realistische schaduwen en perspectief",
    ],
    preview: () => <FurnitureAnimation />,
  },
  {
    id: "ai-in-actie",
    number: "03",
    eyebrow: "AI-analyse",
    title: "Een AI die het pand écht begrijpt.",
    body:
      "Onze AI analyseert de foto in detail: afmetingen, lichtinval, indeling, materialen. Stel vragen in gewone taal en krijg onderbouwd stylingadvies dat klopt bij het pand, niet een generiek moodboard.",
    bullets: [
      "Herkent wanden, ramen, verlichting en proporties",
      "Vraag advies over kleuren, meubels of indeling, in 20+ stijlen, van Scandinavisch tot Art Deco",
      "Onderbouwt elke suggestie met wat het in de foto ziet",
    ],
    preview: (active) => <TransformationPreview active={active} />,
  },
];

export function ScrollFeatures() {
  return (
    <section
      id="features"
      aria-label="Drie manieren om de potentie van een pand te tonen"
      className="relative w-full bg-[color:var(--bg)]"
    >
      <SectionIntro />
      {features.map((feature, i) => (
        <FeatureBlock key={feature.id} feature={feature} index={i} />
      ))}
    </section>
  );
}

function SectionIntro() {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.4 });
  return (
    <div className="snap-block relative flex min-h-[100svh] items-center px-6 py-20 sm:px-8">
      <div
        ref={ref}
        className={`reveal mx-auto w-full max-w-[1280px] ${inView ? "is-visible" : ""}`}
      >
        <div className="mx-auto max-w-2xl text-center">
          <span className="font-display text-base italic text-[color:var(--brand-deep)]">
            Hoe het werkt
          </span>
          <h2 className="font-display mt-4 text-3xl leading-[1.08] text-[color:var(--fg)] sm:text-4xl lg:text-5xl">
            Drie manieren om{" "}
            <em className="italic text-[color:var(--brand-deep)]">
              de potentie van een pand
            </em>{" "}
            te tonen.
          </h2>
        </div>

        {/* Overview of the three features that follow */}
        <div className="mt-14 grid gap-6 sm:grid-cols-3">
          {features.map((f, i) => (
            <a
              key={f.id}
              href={`#${f.id}`}
              className="group flex flex-col rounded-xl border border-[color:var(--hairline)] bg-[color:var(--bg-elev)] p-6 transition hover:-translate-y-0.5 hover:border-[color:var(--brand)]/50"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <div className="flex items-center gap-3 text-[color:var(--brand-deep)]">
                <span className="font-display text-base italic">{f.number}</span>
                <span className="h-px w-8 bg-[color:var(--brand)]/40" />
                <span className="font-display text-sm italic">{f.eyebrow}</span>
              </div>
              <h3 className="font-display mt-4 text-xl leading-snug text-[color:var(--fg)]">
                {f.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-[color:var(--muted)]">
                {f.body}
              </p>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}

type FeatureBlockProps = {
  feature: Feature;
  index: number;
};

function FeatureBlock({ feature, index }: FeatureBlockProps) {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.35 });
  const flip = index % 2 === 1;

  return (
    <section
      id={feature.id}
      className="snap-block relative flex min-h-[100svh] items-center px-6 py-20 sm:px-8"
    >
      <div
        ref={ref}
        className="relative mx-auto grid w-full max-w-[1280px] grid-cols-1 items-center gap-10 lg:grid-cols-2 lg:gap-20"
      >
        {/* Decorative oversized number */}
      <span
        aria-hidden
        className={[
          "font-display pointer-events-none absolute -top-12 select-none text-[8rem] font-normal italic leading-none text-[color:var(--brand)]/[0.10] sm:text-[10rem] lg:text-[13rem]",
          flip ? "right-0" : "left-0",
        ].join(" ")}
      >
        {feature.number}
      </span>

      {/* Copy */}
      <motion.div
        initial={{ opacity: 0, x: flip ? 40 : -40 }}
        animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: flip ? 40 : -40 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className={[
          "relative z-10 flex flex-col gap-5",
          flip ? "lg:order-2" : "lg:order-1",
        ].join(" ")}
      >
        <div className="flex items-center gap-3 text-[color:var(--brand-deep)]">
          <span className="font-display text-base italic">{feature.number}</span>
          <span className="h-px w-10 bg-[color:var(--brand)]/40" />
          <span className="font-display text-sm italic">{feature.eyebrow}</span>
        </div>
        <h3 className="font-display max-w-xl text-3xl leading-[1.1] text-[color:var(--fg)] sm:text-4xl lg:text-[2.75rem]">
          {feature.title}
        </h3>
        <p className="max-w-xl text-[1.0625rem] leading-relaxed text-[color:var(--muted)]">
          {feature.body}
        </p>
        <ul className="mt-2 flex flex-col gap-3">
          {feature.bullets.map((b, i) => (
            <motion.li
              key={b}
              initial={{ opacity: 0, y: 8 }}
              animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 8 }}
              transition={{ duration: 0.5, delay: 0.3 + i * 0.1 }}
              className="flex items-start gap-3 text-sm text-[color:var(--fg)]/85"
            >
              <span className="mt-1 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-[color:var(--brand-soft)] text-[color:var(--brand)]">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <path d="M20 6 9 17l-5-5" />
                </svg>
              </span>
              <span>{b}</span>
            </motion.li>
          ))}
        </ul>
      </motion.div>

      {/* Preview */}
      <motion.div
        initial={{ opacity: 0, y: 60, scale: 0.96 }}
        animate={inView ? { opacity: 1, y: 0, scale: 1 } : { opacity: 0, y: 60, scale: 0.96 }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.15 }}
        className={[
          "relative",
          flip ? "lg:order-1" : "lg:order-2",
        ].join(" ")}
      >
        <div className="glass rounded-2xl p-3 shadow-[0_24px_60px_-36px_rgba(43,39,31,0.35)]">
          {/* Only mount the demo when we've entered the viewport — this is what makes
              each feature 'load during scrolling' rather than running at page load. */}
          {inView ? feature.preview(true) : <PreviewPlaceholder />}
        </div>
      </motion.div>
      </div>
    </section>
  );
}

function PreviewPlaceholder() {
  return (
    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-2xl border border-white/10 bg-[color:var(--bg-elev)]">
      <div className="absolute inset-0 bg-gradient-to-br from-[color:var(--brand-soft)] to-transparent" />
    </div>
  );
}
