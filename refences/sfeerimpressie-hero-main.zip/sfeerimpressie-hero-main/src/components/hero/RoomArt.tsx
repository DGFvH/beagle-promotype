"use client";

export function EmptyRoomArt() {
  return (
    <svg
      viewBox="0 0 800 600"
      preserveAspectRatio="xMidYMid slice"
      className="absolute inset-0 h-full w-full"
      aria-hidden
    >
      <defs>
        <linearGradient id="rart-empty-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#D8D2C7" />
          <stop offset="100%" stopColor="#B8AEA0" />
        </linearGradient>
        <linearGradient id="rart-empty-floor" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#8C7C68" />
          <stop offset="100%" stopColor="#5C4F3F" />
        </linearGradient>
        <linearGradient id="rart-empty-window" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#E9ECF1" />
          <stop offset="100%" stopColor="#C8CFD8" />
        </linearGradient>
      </defs>
      <rect width="800" height="420" fill="url(#rart-empty-wall)" />
      <rect y="420" width="800" height="180" fill="url(#rart-empty-floor)" />
      <rect y="412" width="800" height="10" fill="#3D332B" opacity="0.5" />
      <rect x="120" y="100" width="220" height="240" fill="url(#rart-empty-window)" stroke="#8a8275" strokeWidth="6" />
      <line x1="230" y1="100" x2="230" y2="340" stroke="#8a8275" strokeWidth="4" />
      <line x1="120" y1="220" x2="340" y2="220" stroke="#8a8275" strokeWidth="4" />
      <rect x="560" y="380" width="14" height="20" fill="#3D332B" opacity="0.55" rx="2" />
      <g stroke="#3D332B" strokeWidth="1" opacity="0.18">
        <line x1="0" y1="460" x2="800" y2="460" />
        <line x1="0" y1="500" x2="800" y2="500" />
        <line x1="0" y1="540" x2="800" y2="540" />
      </g>
      <polygon points="120,340 340,340 460,600 60,600" fill="white" opacity="0.06" />
    </svg>
  );
}

export function FurnishedRoomArt() {
  return (
    <svg
      viewBox="0 0 800 600"
      preserveAspectRatio="xMidYMid slice"
      className="absolute inset-0 h-full w-full"
      aria-hidden
    >
      <defs>
        <linearGradient id="rart-furn-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2C2A3A" />
          <stop offset="100%" stopColor="#1A1828" />
        </linearGradient>
        <linearGradient id="rart-furn-floor" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3C2E20" />
          <stop offset="100%" stopColor="#1F170E" />
        </linearGradient>
        <linearGradient id="rart-furn-window" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F3B574" />
          <stop offset="100%" stopColor="#C77848" />
        </linearGradient>
        <linearGradient id="rart-sofa" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#7A5C3D" />
          <stop offset="100%" stopColor="#4F3A24" />
        </linearGradient>
        <radialGradient id="rart-lamp-glow" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor="#FFE3B0" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#FFE3B0" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="800" height="420" fill="url(#rart-furn-wall)" />
      <rect y="420" width="800" height="180" fill="url(#rart-furn-floor)" />
      <rect y="414" width="800" height="8" fill="#0F0B07" opacity="0.6" />
      <rect x="120" y="100" width="220" height="240" fill="url(#rart-furn-window)" stroke="#1A1828" strokeWidth="6" />
      <line x1="230" y1="100" x2="230" y2="340" stroke="#1A1828" strokeWidth="4" />
      <line x1="120" y1="220" x2="340" y2="220" stroke="#1A1828" strokeWidth="4" />
      <polygon points="120,340 340,340 500,600 40,600" fill="#F3B574" opacity="0.12" />
      <ellipse cx="480" cy="510" rx="260" ry="48" fill="#8A4A3A" opacity="0.85" />
      <ellipse cx="480" cy="510" rx="220" ry="36" fill="#A85A45" opacity="0.55" />
      <g>
        <rect x="380" y="350" width="280" height="120" fill="url(#rart-sofa)" rx="12" />
        <rect x="380" y="345" width="280" height="40" fill="#8A6A48" rx="10" />
        <rect x="395" y="380" width="80" height="60" fill="#A07B54" rx="8" />
        <rect x="485" y="380" width="80" height="60" fill="#A07B54" rx="8" />
        <rect x="575" y="380" width="80" height="60" fill="#A07B54" rx="8" />
        <rect x="380" y="465" width="20" height="40" fill="#2A1D10" rx="3" />
        <rect x="640" y="465" width="20" height="40" fill="#2A1D10" rx="3" />
        <rect x="400" y="358" width="50" height="36" fill="#D88A55" rx="6" />
        <rect x="610" y="358" width="50" height="36" fill="#D8B25A" rx="6" />
      </g>
      <g>
        <rect x="710" y="200" width="6" height="240" fill="#2A1D10" />
        <rect x="700" y="430" width="26" height="8" fill="#2A1D10" rx="2" />
        <path d="M685 200 L741 200 L725 150 L701 150 Z" fill="#F2D9A9" />
        <circle cx="713" cy="200" r="90" fill="url(#rart-lamp-glow)" />
      </g>
      <rect x="430" y="490" width="120" height="20" fill="#1F170E" rx="3" />
      <rect x="500" y="140" width="120" height="120" fill="#3F2A45" stroke="#1A1828" strokeWidth="4" />
      <circle cx="540" cy="190" r="14" fill="#F2A65A" />
      <rect x="520" y="220" width="80" height="6" fill="#F2A65A" opacity="0.6" />
      <rect x="530" y="232" width="60" height="6" fill="#F2A65A" opacity="0.4" />
    </svg>
  );
}
