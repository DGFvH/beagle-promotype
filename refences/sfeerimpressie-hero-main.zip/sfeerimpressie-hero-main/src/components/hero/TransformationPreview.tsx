"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";

const ANALYSIS_TEXT =
  "Deze ruimte is circa 15m² met goed daglicht — uitstekend geschikt als kantoor of als compacte tweede slaapkamer. De kastruimte is beperkt; inbouwkasten zijn een logische oplossing. Zal ik een preview maken in een stijl die aansluit bij de rest van de woning?";

// Timeline (seconds) for one full cycle
const T = {
  scanStart: 0.66,
  scanEnd: 2.86,
  panelIn: 3.08,
  typeStart: 3.74,
  typeCharMs: 24.2, // ms per character
};

const TYPE_DURATION_S = (ANALYSIS_TEXT.length * T.typeCharMs) / 1000;
const TYPE_END = T.typeStart + TYPE_DURATION_S;
const HOLD_S = 4.4;
const CYCLE = TYPE_END + HOLD_S;

type Props = { active?: boolean; aspectClass?: string; framed?: boolean };

export function TransformationPreview({
  active = true,
  aspectClass = "aspect-[16/10] w-full",
  framed = true,
}: Props) {
  const [t, setT] = useState(0);

  useEffect(() => {
    if (!active) return;
    if (typeof window === "undefined") return;
    const reduced = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setT(TYPE_END); // jump to finished state
      return;
    }

    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const elapsed = ((now - start) / 1000) % CYCLE;
      setT(elapsed);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active]);

  const scanning = t >= T.scanStart && t < T.scanEnd;
  const scanProgress = scanning ? (t - T.scanStart) / (T.scanEnd - T.scanStart) : 0;
  const scanY = scanning ? scanProgress * 100 : scanProgress >= 1 ? 100 : -10;

  const panelVisible = t >= T.panelIn;

  const charsShown = (() => {
    if (t < T.typeStart) return 0;
    if (t >= TYPE_END) return ANALYSIS_TEXT.length;
    return Math.floor(((t - T.typeStart) * 1000) / T.typeCharMs);
  })();
  const typedText = ANALYSIS_TEXT.slice(0, charsShown);
  const typing = t >= T.typeStart && t < TYPE_END;
  const typingDone = t >= TYPE_END;

  const stepLabel = (() => {
    if (t < T.scanStart) return null;
    if (t < T.scanEnd) return "Ruimte analyseren…";
    if (t < T.typeStart) return "Advies opstellen…";
    if (t < TYPE_END) return "Antwoord genereren…";
    return "Klaar";
  })();

  return (
    <div className={`relative ${aspectClass} overflow-hidden bg-[#E7E0D3] ${framed ? "rounded-2xl border border-white/10 shadow-2xl" : ""}`}>
      {/* Office room photo — base layer */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/graphics/office-room.png"
        alt="Lege kamer die door de AI geanalyseerd wordt"
        draggable={false}
        className="pointer-events-none absolute inset-0 h-full w-full select-none object-cover"
      />

      {/* Subtle vignette to keep UI elements legible on top of the photo */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "linear-gradient(180deg, rgba(0,0,0,0.25) 0%, rgba(0,0,0,0) 30%, rgba(0,0,0,0) 60%, rgba(0,0,0,0.35) 100%)",
        }}
      />

      {/* Scanning gradient line */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 h-[2px] transition-opacity"
        style={{
          top: `${scanY}%`,
          opacity: scanning ? 1 : 0,
          background:
            "linear-gradient(90deg, transparent 0%, rgba(242,166,90,0) 8%, rgba(242,166,90,0.95) 50%, rgba(242,166,90,0) 92%, transparent 100%)",
          boxShadow: "0 0 18px 2px rgba(242,166,90,0.55)",
        }}
      />
      {/* Scan trail (soft) */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 transition-opacity"
        style={{
          top: `${Math.max(0, scanY - 6)}%`,
          height: "6%",
          opacity: scanning ? 0.4 : 0,
          background: "linear-gradient(to bottom, transparent, rgba(242,166,90,0.18))",
        }}
      />

      {/* Detection markers — appear briefly when the scan passes over them */}
      <DetectionMarker x="67%" y="32%" label="Raam" appearAt={scanProgress > 0.25} />
      <DetectionMarker x="41%" y="80%" label="Vloer" appearAt={scanProgress > 0.6} />
      <DetectionMarker x="40%" y="55%" label="Wand" appearAt={scanProgress > 0.4} />

      {/* AI corner pill */}
      <div
        className="pointer-events-none absolute right-3 top-3 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider"
        style={{
          background: "var(--brand)",
          color: "#1a0f06",
        }}
      >
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M12 2v4M12 18v4M4 12H2M22 12h-2M6 6 4 4M20 20l-2-2M6 18l-2 2M20 4l-2 2" />
          <circle cx="12" cy="12" r="4" />
        </svg>
        AI
      </div>

      {/* Step label, top-left */}
      <AnimatePresence mode="wait">
        {stepLabel && (
          <motion.span
            key={stepLabel}
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 4 }}
            transition={{ duration: 0.3 }}
            className="absolute left-3 top-3 rounded-full bg-black/55 px-2.5 py-1 text-[11px] font-medium text-white/90 backdrop-blur"
          >
            {stepLabel}
          </motion.span>
        )}
      </AnimatePresence>

      {/* Analysis panel — slides in from the right covering ~50% of the preview */}
      <AnimatePresence>
        {panelVisible && (
          <motion.div
            key="analysis-panel"
            initial={{ x: "105%", opacity: 0 }}
            animate={{ x: "0%", opacity: 1 }}
            exit={{ x: "105%", opacity: 0 }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="absolute inset-y-3 right-3 flex w-[calc(50%-0.75rem)] flex-col gap-3 rounded-xl border border-white/15 bg-black/65 p-4 text-white backdrop-blur-md shadow-[0_24px_60px_-20px_rgba(0,0,0,0.6)]"
          >
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[color:var(--brand)] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#1a0f06]">
                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <path d="M12 2v4M12 18v4M4 12H2M22 12h-2M6 6 4 4M20 20l-2-2M6 18l-2 2M20 4l-2 2" />
                  <circle cx="12" cy="12" r="4" />
                </svg>
                AI-analyse
              </span>
              {!typingDone && (
                <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-wider text-white/55">
                  <span className="relative inline-flex h-1.5 w-1.5">
                    <span className="relative inline-block h-1.5 w-1.5 rounded-full bg-[color:var(--brand)]" />
                  </span>
                  Aan het denken
                </span>
              )}
            </div>

            <p className="min-h-0 flex-1 overflow-hidden text-[15px] leading-[1.5] text-white/92">
              {typedText}
              {typing && <BlinkingCaret />}
            </p>

            <AnimatePresence>
              {typingDone && (
                <motion.div
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35 }}
                  className="flex flex-wrap gap-2"
                >
                  <button
                    type="button"
                    className="inline-flex items-center gap-1.5 rounded-full bg-[color:var(--brand)] px-3 py-1.5 text-[11px] font-semibold text-[#1a0f06] shadow-[0_8px_22px_-8px_rgba(242,166,90,0.55)]"
                  >
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                      <path d="M20 6 9 17l-5-5" />
                    </svg>
                    Ja, maak preview
                  </button>
                  <button
                    type="button"
                    className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-white/85"
                  >
                    Andere stijl
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Progress bar */}
      <div className="absolute inset-x-0 bottom-0 h-1 bg-white/10">
        <div
          className="h-full origin-left bg-gradient-to-r from-[color:var(--brand)] to-[color:var(--brand-deep)]"
          style={{ transform: `scaleX(${Math.min(1, t / TYPE_END)})` }}
        />
      </div>

      {/* CSS keyframes */}
      <style>{`
        @keyframes caret-blink {
          0%, 49% { opacity: 1; }
          50%, 100% { opacity: 0; }
        }
      `}</style>
    </div>
  );
}

function BlinkingCaret() {
  return (
    <span
      aria-hidden
      className="ml-0.5 inline-block h-[1em] w-[2px] translate-y-[2px] bg-[color:var(--brand)] align-baseline"
      style={{ animation: "caret-blink 1s steps(1) infinite" }}
    />
  );
}

function DetectionMarker({
  x,
  y,
  label,
  appearAt,
}: {
  x: string;
  y: string;
  label: string;
  appearAt: boolean;
}) {
  return (
    <AnimatePresence>
      {appearAt && (
        <motion.div
          initial={{ opacity: 0, scale: 0.6 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.6 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2"
          style={{ left: x, top: y }}
        >
          <span className="relative flex items-center gap-1.5">
            <span className="relative inline-flex h-2.5 w-2.5">
              <span className="relative inline-block h-2.5 w-2.5 rounded-full border-2 border-white bg-[color:var(--brand)]" />
            </span>
            <span className="rounded-full bg-black/65 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wider text-white/90 backdrop-blur">
              {label}
            </span>
          </span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
