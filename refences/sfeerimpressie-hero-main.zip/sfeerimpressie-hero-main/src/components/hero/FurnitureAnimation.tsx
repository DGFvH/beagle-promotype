"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "motion/react";

/**
 * FurnitureAnimation — purely visual looping demo.
 *
 * Drags four furniture icons from a strip below into a room image, one by one,
 * crossfading the room image from frame-0 (empty) through frame-4 (fully
 * furnished). No user interaction.
 */

type StripItem = {
  id: string;
  emoji: string;
  label: string;
  /** Landing target inside the room, as % of room dimensions (from top-left). */
  target: { x: number; y: number };
};

// Strip order matches the animation order: rug → sofa → tv → chair.
// Targets are tuned for a 16:10 room with a floating chip tray at the bottom —
// they sit above the tray so the ghost lands on the visible floor / wall area.
const STRIP: StripItem[] = [
  { id: "rug",   emoji: "🟫", label: "Vloerkleed", target: { x: 50, y: 58 } },
  { id: "sofa",  emoji: "🛋️", label: "Hoekbank",   target: { x: 30, y: 48 } },
  { id: "tv",    emoji: "📺", label: "TV-meubel",  target: { x: 72, y: 45 } },
  { id: "chair", emoji: "🪑", label: "Fauteuil",   target: { x: 72, y: 58 } },
];

// frame-4 is versioned (-v2) so the browser refetches after the source was
// re-uploaded. Rename + bump the suffix when frame-4 changes again.
const FRAME_SRCS = [
  "/graphics/frame-0.png",
  "/graphics/frame-1.png",
  "/graphics/frame-2.png",
  "/graphics/frame-3.png",
  "/graphics/frame-4-v2.png",
];

// Phase durations (ms)
const T = {
  lift: 200,
  float: 1000,
  crossfade: 500,
  exit: 200,
  hold: 800,
  finalHold: 2500,
  reset: 800,
  endPause: 1500,
};
const STEP_TOTAL_MS = T.lift + T.float + T.crossfade + T.exit + T.hold;

type Phase =
  | { kind: "step"; step: number; sub: "lift" | "float" | "crossfade" | "exit" | "hold" }
  | { kind: "final-hold" }
  | { kind: "reset" }
  | { kind: "end-pause" };

const INITIAL_PHASE: Phase = { kind: "step", step: 0, sub: "lift" };

type Coords = {
  slots: { x: number; y: number }[];
  targets: { x: number; y: number }[];
};

export function FurnitureAnimation({
  aspectClass = "aspect-[16/10] w-full",
  framed = true,
}: {
  aspectClass?: string;
  framed?: boolean;
} = {}) {
  const [phase, setPhase] = useState<Phase>(INITIAL_PHASE);
  const [frame, setFrame] = useState(0);
  const [cycleId, setCycleId] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [coords, setCoords] = useState<Coords | null>(null);

  // wrapperRef IS the room — the chip tray is overlaid inside it, so the
  // component's total size matches the other previews (a single 16:10 box).
  const wrapperRef = useRef<HTMLDivElement>(null);
  const slotRefs = useRef<(HTMLDivElement | null)[]>([]);

  // Measure slot + target positions relative to the wrapper (= room).
  const measure = useCallback(() => {
    const wrapper = wrapperRef.current;
    if (!wrapper) return;
    const wRect = wrapper.getBoundingClientRect();

    const slots = slotRefs.current.map((slot) => {
      if (!slot) return { x: 0, y: 0 };
      const s = slot.getBoundingClientRect();
      return {
        x: s.left + s.width / 2 - wRect.left,
        y: s.top + s.height / 2 - wRect.top,
      };
    });

    const targets = STRIP.map((item) => ({
      x: (wRect.width * item.target.x) / 100,
      y: (wRect.height * item.target.y) / 100,
    }));

    setCoords({ slots, targets });
  }, []);

  useEffect(() => {
    measure();
    if (!wrapperRef.current) return;
    const ro = new ResizeObserver(measure);
    ro.observe(wrapperRef.current);
    return () => ro.disconnect();
  }, [measure]);

  // prefers-reduced-motion
  useEffect(() => {
    if (typeof window === "undefined") return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReducedMotion(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  // The timeline. Waits for the first measurement, then drives a single loop
  // via chained setTimeouts. Re-fires when cycleId increments at the end.
  useEffect(() => {
    if (!coords) return;
    if (reducedMotion) {
      setFrame(4);
      setPhase({ kind: "final-hold" });
      return;
    }

    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const at = (ms: number, fn: () => void) => {
      timeouts.push(setTimeout(fn, ms));
    };

    let t = 0;
    for (let s = 0; s < 4; s++) {
      const start = t;
      at(start, () => setPhase({ kind: "step", step: s, sub: "lift" }));
      at(start + T.lift, () => setPhase({ kind: "step", step: s, sub: "float" }));
      at(start + T.lift + T.float, () => {
        setPhase({ kind: "step", step: s, sub: "crossfade" });
        setFrame(s + 1);
      });
      at(start + T.lift + T.float + T.crossfade, () =>
        setPhase({ kind: "step", step: s, sub: "exit" }),
      );
      at(start + T.lift + T.float + T.crossfade + T.exit, () =>
        setPhase({ kind: "step", step: s, sub: "hold" }),
      );
      t += STEP_TOTAL_MS;
    }
    at(t, () => setPhase({ kind: "final-hold" }));
    t += T.finalHold;
    at(t, () => {
      setPhase({ kind: "reset" });
      setFrame(0);
    });
    t += T.reset;
    at(t, () => setPhase({ kind: "end-pause" }));
    t += T.endPause;
    at(t, () => setCycleId((c) => c + 1));

    return () => {
      for (const id of timeouts) clearTimeout(id);
    };
    // We intentionally do NOT include `coords` here — measuring should not
    // restart the cycle. Initial run is gated on coords being non-null above.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cycleId, reducedMotion, coords !== null]);

  // Derived: which strip items look active vs done.
  const allActive = phase.kind === "reset" || phase.kind === "end-pause";
  const isActive = (i: number) => {
    if (allActive) return true;
    if (phase.kind !== "step") return false;
    return phase.step === i && phase.sub !== "hold";
  };
  const isDone = (i: number) => {
    if (phase.kind === "step") {
      if (phase.step > i) return true;
      if (phase.step === i && phase.sub === "hold") return true;
    }
    if (phase.kind === "final-hold") return true;
    return false;
  };

  // Cursor easing is snappier while actively dragging an item (lift|float|
  // crossfade); the rug (step 0) is excluded so the first move feels calm.
  const dragInProgress =
    phase.kind === "step" &&
    phase.step > 0 &&
    (phase.sub === "lift" || phase.sub === "float" || phase.sub === "crossfade");

  // The drag gesture itself (item held by the cursor). The zone divider +
  // number show only during this window; once the item is dropped (crossfade
  // onward) they hide and the loading wash takes over, until the next drag.
  const dragging =
    phase.kind === "step" && (phase.sub === "lift" || phase.sub === "float");

  const currentStep = phase.kind === "step" ? phase.step : -1;
  const ghostItem = currentStep >= 0 ? STRIP[currentStep] : null;

  // The rug is large, so it occupies the WHOLE picture (one region): a single
  // centred "1", no divider, and a full-width loading wash. Every other item
  // can go in either half, so they show the divider + both "1" and "2", and the
  // loading wash plays over the half it actually lands in.
  const fullRegion = currentStep >= 0 && STRIP[currentStep].id === "rug";
  const dropHalf =
    currentStep >= 0 ? (STRIP[currentStep].target.x <= 50 ? "left" : "right") : null;
  const dropLoading =
    phase.kind === "step" && (phase.sub === "crossfade" || phase.sub === "exit");

  // Where the simulated cursor should be, and how long to take getting there.
  // Tracks the ghost during the drag, otherwise parks near the upcoming slot.
  const cursorState = (() => {
    if (!coords) return null;
    const parkOffset = { x: 26, y: -6 }; // offset from slot center when parked
    if (phase.kind === "step") {
      const slot = coords.slots[phase.step];
      const target = coords.targets[phase.step];
      switch (phase.sub) {
        case "lift":
          return { x: slot.x, y: slot.y, scale: 0.88, duration: T.lift / 1000 };
        case "float":
          return { x: target.x, y: target.y, scale: 0.88, duration: T.float / 1000 };
        case "crossfade":
          return { x: target.x, y: target.y, scale: 1, duration: T.crossfade / 1000 };
        case "exit":
          return { x: target.x, y: target.y, scale: 1, duration: T.exit / 1000 };
        case "hold": {
          const next = phase.step < STRIP.length - 1 ? coords.slots[phase.step + 1] : coords.slots[0];
          return {
            x: next.x + parkOffset.x,
            y: next.y + parkOffset.y,
            scale: 1,
            duration: T.hold / 1000,
          };
        }
      }
    }
    // Off-cycle states: park near slot 0
    const slot0 = coords.slots[0];
    return {
      x: slot0.x + parkOffset.x,
      y: slot0.y + parkOffset.y,
      scale: 1,
      duration: 0.4,
    };
  })();

  return (
    <div
      ref={wrapperRef}
      className={`relative ${aspectClass} overflow-hidden bg-[#E7E0D3] ${framed ? "rounded-2xl border border-white/10 shadow-2xl" : ""}`}
    >
      {/* Frames stacked; each new frame fades in ON TOP of the previous ones
          (which stay opaque) so only the newly added furniture appears — no
          whole-image "blacken" dip, and the change reads as local to the half
          where the item landed. */}
      {FRAME_SRCS.map((src, i) => (
        <div
          key={src}
          aria-hidden={i !== frame}
          className="absolute inset-0"
          style={{
            opacity: i <= frame ? 1 : 0,
            transition: `opacity ${T.crossfade}ms ease-out`,
          }}
        >
          <Image
            src={src}
            alt={
              i === 0
                ? "Lege kamer"
                : `Kamer met ${STRIP.slice(0, i)
                    .map((s) => s.label.toLowerCase())
                    .join(", ")}`
            }
            fill
            sizes="100vw"
            priority
            className="select-none object-cover"
            draggable={false}
          />
        </div>
      ))}

      {/* White "loading" wash over the half where the current item lands —
          reads as the styled result being generated in that zone. Rendered
          before the divider/badges so those stay legible on top. */}
      <AnimatePresence>
        {dropLoading && (fullRegion || dropHalf) && (
          <motion.div
            key={`load-${cycleId}-${currentStep}`}
            aria-hidden
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="pointer-events-none absolute inset-y-0 overflow-hidden"
            style={{
              left: fullRegion ? 0 : dropHalf === "left" ? 0 : "50%",
              right: fullRegion ? 0 : dropHalf === "left" ? "50%" : 0,
            }}
          >
            <div className="absolute inset-0 bg-white/10" />
            <div
              className="absolute inset-0"
              style={{
                background:
                  "linear-gradient(100deg, transparent 20%, rgba(255,255,255,0.5) 50%, transparent 80%)",
                animation: "furn-shimmer 1.2s linear infinite",
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Drop zones — shown only during the drag (lift/float), hidden once the
          item is dropped, until the next drag. The big rug goes in the whole
          picture: a single centred "1", no divider. Every other item can go in
          either half: a thicker dashed divider + both "1" and "2". */}
      {!fullRegion && (
        <div
          aria-hidden
          className="pointer-events-none absolute inset-y-6 left-1/2 -translate-x-1/2 border-l-[3px] border-dashed"
          style={{
            borderColor: "rgba(255,255,255,0.45)",
            opacity: dragging ? 1 : 0,
            transition: "opacity 260ms ease-out",
          }}
        />
      )}
      {(fullRegion ? ["1"] : ["1", "2"]).map((n) => (
        <div
          key={n}
          aria-hidden
          className={[
            "pointer-events-none absolute top-1/2 grid h-10 w-10 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-white/40 bg-black/40 text-base font-semibold text-white/90 backdrop-blur-sm",
            fullRegion ? "left-1/2" : n === "1" ? "left-1/4" : "left-3/4",
          ].join(" ")}
          style={{
            opacity: dragging ? 1 : 0,
            transition: "opacity 260ms ease-out",
          }}
        >
          {n}
        </div>
      ))}

      {/* Floating chip tray at the bottom of the picture */}
      <div className="pointer-events-none absolute inset-x-0 bottom-3 z-10 flex justify-center px-3">
        <div className="flex items-end gap-3 rounded-2xl border border-white/15 bg-black/55 px-3 py-2 shadow-[0_18px_40px_-18px_rgba(0,0,0,0.7)] backdrop-blur-md">
          {STRIP.map((item, i) => {
            const active = isActive(i);
            const done = isDone(i);
            return (
              <div key={item.id} className="flex flex-col items-center gap-1">
                <div
                  ref={(el) => {
                    slotRefs.current[i] = el;
                  }}
                  className={[
                    "relative grid h-11 w-11 place-items-center rounded-lg border transition",
                    done && !allActive
                      ? "border-white/10 bg-white/10 opacity-30"
                      : active
                        ? "border-[color:var(--brand)] bg-white/15 ring-2 ring-[color:var(--brand)]"
                        : "border-white/10 bg-white/10",
                  ].join(" ")}
                >
                  <span className="text-lg leading-none">{item.emoji}</span>
                  {done && !allActive && (
                    <span className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-full bg-[color:var(--brand)] text-[#1a0f06] shadow">
                      <svg
                        width="9"
                        height="9"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="3.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        aria-hidden
                      >
                        <path d="M20 6 9 17l-5-5" />
                      </svg>
                    </span>
                  )}
                </div>
                <span className="whitespace-nowrap text-[10px] leading-none text-white/65">
                  {item.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Simulated cursor + the item it's carrying. The item is a CHILD of the
          cursor so it follows it exactly (no drift), and is released (faded out)
          the moment the item is dropped. */}
      {cursorState && (
        <motion.div
          initial={false}
          animate={{
            x: cursorState.x - 4,
            y: cursorState.y - 4,
            scale: cursorState.scale,
          }}
          transition={{
            duration: cursorState.duration,
            ease: dragInProgress ? [0.22, 1, 0.36, 1] : "easeOut",
          }}
          style={{ position: "absolute", left: 0, top: 0, transformOrigin: "0 0" }}
          className="pointer-events-none z-30"
          aria-hidden
        >
          {ghostItem && (
            <div
              className="absolute grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-lg border border-[color:var(--brand)] bg-white/20 shadow-[0_18px_40px_-12px_rgba(0,0,0,0.6)] backdrop-blur"
              style={{
                left: 18,
                top: 22,
                opacity: dragging ? 1 : 0,
                transition: "opacity 200ms ease-out",
              }}
            >
              <span className="text-lg leading-none">{ghostItem.emoji}</span>
            </div>
          )}
          <CursorSvg />
        </motion.div>
      )}

      <style>{`
        @keyframes furn-shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
}

function CursorSvg() {
  return (
    <svg
      width="22"
      height="26"
      viewBox="0 0 22 26"
      fill="none"
      style={{ filter: "drop-shadow(0 6px 10px rgba(0,0,0,0.45))" }}
      aria-hidden
    >
      <path
        d="M2 2 L2 20 L7 16 L10.3 23 L13.5 21.6 L10.2 14.6 L17 14 Z"
        fill="white"
        stroke="#1a0f06"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}
