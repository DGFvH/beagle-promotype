"use client";

import { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "motion/react";
import { BeforeAfterSlider } from "./BeforeAfterSlider";
import { FurnitureAnimation } from "./FurnitureAnimation";
import { TransformationPreview } from "./TransformationPreview";
import { useDemoForm } from "@/components/demo/DemoFormProvider";

const AUTO_ROTATE_MS = 10000;

// Full-width hero showcase: broad and short on larger screens, taller on mobile.
const WIDE_ASPECT = "aspect-[16/10] w-full sm:aspect-[2/1] lg:aspect-[5/2]";

const tabs = [
  { id: "compare", label: "Restyle" },
  { id: "place", label: "Inrichten" },
  { id: "ai", label: "AI-analyse" },
] as const;

type TabId = (typeof tabs)[number]["id"];

function useIsMobile() {
  const [mobile, setMobile] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px)");
    const update = () => setMobile(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);
  return mobile;
}

export function HeroPreviewCard() {
  const [active, setActive] = useState<TabId>("compare");
  const [interacted, setInteracted] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [rotationProgress, setRotationProgress] = useState(0);
  const rotationStartRef = useRef<number | null>(null);
  const isMobile = useIsMobile();

  const autoRotateEnabled = !isMobile && !interacted && !hovering;

  // Auto-rotate timer
  useEffect(() => {
    if (!autoRotateEnabled) {
      rotationStartRef.current = null;
      setRotationProgress(0);
      return;
    }
    let raf = 0;
    rotationStartRef.current = performance.now();
    const tick = (now: number) => {
      if (rotationStartRef.current === null) return;
      const elapsed = now - rotationStartRef.current;
      const p = elapsed / AUTO_ROTATE_MS;
      if (p >= 1) {
        const idx = tabs.findIndex((t) => t.id === active);
        setActive(tabs[(idx + 1) % tabs.length].id);
        rotationStartRef.current = now;
        setRotationProgress(0);
      } else {
        setRotationProgress(p);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, autoRotateEnabled]);

  const onPick = (id: TabId) => {
    setInteracted(true);
    setActive(id);
  };

  return (
    <div
      className="relative w-full"
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
    >
      {/* Preview with overlaid call-to-action buttons */}
      <div className={`relative ${WIDE_ASPECT}`}>
        <AnimatePresence>
          <motion.div
            key={active}
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
          >
            {active === "compare" && (
              <BeforeAfterSlider active aspectClass={WIDE_ASPECT} framed={false} />
            )}
            {active === "place" && (
              <FurnitureAnimation aspectClass={WIDE_ASPECT} framed={false} />
            )}
            {active === "ai" && (
              <TransformationPreview active aspectClass={WIDE_ASPECT} framed={false} />
            )}
          </motion.div>
        </AnimatePresence>

        {/* CTAs — overlaid on the bottom-left from sm up (the region clear on
            every tab). On mobile they move below the preview so they never hide
            the chip tray / AI panel; see the in-flow block under the tabs. */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 hidden gap-3 sm:flex sm:flex-row sm:items-end sm:p-6 lg:p-8">
          <CtaButtons variant="overlay" />
        </div>
      </div>

      {/* Tabs */}
      <div
        role="tablist"
        aria-label="Preview-modus"
        className="mt-4 flex items-center justify-center gap-2 overflow-x-auto px-1 pb-1"
      >
        {tabs.map((t) => {
          const isActive = t.id === active;
          return (
            <button
              key={t.id}
              role="tab"
              aria-selected={isActive}
              aria-controls={`panel-${t.id}`}
              onClick={() => onPick(t.id)}
              className={[
                "relative inline-flex shrink-0 items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-medium transition",
                isActive
                  ? "bg-[color:var(--surface-soft)] text-[color:var(--fg)]"
                  : "text-[color:var(--muted)] hover:bg-[color:var(--surface-soft)] hover:text-[color:var(--fg)]",
              ].join(" ")}
            >
              {isActive && autoRotateEnabled && (
                <ProgressBorder progress={rotationProgress} />
              )}
              <span className="relative z-10">{t.label}</span>
              {isActive && !autoRotateEnabled && (
                <motion.span
                  layoutId="active-tab-underline"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  className="absolute inset-x-3 bottom-0 h-0.5 rounded-full bg-[color:var(--brand)]"
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Mobile CTAs — in normal flow below the tabs so they never overlap the
          preview (kept as an overlay from sm up, above). */}
      <div className="mt-4 flex flex-col items-start gap-3 px-1 sm:hidden">
        <CtaButtons variant="inline" />
      </div>
    </div>
  );
}

// Demo + examples CTAs. Rendered as a dark-image overlay from sm up, and as an
// in-flow block on mobile; the secondary button switches to light-theme styling
// inline so it doesn't look like a stray dark pill on the cream page.
function CtaButtons({ variant }: { variant: "overlay" | "inline" }) {
  const { open } = useDemoForm();
  const secondary =
    variant === "overlay"
      ? "border-white/25 bg-black/40 text-white backdrop-blur-md hover:bg-black/55"
      : "border-[color:var(--hairline)] bg-[color:var(--surface-soft)] text-[color:var(--fg)] hover:bg-[color:var(--surface-softer)]";
  return (
    <>
      <button
        type="button"
        onClick={open}
        className="pointer-events-auto group inline-flex items-center gap-2 rounded-full bg-[color:var(--brand)] px-6 py-2.5 text-sm font-medium text-[color:var(--on-brand)] transition-colors duration-200 hover:bg-[color:var(--brand-deep)]"
      >
        <span>Demo aanvragen</span>
        <svg
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="translate-x-0 transition-transform group-hover:translate-x-0.5"
          aria-hidden
        >
          <path d="M5 12h14" />
          <path d="m13 5 7 7-7 7" />
        </svg>
      </button>

      <Link
        href="/voorbeelden"
        className={`pointer-events-auto inline-flex items-center gap-1.5 rounded-full border px-6 py-2.5 text-sm font-medium transition active:scale-[0.98] ${secondary}`}
      >
        Bekijk voorbeelden →
      </Link>
    </>
  );
}

// Traces a progress stroke around the perimeter of the active tab pill.
function ProgressBorder({ progress }: { progress: number }) {
  const ref = useRef<SVGSVGElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });

  useEffect(() => {
    const el = ref.current?.parentElement;
    if (!el) return;
    const measure = () => setSize({ w: el.offsetWidth, h: el.offsetHeight });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const { w, h } = size;
  const inset = 1;

  return (
    <svg
      ref={ref}
      aria-hidden
      className="pointer-events-none absolute inset-0 h-full w-full overflow-visible"
      viewBox={w && h ? `0 0 ${w} ${h}` : undefined}
      preserveAspectRatio="none"
    >
      {w > 0 && h > 0 && (
        <>
          <rect
            x={inset}
            y={inset}
            width={w - inset * 2}
            height={h - inset * 2}
            rx={(h - inset * 2) / 2}
            fill="none"
            stroke="var(--hairline)"
            strokeWidth={1.5}
          />
          <rect
            x={inset}
            y={inset}
            width={w - inset * 2}
            height={h - inset * 2}
            rx={(h - inset * 2) / 2}
            fill="none"
            stroke="var(--brand)"
            strokeWidth={1.5}
            strokeLinecap="round"
            pathLength={1}
            strokeDasharray={1}
            strokeDashoffset={1 - progress}
          />
        </>
      )}
    </svg>
  );
}
