"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { motion, useAnimationFrame } from "motion/react";

type Props = {
  active?: boolean;
  aspectClass?: string;
  framed?: boolean;
};

export function BeforeAfterSlider({
  active = true,
  aspectClass = "aspect-[16/10] w-full",
  framed = true,
}: Props) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [pos, setPos] = useState(50); // 0..100
  const [dragging, setDragging] = useState(false);
  const [autoDemoDone, setAutoDemoDone] = useState(false);
  const startTimeRef = useRef<number | null>(null);

  // Auto-demo: 50 -> 70 -> 30 -> 50 over ~2.4s on first activation
  useAnimationFrame((t) => {
    if (autoDemoDone || dragging || !active) return;
    if (startTimeRef.current === null) startTimeRef.current = t;
    const elapsed = (t - startTimeRef.current) / 1000;
    const duration = 2.4;
    if (elapsed >= duration) {
      setPos(50);
      setAutoDemoDone(true);
      return;
    }
    const p = elapsed / duration; // 0..1
    // piecewise: 0-0.33 -> 50->70, 0.33-0.66 -> 70->30, 0.66-1 -> 30->50
    let next: number;
    if (p < 1 / 3) {
      const k = p / (1 / 3);
      next = 50 + (70 - 50) * easeOut(k);
    } else if (p < 2 / 3) {
      const k = (p - 1 / 3) / (1 / 3);
      next = 70 + (30 - 70) * easeInOut(k);
    } else {
      const k = (p - 2 / 3) / (1 / 3);
      next = 30 + (50 - 30) * easeInOut(k);
    }
    setPos(next);
  });

  const updateFromClientX = useCallback((clientX: number) => {
    const el = containerRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setPos(Math.min(100, Math.max(0, pct)));
  }, []);

  const onPointerDown = (e: React.PointerEvent) => {
    setAutoDemoDone(true);
    setDragging(true);
    (e.target as Element).setPointerCapture?.(e.pointerId);
    updateFromClientX(e.clientX);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging) return;
    updateFromClientX(e.clientX);
  };
  const onPointerUp = (e: React.PointerEvent) => {
    setDragging(false);
    (e.target as Element).releasePointerCapture?.(e.pointerId);
  };

  // Keyboard a11y
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!containerRef.current?.contains(document.activeElement)) return;
      if (e.key === "ArrowLeft") setPos((p) => Math.max(0, p - 4));
      if (e.key === "ArrowRight") setPos((p) => Math.min(100, p + 4));
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <div
      ref={containerRef}
      className={`relative ${aspectClass} select-none overflow-hidden bg-[#E7E0D3] ${framed ? "rounded-2xl border border-white/10 shadow-2xl" : ""}`}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
    >
      {/* Furnished (full background) */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/graphics/furnished-room.jpeg"
        alt="Ingerichte woonkamer met bank, salontafel en hanglamp"
        draggable={false}
        className="pointer-events-none absolute inset-0 h-full w-full select-none object-cover"
      />

      {/* Empty (clipped) — same room, before */}
      <div
        className="absolute inset-0"
        style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/graphics/empty-room.png"
          alt="Lege woonkamer zonder meubels"
          draggable={false}
          className="pointer-events-none absolute inset-0 h-full w-full select-none object-cover"
        />
      </div>

      {/* Floating labels */}
      <span className="pointer-events-none absolute left-3 top-3 rounded-full bg-black/55 px-2.5 py-1 text-[11px] font-medium uppercase tracking-wider text-white/90 backdrop-blur">
        Voor
      </span>
      <span className="pointer-events-none absolute right-3 top-3 rounded-full bg-[color:var(--brand)]/85 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wider text-[#1a0f06] backdrop-blur">
        Na
      </span>

      {/* Divider */}
      <motion.div
        className="pointer-events-none absolute inset-y-0"
        style={{ left: `${pos}%` }}
        transition={{ type: "spring", stiffness: 60, damping: 18 }}
      >
        <div className="absolute inset-y-0 -left-px w-0.5 bg-white/85 shadow-[0_0_18px_rgba(255,255,255,0.45)]" />
        {/* Handle */}
        <button
          type="button"
          role="slider"
          aria-label="Sleep om voor en na te vergelijken"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(pos)}
          tabIndex={0}
          className="pointer-events-auto absolute top-1/2 -translate-x-1/2 -translate-y-1/2 grid h-9 w-9 cursor-grab place-items-center rounded-full border border-white/40 bg-white/90 text-[#101424] shadow-lg backdrop-blur transition active:cursor-grabbing focus:outline-none focus:ring-2 focus:ring-[color:var(--brand)]/70"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden
          >
            <path d="M9 6 3 12l6 6" />
            <path d="m15 6 6 6-6 6" />
          </svg>
        </button>
      </motion.div>

      {/* Inner top sheen */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-black/30 to-transparent"
      />
    </div>
  );
}

function easeOut(t: number) {
  return 1 - Math.pow(1 - t, 3);
}
function easeInOut(t: number) {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}
