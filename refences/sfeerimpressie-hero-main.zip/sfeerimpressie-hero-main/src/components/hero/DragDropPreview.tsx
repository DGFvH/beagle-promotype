"use client";

import { motion, AnimatePresence } from "motion/react";
import { useEffect, useState } from "react";

type FurnitureItem = {
  id: string;
  label: string;
  Icon: () => React.ReactElement;
};

function SofaIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden>
      <rect x="6" y="22" width="36" height="14" rx="3" fill="#A07B54" />
      <rect x="6" y="18" width="36" height="8" rx="3" fill="#C49770" />
      <rect x="8" y="34" width="4" height="6" rx="1" fill="#3D2A18" />
      <rect x="36" y="34" width="4" height="6" rx="1" fill="#3D2A18" />
      <rect x="11" y="24" width="9" height="8" rx="2" fill="#D8B077" />
      <rect x="22" y="24" width="9" height="8" rx="2" fill="#D8B077" />
      <rect x="32" y="24" width="6" height="8" rx="2" fill="#D8B077" />
    </svg>
  );
}
function TableIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden>
      <rect x="6" y="20" width="36" height="6" rx="1.5" fill="#3D2A18" />
      <rect x="10" y="26" width="3" height="16" fill="#3D2A18" />
      <rect x="35" y="26" width="3" height="16" fill="#3D2A18" />
      <ellipse cx="24" cy="20" rx="18" ry="3" fill="#5A4028" />
    </svg>
  );
}
function LampIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden>
      <path d="M16 14 L32 14 L28 24 L20 24 Z" fill="#F2D9A9" />
      <rect x="22" y="24" width="4" height="18" fill="#3D2A18" />
      <rect x="16" y="40" width="16" height="3" rx="1" fill="#3D2A18" />
      <circle cx="24" cy="14" r="6" fill="#FFE3B0" opacity="0.55" />
    </svg>
  );
}
function PlantIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden>
      <path d="M24 8 C 20 14 18 20 22 26" stroke="#5C8A4E" strokeWidth="3" strokeLinecap="round" fill="none" />
      <path d="M24 10 C 28 14 30 20 26 26" stroke="#7AAE63" strokeWidth="3" strokeLinecap="round" fill="none" />
      <path d="M24 14 C 22 20 22 24 24 28" stroke="#9FCE85" strokeWidth="3" strokeLinecap="round" fill="none" />
      <path d="M14 30 L34 30 L30 42 L18 42 Z" fill="#B07843" />
      <path d="M14 30 L34 30 L33 32 L15 32 Z" fill="#7A4F2C" />
    </svg>
  );
}
function RugIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden>
      <ellipse cx="24" cy="32" rx="20" ry="8" fill="#A85A45" />
      <ellipse cx="24" cy="32" rx="14" ry="5" fill="#D8794F" />
      <ellipse cx="24" cy="32" rx="6" ry="2" fill="#F2A65A" />
    </svg>
  );
}
function CabinetIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden>
      <rect x="9" y="6" width="30" height="36" rx="2" fill="#5A4028" />
      <rect x="11" y="8" width="13" height="32" rx="1" fill="#7A5C3D" />
      <rect x="24" y="8" width="13" height="32" rx="1" fill="#7A5C3D" />
      <circle cx="22" cy="24" r="1.2" fill="#F2D9A9" />
      <circle cx="26" cy="24" r="1.2" fill="#F2D9A9" />
      <line x1="11" y1="20" x2="24" y2="20" stroke="#3D2A18" strokeWidth="0.6" opacity="0.6" />
      <line x1="24" y1="20" x2="37" y2="20" stroke="#3D2A18" strokeWidth="0.6" opacity="0.6" />
    </svg>
  );
}
function TvUnitIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden>
      {/* TV */}
      <rect x="10" y="10" width="28" height="16" rx="1.5" fill="#1B1B22" />
      <rect x="12" y="12" width="24" height="12" rx="0.8" fill="#3A536E" />
      <rect x="22" y="26" width="4" height="3" fill="#1B1B22" />
      <rect x="18" y="29" width="12" height="1.5" rx="0.6" fill="#1B1B22" />
      {/* Unit */}
      <rect x="6" y="31" width="36" height="10" rx="1.5" fill="#7A5C3D" />
      <rect x="9" y="34" width="9" height="4" rx="0.6" fill="#A07B54" />
      <rect x="20" y="34" width="9" height="4" rx="0.6" fill="#A07B54" />
      <rect x="31" y="34" width="8" height="4" rx="0.6" fill="#A07B54" />
      <rect x="8" y="41" width="3" height="3" rx="0.5" fill="#3D2A18" />
      <rect x="37" y="41" width="3" height="3" rx="0.5" fill="#3D2A18" />
    </svg>
  );
}
function ChairIcon() {
  return (
    <svg viewBox="0 0 48 48" className="h-7 w-7" aria-hidden>
      <rect x="14" y="8" width="20" height="18" rx="2.5" fill="#A07B54" />
      <rect x="16" y="11" width="16" height="13" rx="1.5" fill="#C49770" />
      <rect x="12" y="26" width="24" height="6" rx="1.5" fill="#7A5C3D" />
      <rect x="14" y="32" width="3" height="10" fill="#3D2A18" />
      <rect x="31" y="32" width="3" height="10" fill="#3D2A18" />
    </svg>
  );
}

const items: FurnitureItem[] = [
  { id: "sofa", label: "Bank", Icon: SofaIcon },
  { id: "table", label: "Tafel", Icon: TableIcon },
  { id: "lamp", label: "Lamp", Icon: LampIcon },
  { id: "plant", label: "Plant", Icon: PlantIcon },
  { id: "rug", label: "Vloerkleed", Icon: RugIcon },
  { id: "cabinet", label: "Kast", Icon: CabinetIcon },
  { id: "tv", label: "Tv-meubel", Icon: TvUnitIcon },
  { id: "chair", label: "Stoel", Icon: ChairIcon },
];

function RoomBackdrop() {
  return (
    <svg viewBox="0 0 800 600" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 h-full w-full" aria-hidden>
      <defs>
        <linearGradient id="dd-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1E1F2E" />
          <stop offset="100%" stopColor="#13141F" />
        </linearGradient>
        <linearGradient id="dd-floor" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3A2C1F" />
          <stop offset="100%" stopColor="#1E160D" />
        </linearGradient>
      </defs>
      <rect width="800" height="420" fill="url(#dd-wall)" />
      <rect y="420" width="800" height="180" fill="url(#dd-floor)" />
      {/* faint architectural lines */}
      <line x1="0" y1="420" x2="800" y2="420" stroke="#000" strokeWidth="2" opacity="0.5" />
      <g stroke="#000" strokeWidth="1" opacity="0.2">
        <line x1="0" y1="470" x2="800" y2="470" />
        <line x1="0" y1="530" x2="800" y2="530" />
      </g>
      <rect x="500" y="120" width="160" height="180" fill="#26273A" stroke="#0B0C16" strokeWidth="4" />
    </svg>
  );
}

type Props = { active?: boolean };

export function DragDropPreview({ active = true }: Props) {
  // run-key drives a remount of motion children when tab becomes active
  const [runKey, setRunKey] = useState(0);
  useEffect(() => {
    if (active) setRunKey((k) => k + 1);
  }, [active]);

  return (
    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-2xl border border-white/10 bg-[#0D1020] shadow-2xl">
      <RoomBackdrop />

      {/* Slepen & plaatsen label */}
      <span className="pointer-events-none absolute left-3 top-3 z-10 inline-flex items-center gap-1.5 rounded-full bg-black/50 px-2.5 py-1 text-[11px] uppercase tracking-wider text-white/80 backdrop-blur">
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="M3 12h4l3-7 4 14 3-7h4" />
        </svg>
        Slepen &amp; plaatsen
      </span>

      {/* Choreographed sofa + outline */}
      <div key={runKey} className="absolute inset-0">
        {/* Dashed placement outline */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{
            opacity: [0, 0, 1, 1, 1, 0],
          }}
          transition={{
            duration: 2.4,
            delay: 0.8,
            times: [0, 0.16, 0.16, 0.5, 0.85, 1],
            ease: "easeInOut",
          }}
          className="absolute"
          style={{
            left: "32%",
            top: "60%",
            width: "36%",
            height: "22%",
          }}
        >
          <motion.div
            animate={{ scale: [1, 1.04, 1, 1.04, 1] }}
            transition={{ duration: 1.2, delay: 1.2, times: [0, 0.25, 0.5, 0.75, 1], ease: "easeInOut" }}
            className="h-full w-full rounded-xl border-2 border-dashed border-[color:var(--brand)]/80 bg-[color:var(--brand)]/8"
          />
        </motion.div>

        {/* Sofa in-transit */}
        <motion.div
          initial={{ x: "calc(50% - 32px)", y: "calc(100% - 88px)", scale: 0.8, opacity: 0 }}
          animate={{
            x: ["calc(50% - 32px)", "calc(50% - 64px)", "calc(50% - 64px)"],
            y: ["calc(100% - 88px)", "55%", "60%"],
            scale: [0.8, 1.1, 1],
            opacity: [0, 1, 1],
          }}
          transition={{
            duration: 2.0,
            delay: 0.4,
            times: [0, 0.4, 1],
            ease: [0.22, 1, 0.36, 1] as const,
          }}
          className="absolute left-0 top-0"
        >
          <motion.div
            initial={{ filter: "drop-shadow(0 18px 18px rgba(0,0,0,0.5))" }}
            animate={{
              filter: [
                "drop-shadow(0 18px 18px rgba(0,0,0,0.55))",
                "drop-shadow(0 24px 22px rgba(0,0,0,0.6))",
                "drop-shadow(0 6px 10px rgba(0,0,0,0.4))",
              ],
            }}
            transition={{ duration: 2.0, delay: 0.4, times: [0, 0.55, 1] }}
            className="rounded-xl"
          >
            <SofaLarge />
          </motion.div>
        </motion.div>

        {/* Toast */}
        <AnimatePresence>
          <motion.div
            key={`toast-${runKey}`}
            initial={{ opacity: 0, y: 12, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ delay: 2.6, duration: 0.4 }}
            className="absolute bottom-[88px] right-4 inline-flex items-center gap-1.5 rounded-full bg-[color:var(--brand)]/90 px-3 py-1.5 text-[11px] font-semibold text-[#1a0f06] shadow-lg"
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
              <path d="M20 6 9 17l-5-5" />
            </svg>
            Geplaatst
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Furniture strip */}
      <motion.div
        key={`strip-${runKey}`}
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.55, ease: [0.22, 1, 0.36, 1] as const }}
        className="absolute inset-x-0 bottom-0 z-10 border-t border-white/10 bg-black/45 px-3 py-3 backdrop-blur-md"
      >
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {items.map((it, i) => {
            const selected = it.id === "sofa";
            return (
              <button
                type="button"
                key={it.id}
                aria-label={`Plaats ${it.label.toLowerCase()}`}
                className={[
                  "group relative flex h-16 w-16 shrink-0 flex-col items-center justify-center gap-1 rounded-xl border transition",
                  selected
                    ? "border-[color:var(--brand)] bg-white/10 ring-2 ring-[color:var(--brand)]/60"
                    : "border-white/10 bg-white/5 hover:bg-white/10",
                ].join(" ")}
                style={{ animationDelay: `${0.5 + i * 0.05}s` }}
              >
                <it.Icon />
                <span className="text-[9px] uppercase tracking-wider text-white/70">{it.label}</span>
              </button>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
}

function SofaLarge() {
  return (
    <svg viewBox="0 0 128 64" className="h-16 w-32" aria-hidden>
      <rect x="2" y="22" width="124" height="34" rx="6" fill="#7A5C3D" />
      <rect x="2" y="14" width="124" height="18" rx="6" fill="#A07B54" />
      <rect x="4" y="54" width="10" height="8" rx="2" fill="#2A1D10" />
      <rect x="114" y="54" width="10" height="8" rx="2" fill="#2A1D10" />
      <rect x="10" y="24" width="30" height="20" rx="4" fill="#C49770" />
      <rect x="50" y="24" width="30" height="20" rx="4" fill="#C49770" />
      <rect x="90" y="24" width="30" height="20" rx="4" fill="#C49770" />
      <rect x="14" y="14" width="22" height="14" rx="4" fill="#D88A55" />
      <rect x="90" y="14" width="22" height="14" rx="4" fill="#D8B25A" />
    </svg>
  );
}
