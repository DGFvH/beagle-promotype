"use client";

import { MotionConfig, motion } from "motion/react";
import { HeroPreviewCard } from "./HeroPreviewCard";

const fadeUp = (delay: number) => ({
  initial: { opacity: 0, y: 18 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] as const },
});

export function Hero() {
  return (
    <MotionConfig reducedMotion="user">
      <section
        aria-labelledby="hero-heading"
        className="snap-block relative isolate flex min-h-[100svh] w-full flex-col items-center justify-center gap-6 overflow-hidden bg-[color:var(--bg)] pb-8 pt-28 sm:pt-32 lg:gap-8"
      >
        {/* Headline */}
        <motion.h1
          id="hero-heading"
          {...fadeUp(0.1)}
          className="text-display-1 relative z-10 mx-auto shrink-0 px-6 text-center text-[color:var(--fg)]"
        >
          Digitale wooninrichting die de ruimte{" "}
          <em className="italic text-[color:var(--brand-deep)] whitespace-nowrap pr-[0.06em]">
            tot leven brengt
          </em>
        </motion.h1>

        {/* Subheadline */}
        <motion.p
          {...fadeUp(0.22)}
          className="relative z-10 -mt-2 max-w-xl shrink-0 text-balance px-6 text-center text-base text-[color:var(--muted)] sm:text-lg"
        >
          Laat kopers in seconden zien wat een leeg of gedateerd pand kan worden.
        </motion.p>

        {/* Full-width interactive preview — broad and short, the hero centerpiece */}
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.985 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.85, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="relative z-10 w-full"
        >
          <HeroPreviewCard />
        </motion.div>
      </section>
    </MotionConfig>
  );
}
