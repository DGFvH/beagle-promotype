/**
 * Social proof + testimonials.
 *
 * NOTE: the agency names in `LOGOS` and the quotes in `TESTIMONIALS` are
 * PLACEHOLDERS. Replace them with real, permissioned customer logos and quotes
 * before publishing — do not ship fabricated reviews.
 */

const LOGOS = [
  "Noord Makelaars",
  "Stadshuis Wonen",
  "Thuis & Co",
  "De Sleutel",
  "Havenzicht",
];

type Testimonial = {
  quote: string;
  name: string;
  role: string;
};

const TESTIMONIALS: Testimonial[] = [
  {
    quote:
      "Mijn verkopers zien meteen waar hun woning naartoe kan groeien. Dat geeft rust en vertrouwen in het gesprek.",
    name: "Sanne de Vries",
    role: "Makelaar, Noord Makelaars",
  },
  {
    quote:
      "Ik kan nu binnen een dag laten zien wat een leeg pand wordt. Kopers waarderen het enorm dat ze de potentie écht voor zich zien.",
    name: "Tom Bakker",
    role: "Makelaar, Stadshuis Wonen",
  },
  {
    quote:
      "Geen stylisten meer inplannen of wachten. We helpen kopers gewoon sneller een thuis te zien — precies waar het ons om gaat.",
    name: "Lisa Janssen",
    role: "Eigenaar, Thuis & Co",
  },
];

export function Testimonials() {
  return (
    <section
      aria-labelledby="testimonials-heading"
      className="snap-block relative flex min-h-[100svh] items-center bg-[color:var(--bg)] px-6 py-24 sm:px-8"
    >
      <div className="mx-auto w-full max-w-[1280px]">
        <div className="mx-auto max-w-2xl text-center">
          <span className="font-display text-base italic text-[color:var(--brand-deep)]">
            In de praktijk
          </span>
          <h2
            id="testimonials-heading"
            className="font-display mt-4 text-3xl leading-[1.08] text-[color:var(--fg)] sm:text-4xl lg:text-5xl"
          >
            Makelaars die kopers een{" "}
            <em className="italic text-[color:var(--brand-deep)]">thuis</em> laten
            zien.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base text-[color:var(--muted)] sm:text-lg">
            We werken graag samen met makelaars door heel Nederland. Een paar van
            hen vertellen wat het hun oplevert.
          </p>
        </div>

        {/* Social proof — placeholder logo strip */}
        <ul className="mt-10 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
          {LOGOS.map((name) => (
            <li
              key={name}
              className="text-sm font-medium tracking-wide text-[color:var(--muted)] opacity-70"
            >
              {name}
            </li>
          ))}
        </ul>

        {/* Testimonials */}
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <figure
              key={t.name}
              className="flex flex-col rounded-xl border border-[color:var(--hairline)] bg-[color:var(--bg-elev)] p-6"
            >
              <span
                aria-hidden
                className="font-display text-4xl leading-none text-[color:var(--brand)]/60"
              >
                &ldquo;
              </span>
              <blockquote className="mt-2 flex-1 text-[1.0625rem] leading-relaxed text-[color:var(--fg)]/90">
                {t.quote}
              </blockquote>
              <figcaption className="mt-6">
                <div className="font-display text-base text-[color:var(--fg)]">
                  {t.name}
                </div>
                <div className="mt-0.5 text-sm text-[color:var(--muted)]">
                  {t.role}
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
