import Link from "next/link";
import { DemoButton } from "@/components/demo/DemoButton";

/**
 * Closing invitation. Warm and service-minded rather than salesy: no urgency,
 * no pressure — just an open offer to look along with the makelaar.
 */
export function ClosingCta() {
  return (
    <section
      aria-labelledby="closing-heading"
      className="relative flex min-h-[70svh] items-center justify-center bg-[color:var(--bg)] px-6 py-24 text-center sm:px-8"
    >
      <div className="mx-auto max-w-2xl">
        <span className="font-display text-base italic text-[color:var(--brand-deep)]">
          Vrijblijvend
        </span>
        <h2
          id="closing-heading"
          className="font-display mt-4 text-3xl leading-[1.1] text-[color:var(--fg)] sm:text-4xl lg:text-5xl"
        >
          Zullen we een keer met u meekijken?
        </h2>
        <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-[color:var(--muted)] sm:text-lg">
          Stuur ons gerust een woning, dan laten we u vrijblijvend zien wat
          virtuele styling ermee doet. Geen verplichtingen en geen haast — we
          denken graag met u mee en kijken wat het beste bij uw panden past.
        </p>

        <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <DemoButton className="inline-flex items-center gap-2 rounded-full bg-[color:var(--brand)] px-7 py-3 text-sm font-medium text-[color:var(--on-brand)] transition-colors hover:bg-[color:var(--brand-deep)]">
            Demo aanvragen
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
              <path d="M5 12h14" />
              <path d="m13 5 7 7-7 7" />
            </svg>
          </DemoButton>
          <Link
            href="/voorbeelden"
            className="inline-flex items-center gap-1.5 rounded-full border border-[color:var(--hairline)] px-7 py-3 text-sm font-medium text-[color:var(--fg)] transition hover:bg-[color:var(--surface-soft)]"
          >
            Bekijk eerst de voorbeelden →
          </Link>
        </div>

        <p className="mt-6 text-sm text-[color:var(--muted)]">
          Liever even bellen of mailen kan natuurlijk ook.
        </p>
      </div>
    </section>
  );
}
