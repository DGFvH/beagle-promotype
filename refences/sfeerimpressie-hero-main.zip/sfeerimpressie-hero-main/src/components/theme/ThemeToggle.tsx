"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";

type Theme = "dark" | "light";

const STORAGE_KEY = "sfeerimpressie-theme";

export function ThemeToggle() {
  // SSR always renders with the light default (matching <html data-theme="light">).
  // The pre-paint inline script may have flipped the attribute to "dark" before
  // hydration runs, so we cannot read from the document during initial render —
  // doing so causes a hydration mismatch that tears down neighbouring trees.
  // Instead, we sync to the real theme inside useEffect after mount.
  const [theme, setTheme] = useState<Theme>("light");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const attr = document.documentElement.getAttribute("data-theme");
    setTheme(attr === "light" ? "light" : "dark");
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    document.documentElement.setAttribute("data-theme", theme);
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      /* ignore */
    }
  }, [theme, mounted]);

  const isLight = theme === "light";

  return (
    <button
      type="button"
      aria-label={isLight ? "Schakel naar donker thema" : "Schakel naar licht thema"}
      aria-pressed={isLight}
      onClick={() => setTheme(isLight ? "dark" : "light")}
      className="fixed right-4 top-4 z-50 inline-flex h-10 items-center gap-2 rounded-full border border-[color:var(--hairline)] bg-[color:var(--bg-elev)]/80 px-3 text-xs font-medium text-[color:var(--fg)] shadow-[0_10px_30px_-10px_rgba(0,0,0,0.35)] backdrop-blur transition hover:scale-[1.04] active:scale-[0.97] sm:right-6 sm:top-6"
    >
      <span className="relative grid h-6 w-6 place-items-center">
        <AnimatePresence mode="wait" initial={false}>
          {isLight ? (
            <motion.span
              key="sun"
              initial={{ opacity: 0, rotate: -45, scale: 0.6 }}
              animate={{ opacity: 1, rotate: 0, scale: 1 }}
              exit={{ opacity: 0, rotate: 45, scale: 0.6 }}
              transition={{ duration: 0.25 }}
              className="text-[color:var(--brand)]"
            >
              <SunIcon />
            </motion.span>
          ) : (
            <motion.span
              key="moon"
              initial={{ opacity: 0, rotate: 45, scale: 0.6 }}
              animate={{ opacity: 1, rotate: 0, scale: 1 }}
              exit={{ opacity: 0, rotate: -45, scale: 0.6 }}
              transition={{ duration: 0.25 }}
              className="text-[color:var(--brand)]"
            >
              <MoonIcon />
            </motion.span>
          )}
        </AnimatePresence>
      </span>
      <span className="hidden sm:inline">{isLight ? "Licht" : "Donker"}</span>
    </button>
  );
}

function SunIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z" />
    </svg>
  );
}
