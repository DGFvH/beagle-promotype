// Injected as an inline script before hydration so we never paint the wrong theme.
export const themeInitScript = `(() => {
  try {
    var stored = localStorage.getItem('sfeerimpressie-theme');
    var theme = stored === 'light' || stored === 'dark' ? stored : 'light';
    document.documentElement.setAttribute('data-theme', theme);
  } catch (_) {
    document.documentElement.setAttribute('data-theme', 'light');
  }
})();`;
