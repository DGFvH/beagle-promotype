import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { DemoButton } from "@/components/demo/DemoButton";
import { VOORBEELDEN } from "@/lib/voorbeelden";

export const metadata: Metadata = {
  title: "Voorbeelden | Sfeerimpressie",
  description:
    "Bekijk drie voorbeelden van virtuele styling: leeg of gedateerd pand voor en na. Zo laat u kopers de potentie van een woning zien.",
  openGraph: {
    title: "Voorbeelden van virtuele styling | Sfeerimpressie",
    description:
      "Drie voor-en-na voorbeelden van virtuele inrichting voor makelaars.",
    images: [{ url: "/voorbeelden/voorbeeld-1.jpg" }],
  },
};

export default function VoorbeeldenPage() {
  return (
    <main className="mx-auto w-full max-w-6xl px-5 pb-20 pt-24 sm:px-8 sm:pt-28">
      <Link
        href="/"
        className="inline-flex items-center gap-1.5 text-sm font-medium text-[color:var(--muted)] transition hover:text-[color:var(--fg)]"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="m15 18-6-6 6-6" />
        </svg>
        Terug naar home
      </Link>

      <header className="mt-5 max-w-2xl">
        <h1 className="font-display text-3xl leading-[1.08] text-[color:var(--fg)] sm:text-4xl lg:text-5xl">
          Voorbeelden van{" "}
          <em className="italic text-[color:var(--brand-deep)]">
            virtuele styling
          </em>
        </h1>
        <p className="mt-3 text-base text-[color:var(--muted)] sm:text-lg">
          Een leeg of gedateerd pand voor en na. Zo laat u kopers in seconden de
          potentie van een woning zien.
        </p>
      </header>

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {VOORBEELDEN.map((v, i) => (
          <Link
            key={v.slug}
            href={`/${v.slug}`}
            className="group flex flex-col overflow-hidden rounded-xl border border-[color:var(--hairline)] bg-[color:var(--bg-elev)] transition hover:-translate-y-1 hover:border-[color:var(--brand)]/50"
          >
            <div className="overflow-hidden">
              <Image
                src={v.image}
                alt={v.alt}
                width={v.width}
                height={v.height}
                priority={i === 0}
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                className="h-auto w-full transition-transform duration-500 group-hover:scale-[1.02]"
              />
            </div>
            <div className="flex flex-1 flex-col p-5">
              <p className="font-display text-sm italic text-[color:var(--brand-deep)]">
                Voorbeeld {v.num}
              </p>
              <h2 className="font-display mt-1 text-lg text-[color:var(--fg)]">
                {v.title}
              </h2>
              <p className="mt-1.5 flex-1 text-sm text-[color:var(--muted)]">
                {v.blurb}
              </p>
              <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-[color:var(--brand-deep)]">
                Bekijk voorbeeld
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="transition-transform group-hover:translate-x-0.5" aria-hidden>
                  <path d="M5 12h14" />
                  <path d="m13 5 7 7-7 7" />
                </svg>
              </span>
            </div>
          </Link>
        ))}
      </div>

      <div className="mt-14 flex flex-col items-start gap-4 rounded-xl border border-[color:var(--hairline)] bg-[color:var(--bg-elev)] p-6 sm:flex-row sm:items-center sm:justify-between sm:p-8">
        <div>
          <p className="font-display text-xl text-[color:var(--fg)]">
            Benieuwd wat het voor uw panden doet?
          </p>
          <p className="mt-1 text-sm text-[color:var(--muted)]">
            Vraag een demo aan, dan laten we het u zien op uw eigen woning.
          </p>
        </div>
        <DemoButton className="inline-flex shrink-0 items-center gap-2 rounded-full bg-[color:var(--brand)] px-6 py-3 text-sm font-medium text-[color:var(--on-brand)] transition-colors hover:bg-[color:var(--brand-deep)]">
          Demo aanvragen
        </DemoButton>
      </div>
    </main>
  );
}
