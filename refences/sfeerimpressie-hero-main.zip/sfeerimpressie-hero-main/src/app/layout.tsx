import type { Metadata } from "next";
import { DM_Sans, Fraunces } from "next/font/google";
import "./globals.css";
import { SiteHeader } from "@/components/layout/SiteHeader";
import { SiteFooter } from "@/components/layout/SiteFooter";
import { DemoFormProvider } from "@/components/demo/DemoFormProvider";
import { DemoModal } from "@/components/demo/DemoModal";

const dmSans = DM_Sans({
  variable: "--font-dm-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

// Editorial display face for headings — warm, magazine-like (VT-wonen aesthetic).
const fraunces = Fraunces({
  variable: "--font-fraunces",
  subsets: ["latin"],
  weight: ["400", "500"],
  style: ["normal", "italic"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Sfeerimpressie | Virtuele inrichting waarmee makelaars sneller verkopen",
  description:
    "Laat kopers in seconden zien wat een leeg of gedateerd pand kan worden. Virtuele AI-styling voor makelaars: win meer opdrachten en verkoop sneller. Vraag een demo aan.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="nl"
      data-theme="light"
      className={`${dmSans.variable} ${fraunces.variable} h-full antialiased`}
    >
      <body className="min-h-full bg-[color:var(--bg)] text-[color:var(--fg)] font-sans">
        <DemoFormProvider>
          <SiteHeader />
          {children}
          <SiteFooter />
          <DemoModal />
        </DemoFormProvider>
      </body>
    </html>
  );
}
