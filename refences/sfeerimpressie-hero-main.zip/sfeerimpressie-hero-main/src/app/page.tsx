import { Hero } from "@/components/hero/Hero";
import { ScrollFeatures } from "@/components/scroll/ScrollFeatures";
import { Testimonials } from "@/components/sections/Testimonials";
import { ClosingCta } from "@/components/sections/ClosingCta";

export default function Home() {
  return (
    <main className="flex w-full flex-1 flex-col">
      <Hero />
      <ScrollFeatures />
      <Testimonials />
      <ClosingCta />
    </main>
  );
}
