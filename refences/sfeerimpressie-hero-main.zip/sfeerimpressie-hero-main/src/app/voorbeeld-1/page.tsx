import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ExampleDetail } from "@/components/voorbeelden/ExampleDetail";
import { getVoorbeeld } from "@/lib/voorbeelden";

const voorbeeld = getVoorbeeld("voorbeeld-1");

export const metadata: Metadata = voorbeeld
  ? {
      title: `${voorbeeld.title} | Sfeerimpressie`,
      description: voorbeeld.blurb,
      openGraph: {
        title: `${voorbeeld.title} | Sfeerimpressie`,
        description: voorbeeld.blurb,
        images: [{ url: voorbeeld.image }],
      },
    }
  : {};

export default function Page() {
  if (!voorbeeld) notFound();
  return <ExampleDetail voorbeeld={voorbeeld} />;
}
