<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

# Handoff

Before doing anything else, read [`docs/HANDOFF.md`](docs/HANDOFF.md). It captures the resume point from the previous session (project state, design decisions, the in-flight task, and the user's operating conventions). This is the substitute for the local `~/.claude/projects/<project>/memory/` file that does not exist in the cloud.
