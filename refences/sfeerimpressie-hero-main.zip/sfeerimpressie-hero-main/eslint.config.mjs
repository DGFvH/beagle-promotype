import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
  {
    rules: {
      // React 19's new rule is too aggressive for our patterns: mount-time DOM
      // reads (ThemeToggle), client-only randomization (Particles), and
      // active-prop-driven runKey bumps (DragDropPreview / FurnitureAnimation
      // / TransformationPreview) all legitimately set state in effects.
      "react-hooks/set-state-in-effect": "off",
      // Allow intentionally-unused values that document timeline state.
      "@typescript-eslint/no-unused-vars": [
        "warn",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
    },
  },
]);

export default eslintConfig;
