---
name: placeholder-social-proof
description: Testimonials and logo strip on the site are placeholders awaiting real content
metadata:
  type: project
---

The social-proof logo strip and the three testimonial quotes added to the home page (`src/components/sections/Testimonials.tsx`) are PLACEHOLDERS — invented agency names (Noord Makelaars, Stadshuis Wonen, Thuis & Co, De Sleutel, Havenzicht) and fabricated quotes.

**Why:** Built at the user's request during the VT-wonen redesign, but publishing fabricated reviews/logos would be misleading.

**How to apply:** Before the site goes live, replace these with real, permissioned customer logos and quotes. Flag this to the user if they move toward publishing.
