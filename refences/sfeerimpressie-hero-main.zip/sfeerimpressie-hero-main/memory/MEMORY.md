# Memory index

- [Placeholder social proof](placeholder-social-proof.md) — testimonials & logo strip are fake, replace before publishing
