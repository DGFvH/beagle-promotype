# Handoff for a new Claude Code session

This file exists because work on this repo started in a local Claude Code CLI
session on Windows and is being handed off to a fresh cloud session at
claude.ai/code. The transcript of the previous session does not transfer.
**Read this file first** — it captures the resume point, the in-flight task,
and the operating conventions.

Last handoff written: **2026-05-29** at commit `89a68d5`.

---

## 1. What this project is

A Dutch B2B marketing landing page for **Sfeerimpressie**, an AI-styling tool
for real-estate agents (makelaars). It lets a realtor upload a photo of an
empty or dated property and present a styled version to buyers, to win
listings and close faster.

- Stack: **Next.js 16** (Turbopack, App Router), **Tailwind v4**,
  Motion via `motion/react`. TypeScript strict.
- Note: **this Next.js has breaking changes vs. your training data** — read
  `node_modules/next/dist/docs/` before writing Next-specific code.
- Local run: `npm run dev` → `http://localhost:3000`.
- Repo: <https://github.com/DGFvH/sfeerimpressie-hero>.
- Live: Vercel deploys from `main` automatically.

## 2. Page composition today

`src/app/page.tsx` renders only:

```
<main>
  <SnapScroller />        // wheel-driven snap controller (desktop ≥1024px)
  <Hero />                // headline + 3-tab interactive preview + CTAs
  <ScrollFeatures />      // section intro + 3 feature blocks
</main>
```

Each visual block is a `min-h-[100svh]` `.snap-block`. CSS proximity-snap is
enabled ≥1024px and the JS `SnapScroller` does wheel-driven early snapping.

There is **no nav header, no footer, no other routes, no contact form**.
That is the gap the in-flight brainstorm is about closing — see §6.

## 3. Recent design state (already on main)

The page is currently positioned for B2B realtors after a multi-step
repositioning landed last week. Highlights:

- Hero headline: **"Geen makelaar verkoopt een *lege ruimte*."** (gradient on
  "lege ruimte", with `pr-[0.12em]` on the gradient span + `-ml-[0.12em]` on
  the period span to fix italic-overhang clipping).
  - **Feedback 2026-05-29 — this H1 is up for replacement.** It opens negative
    (says what *doesn't* work, not what we offer) and reads awkwardly. Keep the
    word **"makelaar"** (clarifies the audience, good for SEO) but lead with
    the benefit and lean into searched terms — **virtuele inrichting / virtual
    staging**, **verkoopstyling**, **sfeerimpressie**. User's candidate
    directions: *"Als makelaar direct een sfeerimpressie voor al je panden"*,
    *"Virtuele inrichting voor jou als makelaar"*, *"Professionele
    verkoopstyling"*. These are in informal **"je"** — reconcile with the
    site's formal **"u"** (§5): rewrite in "u" or deliberately revisit the
    tense. Offer the user 3–4 polished options rather than picking one.
    Lives in `Hero.tsx:25-32`.
- Primary CTA label: **"Demo aanvragen"** → `#demo`. **The anchor is dead** —
  no `/demo` route exists yet. Wiring it is part of the in-flight brainstorm.
- Secondary CTA: "Bekijk voorbeelden" → `#voorbeelden`.
- Both CTAs sit bottom-left of the preview (stacked on mobile, inline ≥sm).
- ScrollFeatures: realtor-focused copy, formal "u", stats woven into one
  bullet per feature ("tot 90% goedkoper dan fysieke styling", "ingerichte
  ruimte in onder de 30 seconden", "in 20+ stijlen, van Scandinavisch tot
  Art Deco").
- Feature titles are plain bold. Hero h1 and ScrollFeatures intro h2 keep
  their gradient phrase; feature h3s do not.
- Theme toggle has been **removed** from `layout.tsx`. The page locks to the
  cream "light" theme. `src/components/theme/ThemeToggle.tsx` and
  `theme-init.ts` remain on disk as dead code.
- `SnapScroller.tsx` now has direction-aware locking: one continuous gesture
  (incl. trackpad inertia) collapses to a single snap; opposite-direction
  input breaks the lock and reverses immediately. Knobs:
  `SNAP_LOCK_MS = 550`, `INERTIA_GAP_MS = 180`. The snap fix (commit
  `89a68d5`) has not been visually verified by the user — first thing to
  check on cloud is whether the snap feel is right.
- Auto-rotate cadence for the hero preview tabs: 10 s (`AUTO_ROTATE_MS`).

Detail-level spec for the B2B repositioning:
[`docs/superpowers/specs/2026-05-28-b2b-realtor-positioning-design.md`](superpowers/specs/2026-05-28-b2b-realtor-positioning-design.md).

## 4. Phase-2 B2B items still pending (from that spec)

Two unfinished items from the B2B spec that are unblocked once §6 lands:

- **CTA wiring** — `#demo` becomes the `/demo` route from §6 below.
- **SEO / open-graph** — realtor keywords in meta, an OG image PNG
  (1200 × 630), and SaaS structured data. Needs the OG asset from the user.

Items dropped during that work: replacing the emoji furniture chips in
`FurnitureAnimation.tsx` (the user explicitly removed it from the backlog).

## 5. Operating conventions

- **The user pushes only when they explicitly ask.** Commit locally; do not
  push without an explicit "push it" or equivalent. The classifier will
  block unauthorised pushes to `main` even when the user implicitly hinted.
- Branch off `main` for non-trivial work; small same-day fixes are fine
  on `main` as long as they're not pushed without authorisation.
- Commit-message style on this repo: conventional commits
  (`feat(scope): …`, `fix(scope): …`, etc.), Dutch summary lines allowed,
  end with `Co-Authored-By: Claude Opus 4.7 (1M context) <noreply@anthropic.com>`
  (the actual model line may differ).
- Verify with `npx tsc --noEmit` and `npm run lint` before committing.
- The repo contains a `vercelpush` marker file the user occasionally bumps to
  trigger a Vercel redeploy. Don't touch it.
- Audience and copy are **Dutch**, formal **"u"**, professional tone.
  "uw ruimte" → "de woning" / "het pand" / "uw bezichtiging".
- **No decorative em-dashes ("—") in user-facing copy** — the user reads it as
  an AI tell. Use commas, periods, or parentheses. Current offenders to clean
  up: `ScrollFeatures.tsx` body copy (lines ~27, 30, 55, 58) and the
  `layout.tsx` meta title + description.
- **Cut filler / instructional sentences — don't narrate the UI.** The
  scroll-hint at `ScrollFeatures.tsx:100-101` ("Scroll naar beneden om elke
  functie in actie te zien — elk paneel laadt wanneer het in beeld komt.") is
  overbodig — remove it.

## 6. **In-flight task: site expansion (you are here)**

The user asked for a list and plan to add what's missing from the site.
They want a **minimal** set of sections. The brainstorm reached the point
where Section 1 of the design was presented; the next step is to present
the remaining sections, write a spec, get the user's review, and execute.

**Why this matters (feedback 2026-05-29):** the user finds the current page
"kaal" and generically AI-styled, and says it **builds no trust** — having no
header/footer/menu makes it feel empty, and there are no company details
("over ons", bedrijfsnaam, KvK) and no pricing. The nav + footer + trust
content below are the fix; treat **trust-building** as the goal of this
section, not just adding structure. The bare, generic look is itself a defect
to design against, not only a missing-pages problem.

### Locked-in scope (user approved)

**Architecture:** single long page `/` with anchor sections, plus a few
subpages.

**On `/`, in order:**

1. **Nav header** (new) — sticky, logo + anchor links + persistent
   "Demo aanvragen" button.
2. **Hero** (existing) — no change.
3. **Overview** (new) — one short section between Hero and ScrollFeatures.
   Value prop + visual. Keep it tight.
4. **ScrollFeatures** (existing) — no change.
5. **FAQ** (new) — collapsible accordion, ~6–8 realtor-targeted questions.
6. **Footer** (new) — company info, KvK/BTW, copyright, legal links.

**Subpages:**

- `/demo` — in-page form: name, company, email, phone, message. Submits to
  a **stub handler** at first (just shows a "thanks, we'll be in touch"
  screen). Real backend wiring is later.
- `/privacy` — legal text.
- `/terms` — legal text.

**Polish:** favicon, OG image (1200 × 630), realtor-keyword meta.

### Deliberately skipped (user said no)

- How-it-works section (features section already serves this purpose)
- Pricing section (no pricing model yet) — **reopened 2026-05-29:** the user
  now flags missing pricing as a trust gap. Confirm whether to add a pricing
  section (or at least a "prijs op aanvraag" / indicative-tiers placeholder)
  before building.
- Social proof / testimonials (no real customers yet, placeholders declined)
- About / team section — **reopened 2026-05-29:** the user wants an "Over ons"
  and basic bedrijfsgegevens for trust. The footer will carry KvK/BTW/name;
  confirm whether that's enough or a small "Over ons" section/page is wanted.
- Separate "final CTA" section (persistent nav button + hero CTA is enough)
- Blog / case studies (deferred)

### Progress (session 2026-05-30, branch `claude/nice-cray-cTwyH`)

Spec written and pushed:
[`docs/superpowers/specs/2026-05-30-site-expansion-design.md`](superpowers/specs/2026-05-30-site-expansion-design.md).
Decisions taken this session: approach = **spec first**; pricing =
**indicative tiers**; over-ons = **short block on `/`**; legal = **AVG
template for review**; nav = **sticky (always visible)**.

Resume point: walking the spec's "Open items" **one question at a time**
(user asked for step-by-step). Answered: nav = **sticky**; scroll-snap =
**scope to showcase region** (Hero/Overview/Features snap, Pricing and
below scroll free); pricing = **visible placeholder prices** ("vanaf €xx"
on Start/Kantoor, "Prijs op aanvraag" on Op maat + indicatief disclaimer);
FAQ = **trimmed to 6** (dropped "welke foto's", merged use+disclosure);
overview = **3 icon/stat card grid**. All design questions resolved.
**Still to ask:** build granularity (whole shell in one pass vs. phased).
Then collect content (bedrijfsnaam, KvK, BTW, adres, e-mail, logo) and
build Phase 1. No app code has been written for the expansion yet.

### What the cloud session needs to do next

1. **Present the remaining design sections** (page composition details,
   per-section briefs, implementation roadmap) and get the user's nod
   per section, matching the rhythm established in the previous session.
2. **Write the spec doc** to
   `docs/superpowers/specs/YYYY-MM-DD-site-expansion-design.md`,
   self-review, ask the user to review it.
3. **Get content the user must provide** before any real implementation:
   company name + KvK + BTW + address for the footer, logo (or fall back
   to a wordmark), FAQ content (~6–8 Q&A), legal text for /privacy and
   /terms (or a generator stub).
4. Hand to the `superpowers:writing-plans` skill to produce the
   implementation plan, then execute per `superpowers:executing-plans`.

### Open questions to ask the user (still TBD)

- Nav style: sticky on scroll vs. scroll-revealing vs. plain top?
- Logo: do they have an SVG/PNG, or should we use a text wordmark?
- Footer content: company name, KvK number, BTW (VAT) number, address,
  contact email.
- FAQ content: do they want me to draft 6–8 questions or do they have a list?
- Legal: real text, AVG-compliant template, or a "wij maken dit nog"
  placeholder while building?
- OG image: do they have a 1200 × 630 PNG, or should we generate one?

## 7. Resume-point notes for the next agent

- Working tree clean, on `main`, 1 commit ahead of `origin/main`
  (`89a68d5` — snap fix). User authorised pushing it as part of the cloud
  hand-off, but the local push was blocked by the classifier; ask the user
  for explicit "push it" once they're set up in the cloud, then push the
  rebased commit and this handoff doc.
- The user uses formal "u" in Dutch. They want headlines punchy, not
  committee-written. They will push back hard on bad copy ("jesus fucking
  christ what a terrible headline") — take it on the chin, offer 3–4
  concrete alternatives, don't defend the bad line.
- Use the **superpowers** skill set: invoke `superpowers:brainstorming`
  before doing creative work, `superpowers:writing-plans` before touching
  code, `superpowers:verification-before-completion` before claiming
  anything works. The user values the discipline.
- The `superpowers:using-superpowers` skill is auto-loaded; subsequent
  skills must be invoked via the `Skill` tool.
- Memory: in the **local** session the resume-point lives in
  `~/.claude/projects/<project>/memory/hero-redesign-status.md`. The cloud
  session has no equivalent local memory; this `HANDOFF.md` is the substitute.
  If the cloud session needs to update the resume point, update **this file**
  and commit it.

## 8. Feedback round 2026-05-29 — hero & page-shell polish

A second round of user feedback, this time on the **live hero and the bare
page shell** (distinct from the §6 expansion build). Where each point lands:

- Headline / SEO → §3 (headline bullet).
- Body-copy quality (AI em-dashes, filler sentences) → §5 conventions.
- "Feels kaal / generic, builds no trust" + missing pricing / over-ons → §6
  (motivation paragraph + reopened scope items).
- The layout/interaction items below (tabs, the Inrichten line, mobile CTAs,
  desktop framing, dead CTAs) → here.

Several of these are quick wins on the **existing** hero, which is the first
thing a makelaar sees — do them before or alongside §6, not after.

### 8a. The three preview tabs read as illogical (naming + order)

Today the tabs are, left→right: **Voor & na · Inrichten · AI in actie**
(`HeroPreviewCard.tsx:14-18`). The user reads them as an implied *sequence*
("first AI, then drag furniture, then see the result?") and points out they
**all** show a before→after transformation, so singling one out as "Voor & na"
is confusing.

Decision to make with the user:
- Reframe the labels around the *capability/interaction*, not a process
  (e.g. "Vergelijk" · "Zelf inrichten" · "AI-analyse"), **or**
- Commit to an explicit numbered story (1 → 2 → 3) and order/label to match.

Then confirm the left→right order tells that story and that auto-rotate
(`AUTO_ROTATE_MS`) starts on the tab we want seen first.

### 8b. "Inrichten" shows a white centre line that looks draggable

In the **Inrichten** tab a white vertical line + dot appears at 50% during
each drag (`FurnitureAnimation.tsx:291-312`). It is purely decorative — it
mimics the **Voor & na** slider handle, so users expect to drag it and can't.

The user's note suggests the original intent may have been "two regions you
could drag between." Resolve that intent first, then pick one:
- **Remove** the line — simplest; the travelling ghost + cursor already tell
  the placement story, **or**
- **Restyle** it so it clearly is *not* a slider (a faint drop-target guide,
  not a glowing handle), **or**
- **Make it real** — only if we genuinely want a draggable split here, which
  duplicates the Voor & na interaction and is probably not worth it.

### 8c. Mobile: the CTAs sit on top of the preview and hide it

"Demo aanvragen" + "Bekijk voorbeelden" are absolutely positioned over the
bottom-left of the preview (`HeroPreviewCard.tsx:105-141`). On a phone they
cover the content — worst on **Inrichten** (chip tray) and **AI in actie**
(analysis panel), where the user says you "see almost nothing."

Fix: on mobile, lift the CTAs **out of the overlay and place them below the
card** in normal flow; keep an overlay (if at all) only from `sm`/`lg` up where
there is room. Re-check every tab at a phone width afterwards. The user calls
the mobile variant "lelijk" overall, so treat this as the start of a proper
mobile pass, not a one-line fix.

### 8d. Desktop: the hero feels stretched, with no breathing room

The preview is full-width at `aspect-[5/2]` with no max-width or side margin
(`HeroPreviewCard.tsx:12` `WIDE_ASPECT`; the `Hero.tsx` section has no
container). The user wants one of two framings — confirm which:
- **Full-bleed:** edge-to-edge and **drop the rounded corners**
  (`rounded-2xl`), letting it run the full width cleanly, **or**
- **Contained:** keep the rounding but add **left/right margin** (a
  `max-w-*` / `px-*` container) so the hero breathes.

Whichever we pick, apply the same treatment consistently to the section around
the hero so it doesn't read as "uitgerekt".

### 8e. Dead CTA buttons — known, no action needed here

The user confirms the non-working buttons are fine "omdat het demo variant is."
No new work item: this is already tracked — `#demo` becomes the real `/demo`
route in §6, and `#voorbeelden` should anchor to the (new) examples/overview
section once it exists. Listed only so it isn't re-raised as a bug.
