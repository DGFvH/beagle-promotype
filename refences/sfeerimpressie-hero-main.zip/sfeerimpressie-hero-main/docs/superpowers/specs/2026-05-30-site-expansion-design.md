# Site Expansion — Design

**Date:** 2026-05-30
**Branch:** `claude/nice-cray-cTwyH`
**Status:** Draft for user review (decisions approved 2026-05-30; copy drafts pending review)

## Context

The page today is a single route `/` rendering `SnapScroller + Hero +
ScrollFeatures`. There is no nav, no footer, no other routes, no company
details, no pricing. The user's feedback (2026-05-29) is that the page reads
as "kaal" and generically AI-styled, and that it **builds no trust**: a visitor
sees a slick demo but no bedrijfsnaam, no KvK, no prijs, no way to verify the
company is real. Trust-building is the goal of this expansion, not just filling
structural gaps.

This spec covers the locked-in scope from the brainstorm plus three decisions
taken 2026-05-30: indicative pricing tiers, a short "Over ons" block on `/`,
and AVG-aligned legal pages drafted for the user to have reviewed.

## Decisions

| Topic | Decision |
| --- | --- |
| Architecture | Single long page `/` with anchor sections, plus subpages `/demo`, `/privacy`, `/terms`. |
| Voice | Formal "u", professional Dutch. No decorative em-dashes in user-facing copy. |
| Pricing | **Indicative tiers** (3 placeholder tiers, "vanaf" framing). Prices are placeholders to confirm; no real model exists yet. |
| Over ons | **Short "Over ons" block on `/`** plus full bedrijfsgegevens in the footer. No separate page. |
| Legal | I draft Dutch **AVG-aligned templates** for `/privacy` and `/terms`. User must have them professionally reviewed before go-live. |
| Demo form | In-page form on `/demo`, **stub** submit (client-side "bedankt" state). No backend yet. |
| Nav | **Sticky** top bar, always visible, so the "Demo aanvragen" CTA and links stay reachable. |
| Logo | Text wordmark fallback until the user supplies an SVG/PNG. |
| Build order | Spec reviewed first, then implement. Granularity confirmed at approval (default: phased commits). |

## Page composition (new order on `/`)

```
<NavHeader/>            // new — sticky
<Hero/>                 // existing — unchanged
<Overview/>            // new — #overzicht
<ScrollFeatures/>      // existing — #functies
<Pricing/>            // new — #prijzen
<FAQ/>                // new — #faq
<OverOns/>            // new — #over-ons
<Footer/>             // new
```

Anchor ids: `#overzicht`, `#functies`, `#prijzen`, `#faq`, `#over-ons`.

**Scroll-snap reconciliation (decided).** Snap is **scoped to the upper
showcase region only**: Hero, Overview, and ScrollFeatures hard-snap as today;
everything from Pricing down (Pricing, FAQ, Over ons, Footer) scrolls as a
normal page with no snap. Implementation: rather than `y mandatory` on `html`,
apply the snap container to a wrapper around just the showcase blocks (or keep
`html` snap but stop adding `.snap-block` / use `scroll-snap-align: none` from
Pricing onward). Verify the transition out of the snap region into free-scroll
content feels natural (the user is sensitive about snap feel, handoff §7).

## Section briefs

### 1. NavHeader (new)

- **Sticky** top bar (always visible), glass/hairline treatment consistent
  with the page.
- Left: wordmark **Sfeerimpressie** (text until a logo asset arrives).
- Center/right: anchor links **Overzicht · Functies · Prijzen · FAQ**.
- Right: persistent **Demo aanvragen** button → `/demo`.
- Mobile: collapses to a menu (hamburger) with the same links + button.
- Active-section highlight optional (phase-2 nicety, not required for v1).

### 2. Overview (new) — `#overzicht`

One tight section between Hero and ScrollFeatures. Restates the value prop and
gives three concrete proof points, so a realtor "gets it" before the
feature deep-dive. Draft copy (for review):

- Eyebrow: `Voor makelaars`
- Heading: `Meer opdrachten winnen, sneller verkopen.`
- Lead: `Laat opdrachtgevers en kopers in seconden zien wat een leeg of
  gedateerd pand kan worden. Geen stylist, geen wachttijd, geen verbouwing.`
- Three points (icon + label + one line):
  - `Tot 90% goedkoper dan fysieke styling`
  - `Een ingerichte impressie in onder de 30 seconden`
  - `20+ stijlen, van Scandinavisch tot Art Deco`

**Visual treatment (decided 2026-05-30): a compact 3-card grid** (icon + stat
+ one line each); the three points above become the three cards. Heading + lead
sit above the grid, no body image. Stats are summarized here; the feature
blocks below prove them.

### 3. Pricing (new) — `#prijzen`

Three indicative tiers, "vanaf" framing. **Decided 2026-05-30: show visible
placeholder prices** ("vanaf €[xx]" on Start/Kantoor, "Prijs op aanvraag" on Op
maat) plus the "prijzen zijn indicatief" disclaimer, so the section looks
complete; real numbers swap in later. Prices below are placeholders to confirm.

| Tier | Voor wie | Indicatie | Kernpunten (draft) |
| --- | --- | --- | --- |
| **Start** | De individuele makelaar | vanaf €[xx]/mnd | [n] inrichtingen/mnd, 20+ stijlen, voor- en na-vergelijk |
| **Kantoor** | Teams en kantoren | vanaf €[xx]/mnd | Meer volume, meerdere gebruikers, prioriteit |
| **Op maat** | Grote kantoren / ketens | Prijs op aanvraag | Onbeperkt volume, eigen huisstijl, ondersteuning |

- Each tier card: naam, doelgroep-zin, prijsindicatie, 3–4 bullets, CTA
  **Demo aanvragen** → `/demo`.
- A line under the tiers: `Prijzen zijn indicatief. Vraag een demo aan voor een
  voorstel op maat.` (keeps us honest while a real model is set).

### 4. FAQ (new) — `#faq`

Collapsible accordion (native `<details>`/`<summary>` for accessibility, or a
controlled component with proper ARIA). **Decided 2026-05-30: trimmed to 6**
(dropped "welke foto's", merged the old #3+#4 into one about using *and*
disclosing the images). Final set in formal "u":

1. **Wat is virtuele inrichting precies?** Virtuele inrichting (ook wel virtual
   staging) voegt digitaal meubels en styling toe aan een foto van een leeg of
   gedateerd pand, zodat kopers de potentie direct zien.
2. **Hoe snel heb ik een ingerichte impressie?** In de regel binnen 30 seconden
   per foto, klaar vóór uw volgende bezichtiging.
3. **Mag ik de beelden gebruiken, en moet ik vermelden dat ze virtueel zijn
   ingericht?** Ja, u mag de resultaten gebruiken in uw advertenties en
   presentaties op bijvoorbeeld Funda en social media. Wij adviseren wel
   transparantie naar kopers: vermeld dat het om een virtuele impressie gaat.
   Dat voorkomt misverstanden en past bij de richtlijnen.
4. **Welke stijlen zijn beschikbaar?** Meer dan 20 stijlen, van Scandinavisch
   en modern tot klassiek en Art Deco.
5. **Heb ik speciale software of kennis nodig?** Nee. U uploadt een foto en
   kiest een stijl; de rest gebeurt automatisch in de browser.
6. **Wat kost het?** Zie [Prijzen](#prijzen). De definitieve prijs stemmen we
   af op uw volume; vraag een demo aan voor een voorstel.

### 5. OverOns (new) — `#over-ons`

Short block, 2–3 sentences + bedrijfsgegevens. Draft (placeholders bracketed):

> **Over Sfeerimpressie**
> Sfeerimpressie is gemaakt voor makelaars die panden sneller en aantrekkelijker
> in de markt willen zetten. Wij combineren AI met oog voor styling, zodat u
> zonder gedoe een professionele impressie levert.
>
> [Bedrijfsnaam] · KvK [nummer] · BTW [nummer] · [Adres] · [e-mail]

### 6. Footer (new)

Multi-column, hairline top border, consistent with the cream theme.

- **Bedrijf:** [Bedrijfsnaam], [Adres], KvK [nummer], BTW [nummer].
- **Navigatie:** Overzicht, Functies, Prijzen, FAQ, Demo aanvragen.
- **Juridisch:** Privacyverklaring (`/privacy`), Algemene voorwaarden
  (`/terms`).
- **Contact:** [e-mail], (optioneel) telefoon.
- Bottom line: `© [jaar] [Bedrijfsnaam]. Alle rechten voorbehouden.`

## Subpages

### `/demo`

- In-page form: **Naam, Bedrijf, E-mail, Telefoon, Bericht** (e-mail required,
  rest sensible). Realtor-framed intro line above the form.
- **Stub submit:** on submit, show a "Bedankt, we nemen binnen één werkdag
  contact met u op." confirmation state. No data is sent anywhere yet; this is
  wired to a real handler later.
- Note: this Next.js (16) has breaking changes vs. training data. Read
  `node_modules/next/dist/docs/` for the current form / server-action pattern
  before implementing. Default plan: client component with controlled fields
  and a local "submitted" state; swap in a real action later.
- Repoint the hero primary CTA and the nav button from `#demo` to `/demo`.

### `/privacy` and `/terms`

- Dutch, AVG-aligned **template** text drafted by me, with company placeholders.
- `/privacy` sections: verwerkingsverantwoordelijke, welke gegevens, doeleinden
  en grondslag, bewaartermijn, delen met derden / verwerkers, cookies, rechten
  van betrokkenen, klacht bij de Autoriteit Persoonsgegevens, contact.
- `/terms` sections: definities, toepasselijkheid, de dienst, abonnement en
  betaling, gebruiksrecht van de gegenereerde beelden, verplichting tot
  transparantie richting kopers, aansprakelijkheid, looptijd en opzegging,
  wijzigingen, toepasselijk recht en geschillen.
- Prominent note at top (draft watermark): the user must have these reviewed by
  a professional before go-live. Shared layout for legal pages (simple prose
  container, back-to-home link).

## Polish — SEO & assets

- **Meta** (`layout.tsx`): realtor-keyword title + description (virtuele
  inrichting, virtual staging, verkoopstyling, makelaar, sfeerimpressie). No
  em-dashes.
- **Open Graph / Twitter** tags + OG image PNG 1200×630 (need asset from user,
  or I generate a branded placeholder).
- **Structured data:** Organization + SoftwareApplication JSON-LD.
- **Favicon:** `favicon.ico` exists; confirm it reflects the brand or replace.

## Content the user must provide

(Buildable with placeholders meanwhile; these unblock go-live.)

- Bedrijfsnaam, KvK-nummer, BTW-nummer, adres, contact-e-mail (+ telefoon?).
- Logo (SVG/PNG) or confirm text wordmark.
- Real pricing numbers (or confirm the indicative placeholders stay until set).
- Review/sign-off on the FAQ answers and legal text.
- OG image 1200×630, or approval to generate one.

## Implementation roadmap

1. **Shell + trust sections on `/`** — NavHeader, Overview, Pricing, FAQ,
   OverOns, Footer (with placeholder company data). Reconcile scroll-snap.
2. **Subpages** — `/demo` stub form (+ repoint CTAs), `/privacy`, `/terms`
   shared legal layout with drafted template text.
3. **Polish** — meta/OG/JSON-LD, favicon check, OG image.

Each phase verified with `npx tsc --noEmit` and `npm run lint` before commit.
Mobile re-check after every section (the user flagged the current mobile as
"lelijk"; do not regress it).

## Decided

- Nav: **sticky, always visible.**
- Scroll-snap: **scoped to the showcase region** (Hero/Overview/Features snap;
  Pricing and below scroll free).
- Pricing: **visible placeholder prices** ("vanaf €xx" on Start/Kantoor, "Prijs
  op aanvraag" on Op maat) + "indicatief" disclaimer; real numbers later.
- FAQ: **6 entries** (dropped "welke foto's", merged use+disclosure into one).
- Overview: **3 icon/stat card grid** (no body image).

## Open items to confirm at review

All design questions resolved. Remaining items are content the user must
provide (see "Content the user must provide" above) and the build-granularity
choice (whole shell in one pass vs. phased commits).

## Out of scope (unchanged from brainstorm)

How-it-works section (features cover it), social proof / testimonials (no real
customers yet), a separate final-CTA section, blog / case studies. The hero
polish items (handoff §8a–8d: tab naming, fake drag-line, mobile CTAs, desktop
framing) are a parallel track, not part of this expansion build.
