# B2B Realtor Repositioning — Design

**Date:** 2026-05-28
**Branch:** `feat/b2b-realtor-positioning`
**Status:** Approved during brainstorming on 2026-05-28

## Context

The Sfeerimpressie landing page currently reads as a B2C tool addressed to the
homeowner ("uw ruimte", "droominterieur", "Probeer gratis", "Klaar terwijl uw
koffie nog warm is"). The target audience is in fact **real-estate agents
(makelaars)** who use the AI styling tool to help sell or rent properties.
This spec repositions the page to convince a realtor to subscribe.

## Decisions

| Topic | Decision |
| --- | --- |
| Primary job of page | B2B marketing — convince a realtor to subscribe. |
| Audience | The realtor, as a professional. The buyer/client is the audience of the *product*, not the page. |
| Scope | Phase 1: copy & framing rewrite (do now). Phase 2: a roadmap of further B2B enhancements, all layout-preserving. |
| Voice | Formal "u", professional. |
| Lead message | A + B balanced — "show buyers a property's potential" *and* "sell faster". |
| Primary CTA | "Demo aanvragen". |
| Secondary CTA | "Bekijk voorbeelden" (kept). |
| Layout | **Do not change the layout.** No new sections, no restructuring. Content-only edits. |

## Phase 1 — Copy & framing rewrite (do now)

All edits are content-only. No layout/structural changes.

### `src/app/layout.tsx` — metadata

- **title** → `Sfeerimpressie — Virtuele styling waarmee makelaars sneller verkopen`
- **description** → `Laat kopers in seconden zien wat een leeg of gedateerd pand kan worden. Virtuele AI-styling voor makelaars — win meer opdrachten en verkoop sneller. Vraag een demo aan.`

### `src/components/hero/Hero.tsx` — headline

Current: `Van lege ruimte naar droominterieur.`

New: `Laat kopers zien wat een woning kan worden — en verkoop sneller.`

- Keep the existing gradient/emphasis treatment. Apply the gradient to the
  phrase **"wat een woning kan worden"** (replacing the current
  `droominterieur` span).
- The trailing period stays in its own span using `--head-to`, matching the
  current pattern.
- No subline is added. The hero remains headline + preview only.

### `src/components/hero/HeroPreviewCard.tsx` — CTAs

- Primary button label: `Probeer gratis` → **`Demo aanvragen`**
- Primary `href`: `#start` → **`#demo`**
- Secondary button label: **unchanged** (`Bekijk voorbeelden →`)
- Secondary `href`: **unchanged** (`#voorbeelden`)
- Tab labels (Voor & na / Inrichten / AI in actie): **unchanged**.

### `src/components/scroll/ScrollFeatures.tsx` — section intro

- Eyebrow `Hoe het werkt`: **unchanged**.
- H2 *"Drie manieren om uw ruimte opnieuw te zien."* →
  **"Drie manieren om de potentie van een pand te tonen."**
  - Apply the gradient to the phrase **"de potentie van een pand"** (replacing
    the current `opnieuw te zien` span).
- Intro paragraph *"Scroll naar beneden om elke functie in actie te zien — elk
  paneel laadt wanneer het in beeld komt."*: **unchanged**.
- `aria-label` on the section: `Drie manieren om uw ruimte te transformeren` →
  **`Drie manieren om de potentie van een pand te tonen`**.

### `ScrollFeatures.tsx` — Feature 01 (Voor & na)

- **Title** *"Zie het verschil in één blik."* →
  **"Toon het verschil in één blik."**
  - Gradient stays on **"in één blik"** (no change to the emphasis word).
- **Body** →
  > "Sleep over de foto en laat kopers in seconden zien hoe een leeg of
  > gedateerd pand er gestyled uitziet — in elke gewenste stijl, van
  > Scandinavisch tot klassiek. Geen stylist, geen wachttijd, klaar vóór uw
  > volgende bezichtiging."
- **Bullets** →
  1. "Originele en gestylede foto naast elkaar in één beeld"
  2. "Onbeperkt restylen tot het bij de doelgroep past"
  3. "Direct te gebruiken in uw brochure of online listing"

### `ScrollFeatures.tsx` — Feature 02 (Inrichten)

- **Title** *"Plaats de meubels die u wil."* →
  **"Richt elke ruimte in zoals u die wilt presenteren."**
  - Apply the gradient to **"zoals u die wilt presenteren"** (replacing the
    current `die u wil` span).
- **Body** →
  > "Kies uit honderden meubelstukken en presenteer elke ruimte op zijn
  > best. Schaal, kleur en stijl passen we automatisch aan de woning aan."
- **Bullets** →
  1. "Bibliotheek met banken, tafels, lampen en planten"
  2. "Eén klik om een stijl op de hele ruimte toe te passen"
  3. "Realistische schaduwen en perspectief"

### `ScrollFeatures.tsx` — Feature 03 (AI-advies)

- **Title** *"Een AI die uw ruimte écht begrijpt."* →
  **"Een AI die het pand écht begrijpt."**
  - Gradient stays on **"écht begrijpt"** (no change to the emphasis word).
- **Body** →
  > "Onze AI analyseert de foto in detail — afmetingen, lichtinval, indeling,
  > materialen. Stel vragen in gewone taal en krijg onderbouwd stylingadvies
  > dat klopt bij het pand, niet een generiek moodboard."
- **Bullets** →
  1. "Herkent wanden, ramen, verlichting en proporties"
  2. "Vraag advies over kleuren, meubels of indeling"
  3. "Onderbouwt elke suggestie met wat het in de foto ziet"

### Alt text / aria sweep

Update consumer-toned alt text and ARIA labels where they reference "uw
ruimte" or the homeowner framing. Do not invent new labels; only swap phrasing
inside existing attributes.

Specifically expected hits (search for these in the codebase before editing):

- `BeforeAfterSlider.tsx` — alt text for the empty/furnished room photos. Keep
  descriptive (these are accessibility labels for the photo content). No
  change required unless an alt contains B2C framing — the current alts read
  "Lege woonkamer zonder meubels" / "Ingerichte woonkamer met bank, salontafel
  en hanglamp", which describe the photo and are fine. **No change.**
- `FurnitureAnimation.tsx` — frame alts describe room contents. **No change.**
- `TransformationPreview.tsx` — `alt="Lege kamer die door de AI geanalyseerd
  wordt"`. **No change** (descriptive, neutral).
- `HeroPreviewCard.tsx` — `aria-label="Preview-modus"`. **No change.**

Conclusion: a sweep is part of the spec, but on inspection no existing
alt/aria value carries consumer framing that needs rewording. The Phase 1
content edits above are sufficient.

### What does NOT change in Phase 1

- Layout, sections, component structure, animation timings.
- Visual palette (cream + amber stays).
- Theme toggle (Phase 2 reconsiders it).
- Emoji furniture chips in `FurnitureAnimation.tsx` (explicitly kept — the
  user removed this item from Phase 2 during brainstorming).
- CTA wiring (`#demo` is a forward-looking anchor; the destination is wired
  in Phase 2).
- SEO/open-graph beyond the meta title/description (Phase 2).

## Phase 2 — B2B roadmap (planned, not implemented now)

All Phase 2 items are layout-preserving — each is a content or styling swap
inside an existing surface. Listed in suggested priority order. Implementation
of any item is a separate task; this spec only lists them.

1. **CTA wiring.** Hook `#demo` to a real destination: `mailto:` with a
   pre-filled subject, a Calendly/Cal.com link, or a small in-page contact
   form. Highest near-term priority — without this, "Demo aanvragen" does not
   convert.
2. **Lifestyle-phrasing second sweep.** Re-read the full page after Phase 1
   lands and remove any remaining casual/cozy phrasing, asides, or B2C
   residue.
3. **Trust microcopy on existing CTAs.** Add one hairline caption under the
   primary CTA cluster, e.g. *"Gebruikt door makelaars in heel Nederland"* or
   *"Geen creditcard nodig voor de demo."* No new section; one extra text
   node inside the existing CTA group.
4. **Stats woven into existing bullets.** Upgrade one bullet per feature to
   carry a number — e.g. *"90% goedkoper dan fysieke styling"*, *"Klaar in
   <60 seconden per foto"*. Requires real data; placeholders should be marked
   TBD until provided.
5. **Palette nudge (optional).** Slightly cool the cream/amber surface tints
   toward a more professional cream. Token-only change in `globals.css`. A/B
   candidate.
6. **Heading-gradient discipline.** Today every feature title carries a
   gradient word — for B2B this can feel too "marketing". Drop the gradient
   from the three feature titles, keep it on the hero. CSS-only.
7. **SEO / open-graph.** Realtor-targeted keywords ("virtual staging
   makelaar", "virtuele styling", "woning sneller verkopen"), OG image,
   SaaS structured data. Invisible to layout.
8. **Theme toggle reconsidered.** B2B sites rarely ship a theme toggle.
   Remove the floating toggle or relocate it to a footer (when a footer
   exists). Minor JSX edit; no layout shift.

## Out of scope

- Pricing tier, testimonials block, logo strip — these would require new
  sections and therefore contradict the "do not change the layout"
  constraint. Tracked separately whenever the layout is opened up.
- Dutch informal "je" voice — explicitly declined.
- A subline under the hero headline — declined.

## Acceptance — Phase 1

- All strings listed above appear verbatim in their respective files.
- `npm run lint` and `npx tsc --noEmit` both pass with no new errors.
- The dev server renders the page with the new headline, new CTA label, new
  feature titles/bodies/bullets, and the new meta title/description.
- No layout regressions: tab strip, preview aspect ratios, snap-block heights,
  CTA cluster position all unchanged.
- All work committed to `feat/b2b-realtor-positioning`. Not pushed unless the
  user explicitly requests it.

## Notes for the implementer

- The hero gradient span replacement requires moving the `<em>` and the
  trailing-period span so the gradient lands on **"wat een woning kan
  worden"** (multi-word phrase, not a single word). Mind the spacing around
  the em-dash.
- The ScrollFeatures intro H2 gradient phrase is similarly multi-word ("de
  potentie van een pand"). Confirm wrapping behaviour at the smallest H2
  breakpoint still reads cleanly.
- The Phase 1 changes touch four files: `src/app/layout.tsx`,
  `src/components/hero/Hero.tsx`, `src/components/hero/HeroPreviewCard.tsx`,
  `src/components/scroll/ScrollFeatures.tsx`.
