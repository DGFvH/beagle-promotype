import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Pin the workspace root to this project. Without it Turbopack walks up and
  // picks a stray C:\Users\diede\package-lock.json as the root, which breaks
  // module resolution (e.g. the next/font Google internal). Vercel is
  // unaffected (single lockfile there).
  turbopack: {
    root: __dirname,
  },
};

export default nextConfig;
