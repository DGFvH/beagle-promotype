# Sfeerimpressie Hero — Prompt Plan

## Context

**Product:** Sfeerimpressie (sfeerimpressie.nl) — AI interior design tool. Upload a photo of an empty/outdated house, get a finished interior visualization.

**Style reference:** WoningAnalyse hero (dark cinematic bg, motion.div staggered reveals, brand badge, `text-display-1` typography, gradient overlays, glassmorphism cards). RoomLift.ai hero (auto-playing video grid, before/after previews, polished product mockups).

**Stack:** Next.js, Tailwind, Framer Motion, React.

---

## Hero Structure

```
┌─────────────────────────────────────────────────────┐
│  HERO SECTION (full viewport, dark bg)              │
│                                                     │
│  ┌──────────────┐  ┌────────────────────────────┐   │
│  │ TEXT COLUMN   │  │ PREVIEW COLUMN             │   │
│  │              │  │                            │   │
│  │ Badge        │  │ ┌────────────────────────┐ │   │
│  │ H1           │  │ │ TABBED PREVIEW CARD    │ │   │
│  │ Subtitle     │  │ │                        │ │   │
│  │ CTA button   │  │ │ Tab 1: Before/After    │ │   │
│  │ Trust icons  │  │ │ Tab 2: Drag & Drop     │ │   │
│  │              │  │ │ Tab 3: GIF Preview     │ │   │
│  │              │  │ └────────────────────────┘ │   │
│  └──────────────┘  └────────────────────────────┘   │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## Prompt 1 — Layout & Typography

> **Goal:** Scaffold the hero section with text column + preview column.

```
Build the Sfeerimpressie hero section as a React component with Framer Motion.

LAYOUT:
- Full viewport height, dark background (#070A16) with a subtle dot-grid pattern overlay
- Two-column layout (text left 40%, preview right 60%) on lg+, stacked on mobile
- Radial gradient glow (brand color, ~15% opacity) anchored bottom-left

TEXT COLUMN (left):
- Badge component: "Sfeerimpressie" (use accent variant, orange/warm tone)
- H1: "Van lege ruimte naar\n<em>droominterieur</em>" — italic em in brand accent color
- Subtitle (18px, muted): "Upload een foto van een leeg of verouderd pand. 
  Onze AI toont in seconden hoe het interieur eruit kan zien — 
  volledig ingericht, in de stijl die u kiest."
- CTA button: "Probeer gratis" — solid brand color, rounded-xl, hover scale
- Trust row below CTA: three inline items with icons — 
  "Geen creditcard nodig" · "Resultaat in 30 sec" · "Onbeperkt stijlen"

ANIMATIONS (Framer Motion):
- Badge: fadeIn + slideUp, delay 0.1
- H1: fadeIn + slideUp, delay 0.2
- Subtitle: fadeIn + slideUp, delay 0.35
- CTA: fadeIn + slideUp, delay 0.5
- Trust row: fadeIn, delay 0.7

TYPOGRAPHY:
- H1: text-display-1 equivalent (clamp 36px–56px), font-extrabold, tracking tight
- Use DM Sans or equivalent variable font, not Inter/Roboto/Arial
```

---

## Prompt 2 — Before/After Slider Preview

> **Goal:** Interactive slider showing empty room → AI-furnished room.

```
Build a BeforeAfterSlider component for the hero preview column.

REQUIREMENTS:
- Two images stacked: left side = empty room photo, right side = AI-furnished result
- Draggable divider handle in the center (vertical line + circle grip)
- Handle: white circle (32px) with a left-right arrow icon, 
  subtle drop shadow, glassmorphism border
- Smooth CSS clip-path or overflow-based reveal (no canvas)
- On mount: auto-animate handle from 70% → 30% → 50% over 2s 
  to demonstrate the interaction, then let user drag freely
- Labels: floating "Voor" badge (left, top) and "Na" badge (right, top) 
  — semi-transparent dark bg, white text, rounded-full, text-xs

CONTAINER STYLING:
- Rounded-2xl, overflow-hidden
- Subtle border (white/10)
- Shadow-2xl
- Aspect ratio 4:3

ANIMATION:
- Container: scale 0.96 → 1, opacity 0 → 1, delay 0.6, duration 0.6
- Handle auto-play: spring easing, stiffness 60

Use placeholder images (solid color blocks with labels) that can be swapped later.
```

---

## Prompt 3 — Drag & Drop Furniture Preview

> **Goal:** Mockup of the drag-and-drop furniture tool.

```
Build a DragDropPreview component — a stylized mockup (NOT a real drag engine) 
that visually demonstrates the furniture placement concept.

LAYOUT:
- Main area: room photo placeholder (rounded-2xl, aspect 4:3)
- Bottom: horizontal scrollable strip of furniture thumbnails (sofa, table, lamp, plant, rug)
  — each in a small rounded-xl card (64x64) with subtle border
- One furniture item (sofa) is shown "in transit": 
  slightly lifted with a drop shadow, positioned mid-room with a dashed 
  placement outline underneath

ANIMATIONS:
- On mount (or when tab becomes active):
  1. Furniture strip slides up from bottom (delay 0.4)
  2. Sofa card lifts out of strip, scales 1→1.1, moves to room center (delay 0.8)
  3. Dashed outline pulses twice (delay 1.2)
  4. Sofa drops into place, shadow reduces, outline disappears (delay 1.6)
  5. Small "✓ Geplaatst" toast fades in bottom-right of the room (delay 2.0)

STYLING:
- Glassmorphism card container (bg-white/5, backdrop-blur, border white/10)
- Furniture strip: horizontal scroll, gap-3, px-4
- Each thumbnail: bg-white/10, hover:bg-white/20, transition
- Active/selected thumbnail: ring-2 ring-accent
- "Slepen & plaatsen" label top-left of room, text-xs, muted

Use placeholder colored rectangles for furniture items. 
Real images will be swapped in later.
```

---

## Prompt 4 — Animated GIF/Video Preview

> **Goal:** Auto-playing transformation sequence showing the AI at work.

```
Build a TransformationPreview component showing the AI process as a looping sequence.

SEQUENCE (CSS/Framer Motion keyframes, no actual video file needed):
1. Empty room photo visible (0–2s)
2. Scanning overlay: horizontal gradient line sweeps top→bottom 
   with a subtle glow (brand color, 40% opacity) (2–3.5s)
3. "AI aan het werk..." label fades in center with a spinner (3–4s)
4. Crossfade to furnished room (4–5s)
5. Hold furnished room (5–7s)
6. Quick fade back to empty room (7–7.5s)
7. Loop

STYLING:
- Same rounded-2xl container as other previews
- Scanning line: 2px height, full width, linear gradient with glow
- Progress indicator bottom of card: thin bar (h-1) that fills across 
  the full 7.5s cycle, brand color
- Corner badge: "AI" pill, top-right, brand bg, white text, 
  pulses during processing phase (steps 2–4)
- Small step labels that appear/disappear:
  "Ruimte analyseren..." → "Stijl toepassen..." → "Klaar!"

Use placeholder solid color blocks for the two room states.
```

---

## Prompt 5 — Tab Switcher & Assembly

> **Goal:** Combine all three previews into a tabbed card in the hero.

```
Build a HeroPreviewCard that wraps the three preview components in a tabbed interface.

TABS (bottom of the card, or top as floating pills):
1. "Voor & na" (BeforeAfterSlider) — default active
2. "Inrichten" (DragDropPreview)
3. "AI in actie" (TransformationPreview)

TAB STYLING:
- Floating pill-style tabs, centered below the preview
- bg-white/10 inactive, bg-white/20 active, text-white
- Active tab: animated underline (layoutId for Framer Motion)
- Gap-2, text-xs font-medium

TRANSITIONS:
- Tab content: AnimatePresence with fade + slight slideY (8px)
- Auto-rotate tabs every 6 seconds if user hasn't interacted
  - Pause auto-rotate on hover or manual tab click
  - Show small progress arc around active tab during auto-rotate

CONTAINER:
- Outer glow: box-shadow with brand color at 8% opacity, 0 0 80px
- Floating slightly (translateY oscillation, 6px, 6s cycle, ease-in-out)
- Responsive: full-width on mobile, max-w-[580px] on desktop

MOBILE:
- Stack vertically, tabs become horizontally scrollable chips
- Preview aspect ratio stays 4:3
- Auto-rotate disabled on mobile (save performance)
```

---

## Prompt 6 — Polish & Final Integration

> **Goal:** Wire everything into the page, final animation choreography.

```
Integrate the complete hero into the Sfeerimpressie landing page.

FINAL POLISH:
- Stagger all animations: text column first (0–0.7s), 
  then preview card enters (0.6–1.2s) — slight overlap for flow
- Add particle/dust effect in background (very subtle, 15–20 particles, 
  slow drift upward, white at 3% opacity) — CSS only, no heavy lib
- Ensure all text passes WCAG AA contrast on dark background
- Preload placeholder images to avoid layout shift
- Add aria-labels to slider handle, tab buttons, interactive elements

RESPONSIVE BREAKPOINTS:
- lg+ (1024px): two-column side by side
- md (768px): stacked, preview card first (visual hook), text below
- sm (<768px): stacked, text first, preview below, reduced animation

PERFORMANCE:
- Use will-change on animated elements, remove after animation completes
- Lazy-load preview components below fold on mobile
- Reduce motion: respect prefers-reduced-motion, skip auto-play sequences
```

---

## Asset Checklist

| Asset | Spec | Status |
|---|---|---|
| Empty room photo | 1200×900, .webp, <100kb | ⬜ Needed |
| Furnished room photo (same angle) | 1200×900, .webp, <100kb | ⬜ Needed |
| Furniture thumbnails (5×) | 128×128, .webp, transparent bg | ⬜ Needed |
| Hero background texture/photo | 1920×1080, .webp, <200kb | ⬜ Needed |
| Dot-grid pattern | SVG or CSS pattern | ⬜ Can generate |

---

## Build Order

1. **Prompt 1** → Layout + text column + animations → commit & verify
2. **Prompt 2** → BeforeAfterSlider → commit & verify
3. **Prompt 3** → DragDropPreview → commit & verify
4. **Prompt 4** → TransformationPreview → commit & verify
5. **Prompt 5** → Tab switcher + assembly → commit & verify
6. **Prompt 6** → Polish, responsive, a11y, performance → commit & verify
